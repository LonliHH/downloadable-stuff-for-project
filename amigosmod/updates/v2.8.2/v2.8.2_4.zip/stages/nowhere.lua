function onCreate()
	makeLuaSprite('bgc')
	makeGraphic('bgc', 2000, 2000, 'c4c4c4')
	screenCenter('bgc', 'xy')
	setScrollFactor('bgc', 0, 0)
	addLuaSprite('bgc', false)
end