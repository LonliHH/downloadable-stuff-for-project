function onCreate()
	makeLuaSprite('bg', 'insomnia/bedroom', -639, -359)
	addLuaSprite('bg', false)
end

function onCreatePost()
	triggerEvent('se', 'camThing')
	addLuaScript('custom_events/CameraControl')
	triggerEvent('CameraControl', '390,170', '0.9')
	removeLuaScript('custom_events/CameraControl')
end