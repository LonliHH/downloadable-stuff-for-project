function onCreate()
	makeLuaSprite('bg')
	makeGraphic('bg', 2000, 2000, '888888')
	screenCenter('bg', 'xy')
	setScrollFactor('bg', 0, 0)
	addLuaSprite('bg', false)
end

function onMoveCamera(focus)
	if focus == 'boyfriend' then
		cam(500, 550)
		setCamZoom(0.8, 0.65)
	elseif focus == 'dad' then
		cam(300, 370)
		setCamZoom(1.1, 0.65)
	end
end

function cam(x, y)
	setProperty('camFollow.x', x)
	setProperty('camFollow.y', y)
end

function setCamZoom(v1, v2)
	doTweenZoom('camz', 'camGame', v1, v2, 'quadOut')
end

function onTweenCompleted(t)
	if t == 'camz' then setProperty('defaultCamZoom', getProperty('camGame.zoom')) end
end