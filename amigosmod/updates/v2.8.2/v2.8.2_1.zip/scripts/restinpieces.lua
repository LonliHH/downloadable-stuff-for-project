local menu = true
local urDead = false
local accepted = false
local daDead
local daMusic
local daRevive
local flashingLife
local preloadDeath
local stageZoom = getProperty('defaultCamZoom')

function onCreatePost() if preloadDeath then processDeathVars() end end
function onCreate()
	menu = stringStartsWith(songName, 'Menu')
	if menu then
		close()
		return
	end

	flashingLife = getDataFromSave('lonlihh', 'flashingLife')
	preloadDeath = getDataFromSave('lonlihh', 'preloadDeath')
end

function processDeathVars()
	if menu then return end

	checkDeathVar('charName', 'bf-dead')
	checkDeathVar('off.cam.x', 700)
	checkDeathVar('off.cam.y', 880)
	checkDeathVar('off.x', -200)
	checkDeathVar('off.y', 0)
	checkDeathVar('off.time', 1.25)
	checkDeathVar('cam.zoom', stageZoom)
	checkDeathVar('cam.speed', 1.2)
	checkDeathVar('cam.angle', 0)
	checkDeathVar('bgColor', '000000')

	daDead = getPropertyFromClass('substates.GameOverSubstate', 'deathSoundName')
	daMusic = getPropertyFromClass('substates.GameOverSubstate', 'loopSoundName')
	daRevive = getPropertyFromClass('substates.GameOverSubstate', 'endSoundName')

	if preloadDeath then
		precacheImage(checkDeathVar('charSprite', 'characters/BOYFRIEND_DEAD'))
		precacheSound(daDead)

		if getDataFromSave('lonlihh', 'optimizeMod') then
			if not flashingLife then
				precacheMusic(daMusic)
				precacheMusic(daRevive)
			end
		else
			precacheMusic(daMusic)
			precacheMusic(daRevive)
		end
	end
end

function onGameOver()
	if not menu then
		setProperty('lsc.alpha', 0)
		setVar('am.death.prevZoom', getProperty('camGame.zoom'))
		if not preloadDeath then processDeathVars() end
		openCustomSubstate('amDeath', true)
	end

	return Function_Stop
end

function onCustomSubstateCreate(n)
	if n == 'amDeath' then
		urDead = true
		ripDie(checkDeathVar('charName'), getColorFromHex(checkDeathVar('bgColor')))
		playSound(daDead, 1, 'daDead')

		if flashingLife then
			accepted = true
			runTimer('skipDeath', 0.35)
		else
			runTimer('toDeathLoop', 1 + checkDeathVar('off.time'))
		end
	end
end

function checkDeathVar(tag, default)
	local v = getVar('am.death.'..tag)
	if v == nil then
		setVar('am.death.'..tag, default)
		return default
	end

	return v
end

function onCustomSubstateUpdate(n, dt)
	if n == 'amDeath' and not accepted then
		if keyJustPressed('accept') then
			accepted = true
			cancelTimer('toDeathLoop')
			stopSound('daDead')
			ripRevive(daRevive)
		elseif keyJustPressed('back') then
			accepted = true
			setDataFromSave('lonlihh', 'menuLoadIn', true)
			cancelTimer('toDeathLoop')
			stopSound('daDead')
			soundFadeOut('', 0.5, 0)
			runTimer('forceLoadFade', 0.05, 10)
		end
	end
end

function onTimerCompleted(t, l, ll)
	if urDead then
		if t == 'forceLoadFade' then
			setProperty('lsc.alpha', getProperty('lsc.alpha') + 0.1)
			if ll == 0 then loadSong('menu', -1) end
		elseif t == 'toDeathLoop' then
			playMusic(daMusic, 1, true)
			ripLoop()
		elseif t == 'skipDeath' then
			local fadeTime = getVar('am.loadScreen.fadeTime')

			setVar('am.loadScreen.function', 'restartSong')
			doTweenAlpha('loadFadeIn', 'lsc', 1, fadeTime, 'sineOut')
			soundFadeOut('daDead', fadeTime, 0)
		end
	end
end