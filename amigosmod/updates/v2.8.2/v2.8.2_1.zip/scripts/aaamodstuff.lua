local formattedSN
local isMenu = false
local isCounterOn = false

local timeBarEnabled = false
local timeBarFaded = false
local timeBarFadeTime

local iconsBopAngle = 15

local oldNoteSkin

function onCreate()
	setProperty('camHUD.visible', false)

	local versionMatches = version == '0.7.1h'
	if not versionMatches and songName ~= 'Menu (Version Mismatch)' then
		if luaSpriteExists('blak') then
			setProperty('blak.alpha', 1)
			setProperty('blak.visible', true)
		else
			makeLuaSprite('mvb')
			makeGraphic('mvb', screenWidth, screenHeight, '000000')
			setObjectCamera('mvb', 'camOther')
			setObjectOrder('mvb', 100)
			addLuaSprite('mvb')
		end

		loadSong('menu-(version-mismatch)', -1)
		close()
		return
	end

	runHaxeCode([[
		addHaxeLibrary('FlxSave', 'flixel.util');
		addHaxeLibrary('FunkinLua', 'psychlua');

		function initCustomSave(name:String, ?folder:String):Void {
			if (folder == null) folder = 'LonliHH/AmigosMod';

			if (!game.modchartSaves.exists(name)) {
				var save = new FlxSave();
				save.bind(name, folder);
				game.modchartSaves.set(name, save);
				return;
			}

			FunkinLua.luaTrace('initCustomSave: Save file already initialized: ' + name);
		}

		createGlobalCallback('initCustomSave', initCustomSave);
	]])

	initCustomSave('lonlihh')

	if versionMatches then
		if not getDataFromSave('lonlihh', 'disclaimer', false) then
			if songName ~= 'Menu (Disclaimer)' then
				loadSong('menu-(disclaimer)', -1)
				close()
				return
			end
		else
			if not getDataFromSave('lonlihh', 'transferred', false) and songName ~= 'Menu (Save Inform)' then
				local oldMainSave = os.getenv('APPDATA')..'\\ShadowMario\\PsychEngine\\amigosmod\\lonlihh.sol'
				if checkFileExists(oldMainSave, true) then
					loadSong('menu-(save-inform)', -1)
					close()
					return
				end
			end
		end
	end

	initCustomSave('amstats')
	initCustomSave('amcache')

	setPropertyFromClass('openfl.Lib', 'application.window.title', 'FNF: Amigos Mod')
	changeDiscordClientID('1180766780596174848')

	formattedSN = string.lower(songName):gsub('%s', '-')
	isMenu = stringStartsWith(formattedSN, 'menu')

	isCounterOn = getPropertyFromClass('Main', 'fpsVar.visible')
	setPropertyFromClass('Main', 'fpsVar.visible', false)

	oldNoteSkin = getPropertyFromClass('backend.ClientPrefs', 'data.noteSkin')
	setPropertyFromClass('backend.ClientPrefs', 'data.noteSkin', 'Default')

	setProperty('showRating', false)
	coolFFIMsgs()



	if isMenu then
		local cache = function(list)
			if getDataFromSave('amcache', list, nil) == nil then
				local msgPath = 'lonlihh/'..list..'.txt'
				if checkFileExists(msgPath) then
					local assets = stringSplit(getTextFromFile(msgPath), '\n')
					setDataFromSave('amcache', list, assets)
				else
					ffiErrorMsg(getVar('am.errh.msg'):gsub('%[sillyfile%]', msgPath)..'\n'..getVar('am.errh.continueMsg')..';'..getVar('am.errh.title'), 'ok')
				end
			end
		end

		cache('load_msgs')
		cache('pause_msgs')
	end
end

function onCreatePost()
	-- everything is good, load the scene folks
	setVar('am.menu.scene', 'am_none')
	setProperty('camHUD.visible', true)
	startCountdown()

	if not isMenu then
		timeBarEnabled = timeBarType ~= 'Disabled'

		local hideOppStrums = checkFileExists('data/'..formattedSN..'/hideOppStrums.txt')
		if hideOppStrums then
			for i = 0, getProperty('opponentStrums.length') - 1 do
				setPropertyFromGroup('opponentStrums', i, 'alpha', 0)
				setPropertyFromGroup('opponentStrums', i, 'visible', false)
			end
		end

		for i = 0, getProperty('unspawnNotes.length') - 1 do
			if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'noAnimInvisIgnoreNote' then
				setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', true)
				setPropertyFromGroup('unspawnNotes', i, 'noAnimation', true)
				setPropertyFromGroup('unspawnNotes', i, 'visible', false)
				setPropertyFromGroup('unspawnNotes', i, 'copyAlpha', false)
				setPropertyFromGroup('unspawnNotes', i, 'alpha', 0)
			end



			if hideOppStrums and not getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
				setPropertyFromGroup('unspawnNotes', i, 'copyAlpha', false)
				setPropertyFromGroup('unspawnNotes', i, 'alpha', 0)
				setPropertyFromGroup('unspawnNotes', i, 'visible', false)
			end

			setPropertyFromGroup('unspawnNotes', i, 'copyAngle', false)
		end

		setDataFromSave('lonlihh', 'prev.song', formattedSN)



		local aa = getPropertyFromClass('backend.ClientPrefs', 'data.antialiasing')
		setProperty('healthBar.antialiasing', aa)
		setProperty('timeBar.antialiasing', aa)

		local forceCopyFont = getVar('am.forceCopyFont')
		if forceCopyFont == nil then
			forceCopyFont = false
			setVar('am.forceCopyFont', false)
			setVar('am.forceCopyFont.noBorder', false)
		end

		if not forceCopyFont then
			setTextFont('timeTxt', 'visbyround-bold.otf')
			setProperty('timeTxt.y', getProperty('timeTxt.y') - 6)
			setProperty('timeTxt.borderSize', 1.4)
			setProperty('timeTxt.antialiasing', aa)
			setTextFont('botplayTxt', 'visbyround-bold.otf')
			setTextSize('botplayTxt', 30)
			setProperty('botplayTxt.borderSize', 1.4)
			setProperty('botplayTxt.antialiasing', aa)
		end
	end
end

function onSongStart()
	if timeBarEnabled then timeBarFadeTime = songLength - 1000 end

	local dur = crochet / 1000
	for i = 1,2 do
		setProperty('iconP'..i..'.scale.x', 1.2)
		setProperty('iconP'..i..'.scale.y', 1.2)
		doTweenX('iconP'..i..'scaleX', 'iconP'..i..'.scale', 1, dur, 'circOut')
		doTweenY('iconP'..i..'scaleY', 'iconP'..i..'.scale', 1, dur, 'circOut')
	end

	onBeatHit()
end

function noteMiss(i, d, t, s)
	local a = getRandomFloat(40,75)
	if getRandomBool() then a = -a end

	setPropertyFromGroup('playerStrums', d, 'angle', a)
	noteTweenAngle('missback'..d, d + getProperty('opponentStrums.length'), 0, 0.6, 'circOut')
end

function onEndSong()
	if getVar('wasBotplay') then
		setVar('wasBotplay', false)
		setVar('am.loadScreen.function', 'restartSong')
		setDataFromSave('lonlihh', 'botplayDone', true)
		doTweenAlpha('loadFadeIn', 'lsc', 1, getVar('am.loadScreen.fadeTime'), 'sineOut')

		return Function_Stop
	end

	if not isMenu then
		local oldScore = getDataFromSave('amstats', formattedSN..'.score', 0)
		local oldDeaths = getDataFromSave('amstats', formattedSN..'.deaths', 0)
		local curDeaths = getVar('am.deaths')

		if score > oldScore or (score == oldScore and curDeaths < oldDeaths) then
			setDataFromSave('amstats', formattedSN..'.done', true)
			setDataFromSave('amstats', formattedSN..'.score', score)
			setDataFromSave('amstats', formattedSN..'.misses', misses)
			setDataFromSave('amstats', formattedSN..'.acc', getVar('am.accuracy'))
			setDataFromSave('amstats', formattedSN..'.rate', ratingName)
			setDataFromSave('amstats', formattedSN..'.ratefc', ratingFC)
			setDataFromSave('amstats', formattedSN..'.deaths', curDeaths)

			setDataFromSave('lonlihh', 'newScoreSave', true)
		end

		setDeathCounter(0)
	end

	setVar('am.loadScreen.function', 'exitToMenu')
	doTweenAlpha('loadFadeIn', 'lsc', 1, getVar('am.loadScreen.fadeTime'), 'sineOut')

	return Function_Stop
end

function onStepHit()
	if timeBarEnabled and not timeBarFaded and getSongPosition() > timeBarFadeTime then
		timeBarFaded = true
		setProperty('timeBar.visible', true)
		setProperty('timeTxt.visible', true)

		local dur = crochet / 1200
		doTweenAlpha('timeBara', 'timeBar', 0, dur, 'sineOut')
		doTweenAlpha('timeTxta', 'timeTxt', 0, dur, 'sineOut')
	end
end

function bopIcon(tag, angle, dur)
	setProperty(tag..'.angle', angle)
	doTweenAngle(tag..'Bop', tag, 0, dur, 'circOut')
end

function onBeatHit()
	if iconsBopAngle ~= 0 then
		local dur = -1

		local noPlrReaction = getVar('plr.noReaction')
		if noPlrReaction == nil then
			noPlrReaction = false
			setVar('plr.noReaction', noPlrReaction)
		end

		if not noPlrReaction or (noPlrReaction and getHealth() > 0.4) then
			if dur < 0 then dur = crochet / 1000 end
			bopIcon('iconP1', iconsBopAngle, dur)
		end



		local noOppReaction = getVar('opp.noReaction')
		if noOppReaction == nil then
			noOppReaction = false
			setVar('opp.noReaction', noOppReaction)
		end

		if not noOppReaction or (noOppReaction and getHealth() < 1.6) then
			if dur < 0 then dur = crochet / 1000 end
			bopIcon('iconP2', iconsBopAngle, dur)
		end



		iconsBopAngle = -iconsBopAngle
	end
end

function onEvent(n, v1, v2)
	if n == 'se' and v1 == 'icons_angle' then iconsBopAngle = tonumber(v2) end
	if n == 'error msg' then ffiErrorMsg(v1, v2) end
end

function onDestroy()
	setPropertyFromClass('backend.ClientPrefs', 'data.noteSkin', oldNoteSkin)
	setPropertyFromClass('openfl.Lib', 'application.window.title', "Friday Night Funkin': Psych Engine")
	if isCounterOn then setPropertyFromClass('Main', 'fpsVar.visible', true) end
end

function youDiedLol()
	setProperty('camGame.filtersEnabled', false)
	setProperty('camHUD.filtersEnabled', false)
end



function onUpdate()
	if getVar('debugKeys_enabled') then
		if keyboardPressed('CONTROL') then
			if keyboardJustPressed('Z') then setProperty('playbackRate', getProperty('playbackRate') + 1)
			elseif keyboardJustPressed('X') then setProperty('playbackRate', 1) end

			if keyboardJustPressed('F') then
				setPropertyFromClass('openfl.Lib', 'application.window.width', screenWidth)
				setPropertyFromClass('openfl.Lib', 'application.window.height', screenHeight)
			end
		end
	end
end





-- ffi stuff

local ffi_init = false
local ffi
local user32

function coolFFIStuff()
	if ffi_init then return end

	ffi = require('ffi')
	user32 = ffi.load('user32')

	ffi.cdef([[
		enum {
			MB_OK = 0x00000000L,
			MB_ICONINFORMATION = 0x00000040L
		};

		typedef void* HANDLE;
		typedef HANDLE HWND;
		typedef const char* LPCSTR;
		typedef unsigned UINT;

		int MessageBoxA(HWND, LPCSTR, LPCSTR, UINT);
	]])

	setVar('am.errh.ok', ffi.C.MB_OK + ffi.C.MB_ICONINFORMATION)

	ffi_init = true
end

function coolFFIMsgs()
	setVar('am.errh.msg', "The file '[sillyfile]' is missing.")
	setVar('am.errh.restartMsg', "The mod will restart after you press OK.")
	setVar('am.errh.continueMsg', "The mod will keep running after you press OK, but things might not work properly.")
	setVar('am.errh.title', "pls bring back the file :(")
end

function ffiErrorMsg(v1, v2)
	if not ffi_init then coolFFIStuff() end

	local coolMsg = stringSplit(v1, ';')
	user32.MessageBoxA(nil, coolMsg[1], coolMsg[2], getVar('am.errh.'..v2))
end