-- script by LonliHH

local red = false
local alert = false
local enabled = false
local separator = ''
local replacements = {
	['Perfect!!'] = 'WOOO!!',
	['Sick!'] = 'Fantastic', -- 90% to 99%
	['Great'] = 'Amazing', -- 80% to 89%
	['Good'] = 'Nice', -- 70% to 79%
	['Nice'] = ':3', -- 69%
	['Meh'] = 'Ok', -- 60% to 68%
	['Bruh'] = 'Erm', -- 50% to 59%
	['Bad'] = 'Terrible', -- 40% to 49%
	['Shit'] = 'Awful', -- 20% to 39%
	['You Suck!'] = 'L bozo ratio', -- 0% to 19%
	['?'] = '?'
} -- replacements provided by dusky

function onCreate()
	setVar('am.scoreTxt.replacements', replacements)
	if stringStartsWith(songName, 'Menu') then close()
	else enabled = true end
end

function onCreatePost()
	if enabled then
		makeLuaText('scoreTxtThing', '', screenWidth, 0, 0)
		setObjectCamera('scoreTxtThing', 'camHUD')
		setTextAlignment('scoreTxtThing', 'center')
		setProperty('scoreTxt.visible', false)

		if getVar('am.forceCopyFont') then
			separator = '|'
			setProperty('scoreTxtThing.borderSize', getProperty('scoreTxt.borderSize'))
			setProperty('scoreTxtThing.antialiasing', getProperty('scoreTxt.antialiasing'))
			setTextSize('scoreTxtThing', getTextSize('scoreTxt'))
		else
			separator = 'l'
			setTextFont('scoreTxtThing', 'visbyround-bold.otf')
			setTextSize('scoreTxtThing', 22)
			setProperty('scoreTxtThing.antialiasing', getPropertyFromClass('backend.ClientPrefs', 'data.antialiasing'))
			setProperty('scoreTxtThing.borderSize', 1.4)
		end

		setTextString('scoreTxtThing', 'Score: 0 '..separator..' Misses: 0 '..separator..' Accuracy: 0% '..separator..' Rating: ?')
		addLuaText('scoreTxtThing')
		screenCenter('scoreTxtThing', 'x')



		-- health bar stuff
		if not luaSpriteExists('healthAlert') then
			makeLuaSprite('healthAlert', 'healthAlert')
			setObjectCamera('healthAlert', 'camHUD')
			setObjectOrder('healthAlert', getObjectOrder('healthBar') + 1)
			setProperty('healthAlert.visible', false)
			addLuaSprite('healthAlert')
			healthColorizeLuaObj('healthAlert', true)
		end
	end
end

function onBeatHit()
	if getHealth() < 0.4 and not alert then alert = true
	elseif getHealth() > 0.4 and alert then
		alert = false
		setProperty('healthAlert.visible', false)
	end

	if alert then setProperty('healthAlert.visible', not getProperty('healthAlert.visible')) end
end

function onUpdateScore()
	if enabled and luaTextExists('scoreTxtThing') and not getProperty('cpuControlled') then
		local blendedAcc = getVar('am.blendedAcc')
		local percent = blendedAcc ~= nil and blendedAcc or (rating * 100)
		local acc = string.format("%.2f", percent):gsub("%.00$", "")
		setVar('am.accuracy', acc)

		local rName = '?'
		if percent >= 100 then rName = 'Perfect!!'
		elseif percent >= 90 then rName = 'Sick!'
		elseif percent >= 80 then rName = 'Great'
		elseif percent >= 70 then rName = 'Good'
		elseif percent == 69 then rName = 'Nice'
		elseif percent >= 60 then rName = 'Meh'
		elseif percent >= 50 then rName = 'Bruh'
		elseif percent >= 40 then rName = 'Bad'
		elseif percent >= 20 then rName = 'Shit'
		elseif percent >= 0 then rName = 'You Suck!' end

		local displayRating = rName or ratingName
		setTextString('scoreTxtThing', 'Score: '..score..' '..separator..' Misses: '..misses..' '..separator..' Accuracy: '..acc..'% '..separator..' Rating: '..replacements[displayRating]..' ('..ratingFC..')')

		if blendedAcc ~= nil then setVar('am.blendedAcc', nil) end
	end
end

function onUpdatePost()
	if enabled then
		-- 0.4 health = 20% health
		if not getProperty('cpuControlled') then
			if (score < 0 or getHealth() < 0.4) and not red then
				red = true
				cancelTween('sttcb')
				doTweenColor('sttcr', 'scoreTxtThing', 'ff3b3b', 0.4, 'sineOut')
			elseif score > 0 and getHealth() > 0.4 and red then
				red = false
				cancelTween('sttcr')
				doTweenColor('sttcb', 'scoreTxtThing', 'ffffff', 0.4, 'sineIn')
			end
		end

		setProperty('scoreTxtThing.y', getProperty('scoreTxt.y') - 6)
		setProperty('scoreTxtThing.scale.x', getProperty('scoreTxt.scale.x'))
		setProperty('scoreTxtThing.scale.y', getProperty('scoreTxt.scale.y'))
		setProperty('scoreTxtThing.alpha', getProperty('scoreTxt.alpha'))

		if alert then
			setProperty('healthAlert.x', getProperty('iconP1.x') + 135)
			setProperty('healthAlert.y', getProperty('healthBar.y') - 28)
		end
	end
end

--[[
function firstToUpper(str) return str:gsub("^%l", string.upper) end
function titleStuff(str)
	if string.find(str, "-") then
		local arr = stringSplit(str, '-')
		local final = ''
		for i = 1, #arr do
			final = final..firstToUpper(arr[i])
			if i < #arr then final = final..' ' end
		end

		return final
	end

	return firstToUpper(str)
end
]]--