local menu = true
local optionButtons = {}
local buttons = {}
local pusOpt2Buttons = {}
local bcategory = {}
local msgs = {}

function onCreate()
	menu = stringStartsWith(songName, 'Menu')
	if menu then
		close()
		return
	end

	precacheSound('scrollMenu')
	precacheSound('cancelMenu')
	precacheMusic('uhhhhh')

	makeLuaSprite('pusBG')
	makeGraphic('pusBG', screenWidth, screenHeight, '000000')
	setProperty('pusBG.alpha', 0) -- 0.8
	setProperty('pusBG.visible', false)
	addLuaSprite('pusBG')

	makeLuaSprite('pusGrad', 'pause/gradient')
	setProperty('pusGrad.color', getColorFromHex('000000'))
	setProperty('pusGrad.alpha', 0) -- 0.5
	setProperty('pusGrad.visible', false)
	addLuaSprite('pusGrad')

	makeLuaSprite('pusCheck', 'menu/checkered', -250)
	setProperty('pusCheck.alpha', 0) -- 0.35
	setProperty('pusCheck.visible', false)
	addLuaSprite('pusCheck')

	local aa = getPropertyFromClass('backend.ClientPrefs', 'data.antialiasing')
	local textyaa = function(tag, text, y, category)
		makeLuaText(tag, text, 0, 0, y)
		setTextFont(tag, 'fnf.ttf')
		setTextSize(tag, 46)
		setTextAlignment(tag, 'center')
		setTextBorder(tag, 0, '000000', '')
		screenCenter(tag, 'x')
		setProperty(tag..'.antialiasing', aa)
		setProperty(tag..'.alpha', 0)
		setProperty(tag..'.visible', false)
		addLuaText(tag)

		table.insert(category, tag)
	end

	textyaa('pusResume', 'RESUME', 133.5, buttons)
	textyaa('pusRestart', 'RESTART SONG', 233.5, buttons)
	textyaa('pusOptions', 'OPTIONS', 333.5, buttons)
	textyaa('pusView', 'VIEW PAUSED GAME', 433.5, buttons)
	textyaa('pusExit', 'EXIT TO MENU', 533.5, buttons)

	bcategory = buttons

	textyaa('pusOpt1', 'AMIGOS MOD OPTIONS', 283.5, optionButtons)
	textyaa('pusOpt2', 'PSYCH ENGINE OPTIONS', 383.5, optionButtons)



	makeLuaText('pusOpt2Txt', "Since I can't actually figure out how to send you to the Psych Engine Options, I'm just gonna send you to the Psych Engine freeplay.\n\n            -LonliHH", 680, 0, 257)
	setTextSize('pusOpt2Txt', 30)
	setTextAlignment('pusOpt2Txt', 'center')
	screenCenter('pusOpt2Txt', 'x')
	setProperty('pusOpt2Txt.antialiasing', false)
	setProperty('pusOpt2Txt.borderSize', 2.5)
	setProperty('pusOpt2Txt.wordWrap', true)
	setProperty('pusOpt2Txt.alpha', 0)
	setProperty('pusOpt2Txt.visible', false)
	addLuaText('pusOpt2Txt')

	makeLuaText('pusOpt2Opt1', '[Nvm, go back]', 0, 467, 458)
	setTextSize('pusOpt2Opt1', 22)
	setTextAlignment('pusOpt2Opt1', 'center')
	setProperty('pusOpt2Opt1.antialiasing', false)
	setProperty('pusOpt2Opt1.borderSize', 2)
	setProperty('pusOpt2Opt1.alpha', 0)
	setProperty('pusOpt2Opt1.visible', false)
	addLuaText('pusOpt2Opt1')
	table.insert(pusOpt2Buttons, 'pusOpt2Opt1')

	makeLuaText('pusOpt2Opt2', '[Ok]', 0, 702, 458)
	setTextSize('pusOpt2Opt2', 22)
	setTextAlignment('pusOpt2Opt2', 'center')
	setProperty('pusOpt2Opt2.antialiasing', false)
	setProperty('pusOpt2Opt2.borderSize', 2)
	setProperty('pusOpt2Opt2.alpha', 0)
	setProperty('pusOpt2Opt2.visible', false)
	addLuaText('pusOpt2Opt2')
	table.insert(pusOpt2Buttons, 'pusOpt2Opt2')

	

	makeLuaSprite('pusSelect', nil, 0, getProperty(buttons[1]..'.y'))
	makeGraphic('pusSelect', screenWidth, 90, '4f4f4f')
	setProperty('pusSelect.alpha', 0) -- 0.2
	setProperty('pusSelect.visible', false)
	addLuaSprite('pusSelect')

	makeLuaSprite('pusUpBar', nil, 0, -110)
	makeGraphic('pusUpBar', screenWidth, 110, '000000')
	setProperty('pusUpBar.alpha', 0.4)
	setProperty('pusUpBar.visible', false)
	addLuaSprite('pusUpBar')

	makeLuaSprite('pusLowBar', nil, 0, screenHeight + 110)
	makeGraphic('pusLowBar', screenWidth, 110, '000000')
	setProperty('pusLowBar.alpha', 0.4)
	setProperty('pusLowBar.visible', false)
	addLuaSprite('pusLowBar')

	local daDeaths = getPropertyFromClass('states.PlayState', 'deathCounter')
	setVar('am.deaths', daDeaths)
	makeLuaText('pusSongTxt', 'Playing: '..songName..'\nDeaths: '..daDeaths, 0, 12, 12)
	setTextSize('pusSongTxt', 26)
	setTextAlignment('pusSongTxt', 'left')
	setProperty('pusSongTxt.antialiasing', false)
	setProperty('pusSongTxt.borderSize', 0)
	setProperty('pusSongTxt.alpha', 0)
	setProperty('pusSongTxt.visible', false)
	addLuaText('pusSongTxt')

	makeLuaText('pusLowTxt', '', 1280, -12, screenHeight - 67)
	setTextSize('pusLowTxt', 26)
	setTextAlignment('pusLowTxt', 'right')
	setProperty('pusLowTxt.antialiasing', false)
	setProperty('pusLowTxt.borderSize', 0)
	setProperty('pusLowTxt.alpha', 0)
	setProperty('pusLowTxt.visible', false)
	addLuaText('pusLowTxt')

	makeLuaText('pusViewTxt', 'Press [BACK] to go back', 0, 0, screenHeight - 120)
	setTextSize('pusViewTxt', 20)
	setTextAlignment('pusViewTxt', 'center')
	screenCenter('pusViewTxt', 'x')
	setProperty('pusViewTxt.antialiasing', false)
	setProperty('pusViewTxt.borderSize', 2)
	setProperty('pusViewTxt.alpha', 0)
	setProperty('pusViewTxt.visible', false)
	addLuaText('pusViewTxt')

	makeLuaText('pusDebugTxt', 'yes', 0, 0, 24)
	setTextSize('pusDebugTxt', 26)
	setTextAlignment('pusDebugTxt', 'center')
	setProperty('pusDebugTxt.antialiasing', false)
	setProperty('pusDebugTxt.borderSize', 0)
	setProperty('pusDebugTxt.alpha', 0)
	setProperty('pusDebugTxt.visible', false)
	addLuaText('pusDebugTxt')

	makeLuaSprite('blakkk')
	makeGraphic('blakkk', screenWidth, screenHeight, '000000')
	setProperty('blakkk.alpha', 0)
	setProperty('blakkk.visible', false)
	setObjectOrder('blakkk', getObjectOrder('pusViewTxt') + 10)
	addLuaSprite('blakkk')

	runHaxeCode([[
		var camPause = new FlxCamera();
		camPause.bgColor = 0x00;

		game.variables.set('camPause', camPause);
		FlxG.cameras.add(camPause, false);

		game.getLuaObject('pusBG').camera = camPause;
		game.getLuaObject('pusGrad').camera = camPause;
		game.getLuaObject('pusCheck').camera = camPause;
		game.getLuaObject('pusSelect').camera = camPause;

		game.getLuaObject('pusResume').camera = camPause;
		game.getLuaObject('pusRestart').camera = camPause;
		game.getLuaObject('pusOptions').camera = camPause;
		game.getLuaObject('pusView').camera = camPause;
		game.getLuaObject('pusExit').camera = camPause;

		game.getLuaObject('pusOpt1').camera = camPause;
		game.getLuaObject('pusOpt2').camera = camPause;

		game.getLuaObject('pusOpt2Txt').camera = camPause;
		game.getLuaObject('pusOpt2Opt1').camera = camPause;
		game.getLuaObject('pusOpt2Opt2').camera = camPause;

		game.getLuaObject('pusUpBar').camera = camPause;
		game.getLuaObject('pusLowBar').camera = camPause;

		game.getLuaObject('pusSongTxt').camera = camPause;
		game.getLuaObject('pusLowTxt').camera = camPause;
		game.getLuaObject('pusViewTxt').camera = camPause;

		game.getLuaObject('pusDebugTxt').camera = camPause;
		game.getLuaObject('blakkk').camera = camPause;

		// rearranging cams
		var camLoadScreen;
		if ((camLoadScreen = game.variables.get('camLoadScreen')) != null) {
			FlxG.cameras.remove(camLoadScreen, false);
			FlxG.cameras.add(camLoadScreen, false);
		}





		function findScript(scriptFile:String, ?ext:String):String {
			if (ext == null) ext = '.lua';

			if (scriptFile.substr(-ext.length) != ext) scriptFile += ext;
			if (FileSystem.exists(scriptFile)) return scriptFile;

			var path:String = Paths.modFolders(scriptFile);
			if (FileSystem.exists(path)) return path;

			var preloadPath:String = Paths.getPreloadPath(scriptFile);
			if (FileSystem.exists(preloadPath)) return preloadPath;

			return null;
		}

		var cdLuaPath = findScript('scripts/bbbcountdown.lua');
		var cdScript = null;
		if (cdLuaPath != null) {
			for (luaInstance in game.luaArray) {
				if (luaInstance.scriptName == cdLuaPath) {
					cdScript = luaInstance;
					break;
				}
			}
		}

		if (cdScript == null) debugPrint("Couldn't find countdown script :(");

		function continueFromAMPause():Void {
			cdScript.call('continueFromAMPause', []);
		}

		createCallback('continueCountdown', continueFromAMPause);
	]])

	msgs = getDataFromSave('amcache', 'pause_msgs', nil)
	if msgs == nil then
		triggerEvent('error msg', getVar('am.errh.msg'):gsub('%[sillyfile%]', 'lonlihh/pause_msgs.txt')..'\nNo more inspirational quotes :(;'..getVar('am.errh.title'), 'ok')
		msgs = {
			"WHAT HAPPENED??",
			"erm why do i feel empty",
			"why can't i remember any of their quotes",
			"what did u do?",
			"u messed with something didnt u",
			"fix me :(",
			"i don't feel like dropping any fire quotes rn idk why"
		}
	end
end

local firstTimePause = true
local paused = false
local selectable = false
local viewing = false
local selectOptions = false
local selectPusOpt2 = false
local selected = 1
local fadeTime = 0.25
local tweenTime = 0.3

function onPause()
	if not menu then
		paused = true
		openCustomSubstate('amigosPause', true)
	end

	return Function_Stop
end

function onCreatePost()
	if not menu and getDataFromSave('lonlihh', 'botplayDone', false) then
		setDataFromSave('lonlihh', 'botplayDone', false)
		runTimer('forcePause', 0.1)
	end
end

function onCustomSubstateCreate(name)
	if name ~= 'amigosPause' then return end

	debugKeysInit()

	if firstTimePause then
		firstTimePause = false
		playLoopingSound('amPauseMusic', 'uhhhhh')
	else resumeSound('amPauseMusic') end

	local oldFadeTime = nil
	if luaSpriteExists('lsc') and getProperty('lsc.alpha') > 0 then
		oldFadeTime = fadeTime
		fadeTime = 0.01
		local lft = getVar('am.loadScreen.fadeTime')

		cancelTween('loadFadeOut')
		doTweenAlpha('loadFadeOut', 'lsc', 0, lft, 'sineOut')
		
		if luaTextExists('loadTxt') then
			cancelTween('loadTxtFadeOut')
			doTweenAlpha('loadTxtFadeOut', 'loadTxt', 0, lft, 'sineOut')
		end
	end

	soundFadeIn('amPauseMusic', 15, 0, 1)
	runTimer('pus_selectable', fadeTime)
	doTweenColor('pauseGradColor', 'pusGrad', '000000', 0.5, 'sineInOut')
	fadeIn(fadeTime)
	setTextString('pusLowTxt', 'Pause Music: "Uhhhhh" - MarStarBro\n'..msgs[getRandomInt(1, #msgs)])

	if oldFadeTime ~= nil then fadeTime = oldFadeTime end
end

function fadeLoadScreen(func)
	selectable = false
	setVar('am.loadScreen.function', func)

	local lftime = getVar('am.loadScreen.fadeTime')

	soundFadeOut('amPauseMusic', lftime - 0.05, 0)
	runTimer('stopPauseMusic', lftime - 0.05, 0)
	doTweenAlpha('loadFadeIn', 'lsc', 1, lftime, 'sineOut')
end



local isDebugMode
local debugKeys = {'D','E','B','U','G','M','O','D','E'}
local pressedDebugKeys = 0

local isBotplay
local botplayKeys = {'B','O','T','P','L','A','Y'}
local pressedBotplayKeys = 0

function debugKeysInit()
	isDebugMode = getVar('debugKeys_enabled')
	isBotplay = getProperty('cpuControlled')
end

function debugKeysUpdate()
	if pressedDebugKeys == #debugKeys then
		isDebugMode = not isDebugMode
		pressedDebugKeys = 0
		local snd = 'dialogueClose'

		if isDebugMode then
			snd = 'clickText'
			enableDebugKeys()
		else disableDebugKeys() end

		playSound(snd)
		debugTxtPop('DEBUG MODE: '..boolthing(isDebugMode), fadeTime)
		setVar('debugKeys_enabled', isDebugMode)
	else
		local nextKey = debugKeys[pressedDebugKeys + 1]
		if keyboardJustPressed(nextKey) then pressedDebugKeys = pressedDebugKeys + 1 end
	end

	if pressedBotplayKeys == #botplayKeys then
		isBotplay = not isBotplay
		pressedBotplayKeys = 0
		setProperty('cpuControlled', isBotplay)
		setProperty('botplayTxt.visible', isBotplay)

		local snd = 'dialogueClose'
		if isBotplay then snd = 'clickText' end

		playSound(snd)
		debugTxtPop('BOTPLAY: '..boolthing(isBotplay), fadeTime)
	else
		local nextKey = botplayKeys[pressedBotplayKeys + 1]
		if keyboardJustPressed(nextKey) then pressedBotplayKeys = pressedBotplayKeys + 1 end
	end
end



--[[
function coolResumeFunc()
	paused = false
	selectable = false
	selected = 1

	if isBotplay then setVar('wasBotplay', isBotplay) end

	fadeOut(fadeTime / 2)
	soundFadeOut('amPauseMusic', fadeTime / 2, 0)
	runTimer('pausePauseMusic', fadeTime / 2)
	resetStrumAnims()
	callOnScripts('onAmigosResume')
	closeCustomSubstate()
end
]]--

function coolResumeFunc()
	paused = false
	selectable = false
	selected = 1

	if isBotplay then setVar('wasBotplay', isBotplay) end

	local dur = fadeTime / 2
	fadeOut(dur)
	soundFadeOut('amPauseMusic', dur, 0)
	runTimer('pausePauseMusic', dur)
	resetStrumAnims()
	callOnScripts('onAmigosResume')
	
	if getDataFromSave('lonlihh', 'continueCD') then continueCountdown() else closeCustomSubstate() end
end

function onCustomSubstateUpdate(name, elapsed)
	if name ~= 'amigosPause' then return end

	if getProperty('pusCheck.x') >= 0 then setProperty('pusCheck.x', -200)
	else setProperty('pusCheck.x', getProperty('pusCheck.x') + 100 * elapsed) end

	if selectable then
		if keyJustPressed('accept') then
			local button = bcategory[selected]

			if button == 'pusResume' then coolResumeFunc()
			elseif button == 'pusRestart' then fadeLoadScreen('restartSong')
			elseif button == 'pusOptions' then
				selectOptions = true
				selected = 1
				bcategory = optionButtons

				setProperty('pusViewTxt.alpha', 0.6)
				playSound('scrollMenu')
				updateMenu()

				for i = 1, #buttons do setProperty(buttons[i]..'.visible', false) end
				for i = 1, #optionButtons do
					setProperty(optionButtons[i]..'.alpha', 1)
					setProperty(optionButtons[i]..'.visible', true)
				end
			elseif button == 'pusView' then
				selectable = false
				viewing = true
				fadeOut(fadeTime)
				setProperty('pusViewTxt.visible', true)
				doTweenAlpha('pusViewTxta', 'pusViewTxt', 0.6, fadeTime, 'sineIn')
			elseif button == 'pusExit' then
				isBotplay = false
				setVar('wasBotplay', isBotplay)
				fadeLoadScreen('exitToMenu')
			elseif button == 'pusOpt1' then fadeLoadScreen('toOptions')
			elseif button == 'pusOpt2' then
				selectOptions = false
				selectPusOpt2 = true
				bcategory = pusOpt2Buttons
				selected = 1

				for i = 1, #optionButtons do setProperty(optionButtons[i]..'.visible', false) end
				for i = 1, #pusOpt2Buttons do
					setProperty(pusOpt2Buttons[i]..'.alpha', 1)
					setProperty(pusOpt2Buttons[i]..'.visible', true)
				end

				doTweenY('pusSelectsy', 'pusSelect.scale', 0.7, fadeTime / 2, 'circOut')
				doTweenY('pusSelectoy', 'pusSelect.offset', 11, fadeTime / 2, 'circOut')
				setProperty('pusOpt2Txt.alpha', 1)
				setProperty('pusOpt2Txt.visible', true)
				setProperty('pusViewTxt.alpha', 0)
				playSound('scrollMenu')
				updateMenu()
			elseif button == 'pusOpt2Opt1' then pusOpt2Back()
			elseif button == 'pusOpt2Opt2' then
				selectable = false
				isBotplay = false
				setVar('wasBotplay', isBotplay)
				setProperty('blakkk.visible', true)
				soundFadeOut('amPauseMusic', fadeTime - 0.1, 0)
				doTweenAlpha('blakkka', 'blakkk', 1, fadeTime, 'sineOut')
				flushSaveData('lonlihh')
				flushSaveData('amstats')
			end
		elseif keyJustPressed('down') or (selectPusOpt2 and keyJustPressed('right')) then
			selected = selected + 1
			if selected > #bcategory then selected = 1 end

			updateMenu()
			playSound('scrollMenu')
		elseif keyJustPressed('up') or (selectPusOpt2 and keyJustPressed('left')) then
			selected = selected - 1
			if selected < 1 then selected = #bcategory end

			updateMenu()
			playSound('scrollMenu')
		elseif keyJustPressed('back') then
			if selectOptions then
				selectOptions = false
				selected = 3
				bcategory = buttons

				setProperty('pusViewTxt.alpha', 0)
				playSound('cancelMenu')
				updateMenu()

				for i = 1, #buttons do setProperty(buttons[i]..'.visible', true) end
				for i = 1, #optionButtons do
					setProperty(optionButtons[i]..'.alpha', 0)
					setProperty(optionButtons[i]..'.visible', false)
				end
			elseif selectPusOpt2 then pusOpt2Back()
			else coolResumeFunc() end
		else debugKeysUpdate() end
	elseif viewing and keyJustPressed('back') then
		selectable = true
		viewing = false
		fadeIn(fadeTime)
		onTweenCompleted('pauseGradColor')
		doTweenAlpha('pusViewTxta', 'pusViewTxt', 0, fadeTime, 'sineOut')
	end
end

function boolthing(cool)
	if cool then return 'ON' end
	return 'OFF'
end

function debugTxtPop(str, dur)
	setTextString('pusDebugTxt', '['..str..']')
	screenCenter('pusDebugTxt', 'x')
	setProperty('pusDebugTxt.visible', true)
	setProperty('pusDebugTxt.alpha', 1)
	scaleObject('pusDebugTxt', 1.2, 1.2)
	doTweenX('debugTxtsx', 'pusDebugTxt.scale', 1, dur * 2, 'circOut')
	doTweenY('debugTxtsy', 'pusDebugTxt.scale', 1, dur * 2, 'circOut')
	doTweenAlpha('debugTxta', 'pusDebugTxt', 0, dur * 4, 'sineOut')
end

function pusOpt2Back()
	selectPusOpt2 = false
	selectOptions = true
	selected = 2
	bcategory = optionButtons

	doTweenY('pusSelectsy', 'pusSelect.scale', 1, fadeTime / 2, 'circOut')
	doTweenY('pusSelectoy', 'pusSelect.offset', 0, fadeTime / 2, 'circOut')
	setProperty('pusOpt2Txt.alpha', 0)
	setProperty('pusOpt2Txt.visible', false)
	setProperty('pusViewTxt.alpha', 0.6)
	playSound('cancelMenu')
	updateMenu()

	for i = 1, #optionButtons do setProperty(optionButtons[i]..'.visible', true) end
	for i = 1, #pusOpt2Buttons do
		setProperty(pusOpt2Buttons[i]..'.alpha', 0)
		setProperty(pusOpt2Buttons[i]..'.visible', false)
	end
end

function updateMenu()
	setpos('pusSelect', nil, getProperty(bcategory[selected]..'.y') - 20, tweenTime, 'circOut')

	for i = 1, #bcategory do
		if i == selected then tweenScale(bcategory[i], 1.25, tweenTime, 'circOut')
		else tweenScale(bcategory[i], 1, tweenTime, 'quadOut') end
	end
end

function onTimerCompleted(t, l, ll)
	if t == 'forcePause' then onPause() end

	if t == 'stopPauseMusic' then stopLoopingSound('amPauseMusic') end
	if t == 'pausePauseMusic' then pauseSound('amPauseMusic') end

	if menu or not paused then return end

	if t == 'pus_selectable' then
		selectable = true
		updateMenu()
	end
end

function onTweenCompleted(t)
	if menu then return end

	if paused then
		if t == 'pauseGradColor' then doTweenColor('pauseGradColor', 'pusGrad', randomHex(), 5, 'sineInOut') end

		if t == 'upPusBarIn' then doTweenAlpha('songPusTxtIn', 'pusSongTxt', 1, fadeTime, 'sineOut') end
		if t == 'lowPusBarIn' then doTweenAlpha('lowPusTxtIn', 'pusLowTxt', 1, fadeTime, 'sineOut') end

		if t == 'blakkka' then
			setPropertyFromClass('states.PlayState', 'deathCounter', 0)
			exitSong(false)
		end
	end

	if t == 'debugTxta' then setProperty('pusDebugTxt.visible', false) end

	if t == 'upPusBarOut' then setProperty('pusUpBar.visible', false) end
	if t == 'lowPusBarOut' then setProperty('pusLowBar.visible', false) end

	if stringStartsWith(t, 'fadeOut') then setProperty(string.sub(t, 8, string.len(t))..'.visible', false) end
end

function fadeIn(time)
	local daFade = function(tag, alpha)
		setProperty(tag..'.visible', true)
		doTweenAlpha(tag..'fadeIn', tag, alpha, time, 'sineOut')
	end

	daFade('pusBG', 0.8)
	daFade('pusGrad', 0.5)
	daFade('pusCheck', 0.35)
	daFade('pusSelect', 0.2)
	for i = 1, #buttons do daFade(buttons[i], 1) end

	setProperty('pusViewTxt.visible', true)
	setProperty('pusSongTxt.visible', true)
	setProperty('pusLowTxt.visible', true)

	setProperty('pusUpBar.visible', true)
	setProperty('pusLowBar.visible', true)
	doTweenY('upPusBarIn', 'pusUpBar', -30, time + 0.3, 'backOut')
	doTweenY('lowPusBarIn', 'pusLowBar', screenHeight - 80, time + 0.3, 'backOut')
end

function fadeOut(time)
	setProperty('pusViewTxt.visible', false)
	cancelTween('pauseGradColor')

	local daFade = function(tag)
		doTweenAlpha('fadeOut'..tag, tag, 0, time, 'sineIn')
	end

	daFade('pusBG')
	daFade('pusGrad')
	daFade('pusCheck')
	daFade('pusSelect')
	daFade('pusSongTxt')
	daFade('pusLowTxt')
	for i = 1, #buttons do daFade(buttons[i]) end

	cancelTween('upPusBarIn')
	cancelTween('lowPusBarIn')
	doTweenY('upPusBarOut', 'pusUpBar', -110, time + 0.1, 'quadIn')
	doTweenY('lowPusBarOut', 'pusLowBar', screenHeight + 110, time + 0.1, 'quadIn')
end



--[[
local hexSymbols = {'a','b','c','d','e','f','0','1','2','3','4','5','6','7','8','9'}
function randomHex()
	local hex = 'ff'
	for i = 1,4 do
		hex = hex..hexSymbols[getRandomInt(1, #hexSymbols)]
	end

	return hex
end]]--

function randomHex()
	local r, g, b
	repeat
		r = getRandomInt(15, 255)
		g = getRandomInt(15, 255)
		b = getRandomInt(15, 255)
	until (r > 15 or g > 15 and b > 15) and (r ~= g and g ~= b and r ~= b)

	return string.format("%02X%02X%02X", r, g, b)
end












-------------------- LAZY STUFF --------------------

-- addpos() removed bc unused

function setpos(obj, x, y, dur, ease)
	if x ~= nil and getProperty(obj..'.x') ~= x then doTweenX('x'..obj, obj, x, dur, ease) end
	if y ~= nil and getProperty(obj..'.y') ~= y then doTweenY('y'..obj, obj, y, dur, ease) end
end

function tweenScale(obj, scale, dur, ease)
	if getProperty(obj..'.scale.x') ~= scale then doTweenX('sx'..obj, obj..'.scale', scale, dur, ease) end
	if getProperty(obj..'.scale.y') ~= scale then doTweenY('sy'..obj, obj..'.scale', scale, dur, ease) end
end

----------------------------------------------------