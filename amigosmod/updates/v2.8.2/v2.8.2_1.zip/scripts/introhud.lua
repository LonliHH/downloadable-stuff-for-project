local enabled = false
local unready = {7,6,5,4,3,2,1,0}
local ay = 0
local y = -80

function onCreatePost()
	enabled = not stringStartsWith(songName, 'Menu') and not checkFileExists('data/'..string.lower(songName):gsub('%s', '-')..'/disableINS.txt')
	if not enabled then
		close()
		return
	end

	if downscroll then y = -y end

	setProperty('healthBar.y', getProperty('healthBar.y') - y)
	setProperty('healthBar.alpha', 0)
	setProperty('scoreTxt.y', getProperty('scoreTxt.y') - y)
	setProperty('scoreTxt.alpha', 0)
	
	for i = 1,2 do
		setProperty('iconP'..i..'.y', getProperty('iconP'..i..'.y') - y)
		setProperty('iconP'..i..'.alpha', 0)
	end
end

function onCountdownStarted()
	if not enabled then return end

	ay = y
	if not isStoryMode then ay = ay*2 end
	for i = 0, getProperty('strumLineNotes.length') - 1 do
		setPropertyFromGroup('strumLineNotes', i, 'y', getPropertyFromGroup('strumLineNotes', i, 'y') + ay)
		--if isStoryMode then setPropertyFromGroup('strumLineNotes', i, 'alpha', 0) end
	end
end

function onSongStart()
	runTimer('intstrum', 0.06, 8)
	
	doTweenY('intro_hby', 'healthBar', getProperty('healthBar.y') + y, 0.5, 'backOut')
	doTweenAlpha('intro_hba', 'healthBar', 1, 0.5, 'sineOut')
	doTweenY('intro_sty', 'scoreTxt', getProperty('scoreTxt.y') + y, 0.5, 'backOut')
	doTweenAlpha('intro_sta', 'scoreTxt', 1, 0.5, 'sineOut')
	
	for i = 1,2 do
		doTweenY('intro_ip'..i, 'iconP'..i, getProperty('iconP'..i..'.y') + y, 0.5, 'backOut')
		doTweenAlpha('intro_ipa'..i, 'iconP'..i, 1, 0.5, 'sineOut')
	end
end

function onTimerCompleted(t, l, ll)
	if t == 'intstrum' then
		local i = unready[ll + 1]
		table.remove(unready, ll + 1)
		noteTweenY('introstrum'..i, i, getPropertyFromGroup('strumLineNotes', i, 'y') - ay, 0.6, 'backOut')
		--if isStoryMode then noteTweenAlpha('introstrumA'..i, i, 1, 0.6, 'sineOut') end
	end
end