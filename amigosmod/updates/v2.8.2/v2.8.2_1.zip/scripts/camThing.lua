-- by LonliHH

local allowed = true
local lastMHS = nil
local isIdle = false
local off = 25
local bx = 0
local by = 0
local dx = 0
local dy = 0

function onCreate()
	if stringStartsWith(songName, 'Menu') or checkFileExists('data/'..string.lower(songName):gsub('%s', '-')..'/forcedcam.txt') then close() end
end

function onCreatePost()
	bfOffsets(boyfriendName)
	dadOffsets(dadName)
end

function bfOffsets(bf)
	bx = getProperty('boyfriend.x') - 20
	by = getProperty('boyfriend.y') + 60

	if bf == 'lonliRoblox' then
		bx = bx + 180
		by = by + 390
	end
end

function dadOffsets(dad)
	dx = getProperty('dad.x') + 400
	dy = getProperty('dad.y') + 240

	if dad == 'dusgee' then
		dx = dx + 400
		dy = dy + 780
	elseif dad == 'duskyRoblox' then
		dx = dx - 120
		dy = dy + 40
	elseif dad == 'raven' then
		dy = dy - 100
	end
end

function onEvent(n, v1, v2)
	if n == 'Change Character' then
		if v1 == 'BF' then bfOffsets(v2)
		elseif v1 == 'Dad' then dadOffsets(v2) end
	end

	if n == 'se' then
		if v1 == 'camThing' then allowed = v2 == '1'
		elseif v1 == 'camThing_off' then off = tonumber(v2)
		elseif v1 == 'camThing_force' then
			local force = stringSplit(v2, ',')
			local cx = dx
			local cy = dy

			if force[1] == 'bf' then
				cx = bx
				cy = by
			end

			local posx = cx
			local posy = cy
			if force[2] == '0' then posx = cx - off
			elseif force[2] == '1' then posy = cy + off
			elseif force[2] == '2' then posy = cy - off
			elseif force[2] == '3' then posx = cx + off end

			cancelTimer('followCamBack')
			fcam(cx, cy)
		end
	end
end

function onBeatHit()
	if allowed and curBeat % 4 == 0 and (lastMHS == nil or lastMHS ~= mustHitSection) and isIdle then
		lastMHS = mustHitSection
		onTimerCompleted('followCamBack', 0, 0)
	end
end

function opponentNoteHit(i, d, t, s) hit(i, d, false) end
function goodNoteHit(i, d, t, s) hit(i, d, true) end

function hit(i, d, p)
	if allowed and (mustHitSection == p) and not getPropertyFromGroup('notes', i, 'ignoreNote') and not getPropertyFromGroup('notes', i, 'hitCausesMiss') and not getPropertyFromGroup('notes', i, 'noAnimation') then
		local cx
		local cy

		if p then
			cx = bx
			cy = by
		else
			cx = dx
			cy = dy
		end

		if d == 0 then fcam(cx - off, cy)
		elseif d == 1 then fcam(cx, cy + off)
		elseif d == 2 then fcam(cx, cy - off)
		elseif d == 3 then fcam(cx + off, cy) end

		cancelTimer('followCamBack')
		runTimer('followCamBack', (stepCrochet / 1000) * 6.1)

		isIdle = false
	end
end

function fcam(x, y)
	triggerEvent('Camera Follow Pos', x, y)
	setProperty('isCameraOnForcedPos', true)
end

function onTimerCompleted(t, l, ll)
	if allowed and t == 'followCamBack' then
		if mustHitSection then fcam(bx, by)
		else fcam(dx, dy) end

		isIdle = true
	end
end