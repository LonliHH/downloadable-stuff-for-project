local allow = false
local pauseMode = false
local dur

function onCreate()
	if stringStartsWith(songName, 'Menu') then
		close()
		return
	end

	dur = crochet / 1000

	setProperty('skipCountdown', true)

	precacheImage('ready')
	precacheImage('set')
	precacheImage('go')
end

function onStartCountdown()
	if not allow then
		runTimer('amBeforeCD', dur / getProperty('playbackRate'))
		callOnLuas('onCountdownStarted')
		return Function_Stop
	end

	allow = false
	return Function_Continue
end

function onTimerCompleted(t, l, ll)
	if t == 'amBeforeCD' then
		runTimer('amCD', dur / getProperty('playbackRate'), 3)
		onTimerCompleted('amCD', 0, 3)
	end

	if t == 'amCD' then
		if ll > 0 then
			playSound('intro'..ll)

			local tick = 3 - ll
			if not pauseMode then callOnLuas('onCountdownTick', {tick}) end
			onCountdownTick(tick)
		else
			playSound('introGo')
			runTimer('amCDgo', dur / getProperty('playbackRate'))

			if not pauseMode then callOnLuas('onCountdownTick', {3}) end
			onCountdownTick(3)
		end
	end

	if t == 'amCDgo' then
		allow = true
		if pauseMode then
			closeCustomSubstate()
			pauseMode = false
		else startCountdown() end
	end

	if t == 'teehee' then
		debugPrint('done')
		closeCustomSubstate()
	end
end

function continueFromAMPause()
	pauseMode = true
	runTimer('amBeforeCD', dur)
end

function onCountdownTick(c)
	if c == 1 then coolCounter('ready')
	elseif c == 2 then coolCounter('set')
	elseif c == 3 then coolCounter('go') end
end

function coolCounter(name)
	if luaSpriteExists('counter') then removeLuaSprite('counter', true) end

	makeLuaSprite('counter', name)
	setObjectCamera('counter', 'camOther')
	screenCenter('counter', 'xy')
	setProperty('counter.scale.x', 1.2)
	setProperty('counter.scale.y', 1.2)
	addLuaSprite('counter')

	local cooldur = dur / getProperty('playbackRate')
	doTweenAlpha('countera', 'counter', 0, cooldur, 'quadIn')
	doTweenX('countersx', 'counter.scale', 1, cooldur, 'circOut')
	doTweenY('countersy', 'counter.scale', 1, cooldur, 'circOut')
end