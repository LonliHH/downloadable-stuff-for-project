local enabled = false

function onCreate()
	initSaveData('lonlihh', 'amigosmod')

	enabled = not stringStartsWith(songName, 'Menu')
	if enabled then
		makeLuaSprite('lsc', getDataFromSave('lonlihh', 'loadScreen'))
		setProperty('lsc.antialiasing', false)
		addLuaSprite('lsc')

		local msg = getDataFromSave('lonlihh', 'lastLoadTxt', nil)
		if msg ~= nil then
			makeLuaText('loadTxt', msg, 0, 10, screenHeight - 30)
			setTextSize('loadTxt', 20)
			setTextAlignment('loadTxt', 'left')
			setProperty('loadTxt.antialiasing', false)
			setProperty('loadTxt.borderSize', 2)
			addLuaText('loadTxt')
			setDataFromSave('lonlihh', 'lastLoadTxt', nil)
			setDataFromSave('lonlihh', 'avoidLoadTxt', msg)
		end

		runHaxeCode([[
			var coolCam = new FlxCamera();
			coolCam.bgColor = 0x00;

			game.variables.set('camLoadScreen', coolCam);
			FlxG.cameras.add(coolCam, false);

			game.getLuaObject('lsc').camera = coolCam;

			var loadTxt = game.getLuaObject('loadTxt');
			if (loadTxt != null) loadTxt.camera = coolCam;
		]])

		setLSVar('fadeTime', 0.6)
		setLSVar('function', 'none')
	else close() end
end

function onCreatePost()
	if enabled then
		local lft = getLSVar('fadeTime')

		doTweenAlpha('loadFadeOut', 'lsc', 0, lft, 'sineOut')
		if luaTextExists('loadTxt') then doTweenAlpha('loadTxtFadeOut', 'loadTxt', 0, lft, 'sineOut') end
	end
end

function onTweenCompleted(t)
	if t == 'loadFadeIn' then
		local func = getLSVar('function')

		if func == 'restartSong' then triggerEvent('restartSong')
		elseif func == 'exitToMenu' then
			setDataFromSave('lonlihh', 'menuLoadIn', true)
			setDataFromSave('lonlihh', 'lastScene', 'freeplay')
			loadSong('menu', -1)
		elseif func == 'toOptions' then
			setDataFromSave('lonlihh', 'menuLoadIn', true)
			setDataFromSave('lonlihh', 'lastScene', 'options')
			setDataFromSave('lonlihh', 'prev.enabled', true)
			loadSong('menu', -1)
		end
	end

	if t == 'loadTxtFadeOut' then removeLuaText('loadTxt', true) end
end

function setLSVar(tag, var) setVar('am.loadScreen.'..tag, var) end
function getLSVar(tag) return getVar('am.loadScreen.'..tag) end