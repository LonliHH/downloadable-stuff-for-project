-- by LonliHH

local enabled = false
local optimized = false
local objOrder = -1
local noBorder = false
local aa = false
local offX = -15
local y, ay
local sustainCombos = {}
local playerCombos = {}

function onCreate()
	setProperty('showComboNum', false)
	initSaveData('lonlihh', 'amigosmod')
	enabled = getDataFromSave('lonlihh', 'optCombo') and not stringStartsWith(songName, 'Menu')

	if enabled then
		aa = getPropertyFromClass('backend.ClientPrefs', 'data.antialiasing')
		optimized = getDataFromSave('lonlihh', 'optimizeMod')
	else close() end
end

function onCreatePost()
	if enabled then
		noBorder = getVar('am.forceCopyFont.noBorder')

		y = -70
		ay = -5
		if downscroll then
			y = -y
			ay = ay + 35
		end
	end
end

local oppCombo, gfCombo = 0, 0

function silly(id, dir, sus)
	if enabled and not sus and not getPropertyFromGroup('notes', id, 'ignoreNote') and not getPropertyFromGroup('notes', id, 'hitCausesMiss') then
		local type = getPropertyFromGroup('notes', id, 'gfNote') and 'GF' or (getPropertyFromGroup('notes', id, 'mustPress') and 'PLR' or 'OPP')

		local daCombo
		if type == 'PLR' then daCombo = getProperty('combo')
		elseif type == 'OPP' then
			oppCombo = oppCombo + 1
			daCombo = oppCombo
		elseif type == 'GF' then
			gfCombo = gfCombo + 1
			daCombo = gfCombo

			if getPropertyFromGroup('notes', id, 'mustPress') then type = 'PLR_GF' end
		end

		local d = dir
		if type == 'PLR' or type == 'PLR_GF' then d = d + getProperty('opponentStrums.length') end

		local alpha = getPropertyFromGroup('strumLineNotes', d, 'alpha')
		if alpha == 0 or not getPropertyFromGroup('strumLineNotes', d, 'visible') then return end

		local name = 'comboThing'..type..daCombo
		if type == 'PLR' or type == 'PLR_GF' then table.insert(playerCombos, name) end

		makeLuaText(name, daCombo, 90, getPropertyFromGroup('strumLineNotes', d, 'x') + offX, getPropertyFromGroup('strumLineNotes', d, 'y') + ay)
		setObjectCamera(name, 'camHUD')
		setTextSize(name, 30)
		setTextAlignment(name, 'center')
		--setTextColor(name, ncolors[dir + 1]) SCRAPPED (v2.8.0)
		--setTextColor(name, 'e6e6e6') (v2.8.2, subversion: 0)
		setProperty(name..'.color', getPropertyFromClass('backend.ClientPrefs', 'data.arrowRGB['..dir..'][0]'))
		setProperty(name..'.borderColor', getPropertyFromClass('backend.ClientPrefs', 'data.arrowRGB['..dir..'][2]'))
		setProperty(name..'.alpha', alpha)
		-- LET'S GO IT WORRRKSSSSSSSSS (v2.8.2, subversion: 1)
		scaleObject(name, 1.5, 1.5)

		if noBorder then setTextBorder(name, 0, '000000', '') else setProperty(name..'.borderSize', 1.4) end

		if optimized then
			if objOrder < 0 then objOrder = getObjectOrder('strumLineNotes') - 1 end
			setObjectOrder(name, objOrder)
		else setObjectOrder(name, getObjectOrder('strumLineNotes') - 1) end

		setProperty(name..'.font', getProperty('scoreTxtThing.font'))
		setProperty(name..'.antialiasing', aa)
		addLuaText(name)

		--triggerEvent('comboThingyShade', name, id) SCRAPPED (v2.8.0)

		doTweenX(name..'SX_', name..'.scale', 0.7, crochet / 800, 'sineIn')
		doTweenY(name..'SY_', name..'.scale', 0.7, crochet / 800, 'sineIn')
		doTweenY(name..'Y_', name, getProperty(name..'.y') + (y * 0.8), (crochet+150) / 800, 'circOut')

		if getPropertyFromGroup('notes', id, 'tail.length') > 0 then
			doTweenX(name..'SX_', name..'.scale', 1.1, crochet / 800, 'sineOut')
			doTweenY(name..'SY_', name..'.scale', 1.1, crochet / 800, 'sineOut')

			local sustainLength = getPropertyFromGroup('notes', id, 'sustainLength') / 1000
			runTimer(name, sustainLength)

			local tickRate = (stepCrochet / 1000) * 0.9
			local ticks = math.floor(sustainLength / tickRate)
			runTimer('tick_'..name, tickRate, ticks)
			onTimerCompleted('tick_'..name, 0, ticks + 1)

			table.insert(sustainCombos, name)
		else doTweenAlpha(name, name, 0, crochet / 800, 'sineIn') end
	end
end

function onTimerCompleted(t, l, ll)
	if stringStartsWith(t, 'comboThing') then
		removeFromTable(sustainCombos, t)

		doTweenAngle(t..'ANG_', t, 0, crochet / 800, 'circOut')
		doTweenX(t..'SX_', t..'.scale', 0.7, crochet / 800, 'sineIn')
		doTweenY(t..'SY_', t..'.scale', 0.7, crochet / 800, 'sineIn')
		doTweenAlpha(t, t, 0, crochet / 800, 'sineIn')
	end

	if stringStartsWith(t, 'tick') then
		local name = string.sub(t, 6, #t)
		local angle = 12
		if ll % 2 == 0 then angle = -angle end

		doTweenAngle(name..'ANG_', name, angle, 0.1, 'sineInOut')
	end
end

function onTweenCompleted(t)
	if stringStartsWith(t, 'comboThing') and not stringEndsWith(t, '_') then
		if string.find(t, 'PLR') then removeFromTable(playerCombos, t) end

		removeLuaText(t, true)
	end
end

function goodNoteHit(id, dir, ntype, sus) silly(id, dir, sus) end
function opponentNoteHit(id, dir, ntype, sus) silly(id, dir, sus) end

local missColor = getColorFromHex('9e9e9e')
local missBorderColor = getColorFromHex('474747')
function noteMiss(id, dir, ntype, sus)
	if getPropertyFromGroup('notes', id, 'gfNote') then gfCombo = 0 end

	for i,t in ipairs(playerCombos) do
		removeFromTable(playerCombos, t)

		cancelTimer('tick_'..t)
		cancelTimer(t)
		cancelTween(t)

		setProperty(t..'.color', missColor)
		setProperty(t..'.borderColor', missBorderColor)

		doTweenAngle(t..'ANG_', t, 0, crochet / 1400, 'circOut')
		doTweenX(t..'SX_', t..'.scale', 0.7, crochet / 1400, 'sineIn')
		doTweenY(t..'SY_', t..'.scale', 0.7, crochet / 1400, 'sineIn')
		doTweenAlpha(t, t, 0, crochet / 1400, 'sineIn')
	end
end

function removeFromTable(tab, value)
	for i = #tab, 1, -1 do
		if tab[i] == value then
			table.remove(tab, i)
			break
		end
	end
end