-- by LonliHH

local enabled = false
local optimized = false
local objOrder = -1
local noBorder = false
local aa = false
--local ncolors = {'c24b99', '00ffff', '12fa05', 'f9393f'}
--scrapped bc cant adjust to player's rgbShader
local offX = -15

function onCreate()
	setProperty('showComboNum', false)
	initSaveData('lonlihh', 'amigosmod')
	enabled = getDataFromSave('lonlihh', 'optCombo') and not stringStartsWith(songName, 'Menu')

	if enabled then
		aa = getPropertyFromClass('backend.ClientPrefs', 'data.antialiasing')
		optimized = getDataFromSave('lonlihh', 'optimizeMod')
	else close() end
end

function onCreatePost()
	if enabled then noBorder = getVar('am.forceCopyFont.noBorder') end
end

local oppCombo = 0
local gfCombo = 0

function silly(id, dir, sus)
	if enabled and not sus and not getPropertyFromGroup('notes', id, 'ignoreNote') and not getPropertyFromGroup('notes', id, 'hitCausesMiss') then
		local type
		if getPropertyFromGroup('notes', id, 'gfNote') then type = 'GF'
		elseif getPropertyFromGroup('notes', id, 'mustPress') then type = 'PLR'
		else type = 'OPP' end

		local daCombo
		if type == 'PLR' then daCombo = getProperty('combo')
		elseif type == 'OPP' then
			oppCombo = oppCombo + 1
			daCombo = oppCombo
		elseif type == 'GF' then
			gfCombo = gfCombo + 1
			daCombo = gfCombo

			if getPropertyFromGroup('notes', id, 'mustPress') then type = 'PLR_GF' end
		end

		local d = dir
		if type == 'PLR' or type == 'PLR_GF' then d = d + getProperty('opponentStrums.length') end
		if getPropertyFromGroup('strumLineNotes', d, 'alpha') == 0 or not getPropertyFromGroup('strumLineNotes', d, 'visible') then return end

		local name = 'comboThing'..type..daCombo..getRandomInt(0,9)
		local y = -70
		local ay = -5
		if downscroll then
			y = -y
			ay = ay + 35
		end

		makeLuaText(name, daCombo, 90, getPropertyFromGroup('strumLineNotes', d, 'x') + offX, getPropertyFromGroup('strumLineNotes', d, 'y') + ay)
		setObjectCamera(name, 'camHUD')
		setTextSize(name, 40)
		setTextAlignment(name, 'center')
		--setTextColor(name, ncolors[dir + 1]) SCRAPPED
		setTextColor(name, 'e6e6e6')
		scaleObject(name, 1.5, 1.5)

		if noBorder then setTextBorder(name, 0, '000000', '') else setProperty(name..'.borderSize', 1.4) end

		if optimized then
			if objOrder < 0 then objOrder = getObjectOrder('strumLineNotes') - 1 end
			setObjectOrder(name, objOrder)
		else setObjectOrder(name, getObjectOrder('strumLineNotes') - 1) end

		setProperty(name..'.font', getProperty('scoreTxtThing.font'))
		setProperty(name..'.antialiasing', aa)
		addLuaText(name)

		--triggerEvent('comboThingyShade', name, id)

		doTweenX(name..'SX_', name..'.scale', 0.7, crochet / 800, 'sineOut')
		doTweenY(name..'SY_', name..'.scale', 0.7, crochet / 800, 'sineOut')
		doTweenY(name..'Y_', name, getProperty(name..'.y') + y, (crochet+150) / 800, 'circOut')
		doTweenAlpha(name, name, 0, crochet / 800, 'sineIn')
	end
end

function onTweenCompleted(t)
	if stringStartsWith(t, 'comboThing') and not stringEndsWith(t, '_') then removeLuaText(t, true) end
end

function goodNoteHit(id, dir, ntype, sus) silly(id, dir, sus) end
function opponentNoteHit(id, dir, ntype, sus) silly(id, dir, sus) end
function noteMiss(id, dir, ntype, sus) if getPropertyFromGroup('notes', id, 'gfNote') then gfCombo = 0 end end