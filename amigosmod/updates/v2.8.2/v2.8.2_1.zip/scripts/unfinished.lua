local enabled = false

function onCreate()
	initSaveData('lonlihh', 'amigosmod')
	if getDataFromSave('lonlihh', 'unfTxt', false) and checkFileExists('data/'..string.lower(songName):gsub('%s', '-')..'/unfinished.txt') then
		enabled = true
		
		makeLuaSprite('unf', 'unfinished')
		setObjectCamera('unf', 'camOther')
		scaleObject('unf', 1.6, 1.6)
		screenCenter('unf', 'xy')
		addLuaSprite('unf')
	else close() end
end

function onCountdownTick(c)
	if enabled and c == 3 then
		doTweenX('unfsx', 'unf.scale', 0.5, crochet / 500, 'backInOut')
		doTweenY('unfsy', 'unf.scale', 0.5, crochet / 500, 'backInOut')
		doTweenX('unfx', 'unf', -250, crochet / 500, 'backInOut')
		doTweenY('unfy', 'unf', -30, crochet / 500, 'backInOut')
	end
end

function onTweenCompleted(t)
	if enabled and t == 'unfsx' then close() end
end