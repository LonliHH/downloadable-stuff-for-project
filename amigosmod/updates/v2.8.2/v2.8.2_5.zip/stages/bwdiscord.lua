function onCreate()
	makeLuaSprite('bgc')
	makeGraphic('bgc', 2000, 2000, '3d3d3d')
	screenCenter('bgc', 'xy')
	setScrollFactor('bgc', 0, 0)
	addLuaSprite('bgc', false)
end