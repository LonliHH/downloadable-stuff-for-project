local oldBG

function onCreate()
	setVar('am.forceCopyFont', true)
	setVar('am.forceCopyFont.noBorder', true)
	setPropertyFromClass('backend.ClientPrefs', 'data.timeBarType', 'Time Elapsed')

	oldBG = getProperty('camGame.bgColor')
	setProperty('camGame.bgColor', getColorFromHex('2f3136'))

	makeLuaSprite('healthAlert', 'clones/ui/healthAlert')
	setObjectCamera('healthAlert', 'camHUD')
	setProperty('healthAlert.visible', false)
	addLuaSprite('healthAlert')
end

function onCreatePost()
	setObjectOrder('healthAlert', getObjectOrder('healthBar') + 1)
	healthColorizeLuaObj('healthAlert', true)

	local aa = getPropertyFromClass('backend.ClientPrefs', 'data.antialiasing')

	setProperty('boyfriend.flipX', false)
	setTextFont('botplayTxt', 'ggsans.ttf')
	setTextColor('botplayTxt', 'dbdee1')
	setTextBorder('botplayTxt', 0, '000000', '')
	setProperty('botplayTxt.antialiasing', aa)
	setTextFont('scoreTxtThing', 'ggsans.ttf')
	setTextBorder('scoreTxtThing', 0, '000000', '')
	setProperty('scoreTxtThing.antialiasing', aa)
	setProperty('scoreTxt.antialiasing', aa)
	setTextFont('timeTxt', 'ggsans.ttf')
	setTextColor('timeTxt', 'dbdee1')
	setTextBorder('timeTxt', 0, '000000', '')
	setTextSize('timeTxt', 18)
	setProperty('timeTxt.y', getProperty('timeTxt.y') - 5)
	setProperty('timeTxt.antialiasing', aa)

	local addy = 15
	if downscroll then addy = addy - 7 end

	setProperty('timeBar.scale.x', 0.8)
	setProperty('timeBar.scale.y', 0.8)
	setProperty('timeBar.y', getProperty('timeBar.y') - addy)
	setProperty('timeTxt.x', getProperty('timeBar.x') - 141)
	setProperty('timeTxt.y', getProperty('timeBar.y') + 12)

	makeLuaSprite('timeBarBG', 'clones/ui/timeBarBG', getProperty('timeBar.x') + 19, getProperty('timeBar.y') - 10)
	setObjectCamera('timeBarBG', 'camHUD')
	setObjectOrder('timeBarBG', getObjectOrder('timeBar') - 1)
	addLuaSprite('timeBarBG')

	makeLuaText('timeFinish', '', 0, getProperty('timeBar.x') + 332, getProperty('timeTxt.y'))
	setObjectCamera('timeFinish', 'camHUD')
	setObjectOrder('timeFinish', getObjectOrder('timeTxt'))
	setTextSize('timeFinish', getTextSize('timeTxt'))
	setTextAlignment('timeFinish', 'right')
	setTextColor('timeFinish', 'dbdee1')
	setTextBorder('timeFinish', 0, '000000', '')
	setProperty('timeFinish.antialiasing', aa)
	setProperty('timeFinish.font', getProperty('timeTxt.font'))
	addLuaText('timeFinish')

	setProperty('camFollow.x', 330)
	setProperty('camFollow.y', 300)
	setProperty('camGame.scroll.x', 330 - (screenWidth / 2))
	setProperty('camGame.scroll.y', 300 - (screenHeight / 2))

	runHaxeCode([[
		var aa:Bool = ]]..tostring(aa)..[[;

		var hbPath = Paths.image('clones/ui/healthBar');
		var tbPath = Paths.image('clones/ui/timeBar');

		game.healthBar.bg.visible = false;
		game.healthBar.leftBar.loadGraphic(hbPath);
		game.healthBar.leftBar.antialiasing = aa;
		game.healthBar.rightBar.loadGraphic(hbPath);
		game.healthBar.rightBar.antialiasing = aa;
		game.healthBar.antialiasing = aa;

		game.timeBar.bg.visible = false;
		game.timeBar.leftBar.loadGraphic(tbPath);
		game.timeBar.leftBar.color = FlxColor.fromRGB(219, 222, 225);
		game.timeBar.leftBar.antialiasing = aa;
		game.timeBar.rightBar.loadGraphic(tbPath);
		game.timeBar.rightBar.color = FlxColor.fromRGB(41, 44, 48);
		game.timeBar.rightBar.antialiasing = aa;
		game.timeBar.antialiasing = aa;
	]])
end

function goodNoteHit(i, d, t, s)
	if getProperty('boyfriend.scale.x') < 0 and (d == 0 or d == 3) then
		local suffix = ''
		if stringEndsWith(getProperty('boyfriend.animation.curAnim.name'), '-alt') then suffix = '-alt' end

		if d == 0 then playAnim('boyfriend', 'singRIGHT'..suffix, true)
		else playAnim('boyfriend', 'singLEFT'..suffix, true) end
	end
end

function noteMiss(i, d, t, s)
	if getProperty('boyfriend.scale.x') < 0 and (d == 0 or d == 3) then
		if d == 0 then playAnim('boyfriend', 'singRIGHTmiss', true)
		else playAnim('boyfriend', 'singLEFTmiss', true) end
	end
end

function onBeatHit()
	if curBeat % 2 ~= 0 then
		local anim = getProperty('boyfriend.animation.curAnim.name')
		if anim == 'idle' then playAnim('boyfriend', 'idle', true)
		elseif anim == 'idle-alt' then playAnim('boyfriend', 'idle-alt', true) end
	end
end

function onSongStart()
	setTextToMaxSongTime('timeFinish')
	playAnim('boyfriend', 'idle', true)
	playAnim('dad', 'idle', true)
	playAnim('gf', 'idle', true)
end

function onUpdatePost()
	local a = getProperty('timeTxt.alpha')
	setProperty('timeFinish.alpha', a)
	setProperty('timeBarBG.alpha', a)
end

function onCountdownTick(c)
	playAnim('boyfriend', 'idle', true)

	if c == 0 or c == 2 then
		playAnim('dad', 'idle', true)
		playAnim('gf', 'idle', true)
	end
end

function onDestroy()
	setProperty('camGame.bgColor', oldBG)
	setPropertyFromClass('backend.ClientPrefs', 'data.timeBarType', timeBarType)
end