local barHeight = 130

function onCreate()
	makeLuaSprite('bg', 'insomnia/bedroom', -639, -359)
	addLuaSprite('bg', false)

	makeLuaSprite('topBar')
	makeGraphic('topBar', screenWidth, barHeight, '000000')
	setObjectCamera('topBar', 'camHUD')
	addLuaSprite('topBar')

	makeLuaSprite('botBar', nil, 0, screenHeight - barHeight)
	makeGraphic('botBar', screenWidth, barHeight, '000000')
	setObjectCamera('botBar', 'camHUD')
	addLuaSprite('botBar')

	makeLuaText('oppBar', 'opponent health/vibe baR :3', 800, 130, 50)
	setObjectCamera('oppBar', 'camHUD')
	setTextSize('oppBar', 20)
	setTextAlignment('oppBar', 'left')
	addLuaText('oppBar')

	makeLuaText('plrBar', 'PLAYR HEALTH/VIBE BAR AAAA', 800, 320, screenHeight - 70)
	setObjectCamera('plrBar', 'camHUD')
	setTextSize('plrBar', 20)
	setTextAlignment('plrBar', 'right')
	addLuaText('plrBar')

	setVar('am.combothingies.forceClose', true)
end

function onCreatePost()
	local order = getObjectOrder('strumLineNotes') - 1
	setObjectOrder('topBar', order)
	setObjectOrder('botBar', order)
	setObjectOrder('oppBar', order + 1)
	setObjectOrder('plrBar', order + 1)

	triggerEvent('se', 'camThing')
	addLuaScript('custom_events/CameraControl')
	triggerEvent('CameraControl', '330,100', getProperty('defaultCamZoom'))
	removeLuaScript('custom_events/CameraControl')

	runHaxeCode([[
		for (n in game.unspawnNotes) {
			if (!n.isSustainNote) {
				n.setGraphicSize(n.width / 0.7 * 0.65);

				if (n.tail.length > 0) for (t in n.tail) {
					t.setGraphicSize(t.width / 0.7 * 0.65, t.height);
					t.offsetX -= 2.5;
				}
			}

			n.updateHitbox();
		}

		game.getLuaObject('scoreTxtThing').visible = false;
		game.healthBar.y += 18;
		game.iconP1.y += 18;
		game.iconP2.y += 18;

		game.healthBar.visible = false;
		game.iconP1.visible = false;
		game.iconP2.visible = false;

		function handleNote(n:Note):Void {
			if (!n.mustPress && n.tail.length > 0) {
				if (n.tail.length > 1) {
					n.tail[0].visible = false;
					n.tail[0].copyAlpha = false;
					n.tail[0].alpha = 0;
				}

				for (t in n.tail) {
					if (t.visible && t.alpha > 0) {
						t.flipY = !ClientPrefs.data.downScroll;
					}
				}
			}
		}

		createCallback('adjustStrums', function():Void {
			for (strum in game.opponentStrums.members) {
				strum.downScroll = !strum.downScroll;

				var offsetY:Float = 520;
				strum.y += strum.downScroll ? offsetY : -offsetY;
			}

			for (n in game.unspawnNotes) handleNote(n);
			for (n in game.notes.members) handleNote(n);

			for (strum in game.strumLineNotes.members) {
				strum.setGraphicSize(strum.width / 0.7 * 0.65);
				strum.updateHitbox();

				var offsetY:Float = 35;

				strum.y += strum.downScroll ? offsetY : -offsetY;
			}
		});
	]])
end

luaDebugMode = true

function onSongStart()
	adjustStrums()
end

function onUpdatePost()
	setProperty('healthAlert.visible', false)
end