local yourHeight = 120

function onCreate()
	makeLuaSprite('bg', 'confrontation/Confront_bg')
	scaleObject('bg', 4.5, 4.5)
	setScrollFactor('bg', 0.7, 0.7)
	screenCenter('bg', 'xy')
	setProperty('bg.x', getProperty('bg.x') + 30)
	addLuaSprite('bg', false)
end

function onCreatePost()
	makeLuaSprite('topBar', nil, 0, -yourHeight)
	makeGraphic('topBar', screenWidth, yourHeight, '000000')
	setObjectCamera('topBar', 'camHUD')
	addLuaSprite('topBar', false)

	makeLuaSprite('botBar', nil, 0, screenHeight + yourHeight)
	makeGraphic('botBar', screenWidth, yourHeight, '000000')
	setObjectCamera('botBar', 'camHUD')
	addLuaSprite('botBar', false)

	triggerEvent('Bloom Shader', 'remove', '')
end

function onEvent(n, v1, v2)
	if n == 'stars' and v1 == 'in' then
		local dur = crochet / 500
		doTweenY('topBar', 'topBar', 0, dur, 'circOut')
		doTweenY('botBar', 'botBar', screenHeight - yourHeight, dur, 'circOut')
	end
end