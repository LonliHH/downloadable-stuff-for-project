-- "pls." -LonliHH

luaDebugMode = true
local active = false
local loaded = false
local freecamMode = false
local isAllNotesGhost = false
local freezeHealth = false
local curHealth = 1
local camMoveSpeed = 200
local consoleVersion = '1.0.1'
local startingText = "Type 'help' for a list of commands"
local appendPrefix = ''
local prevInputs = {}
local inputHistoryIndex = nil
local inputHistorySave = ''

function onUpdate()
	if not active and keyboardPressed('CONTROL') and keyboardJustPressed('D') then
		openCustomSubstate('amConsole', true)
	end

	if freezeHealth then setHealth(curHealth) end
end

function onCustomSubstateCreate(n)
	if n == 'amConsole' then
		active = true

		if loaded then
			setProperty('console.hasFocus', true)
			setProperty('consoleCam.active', true)
			setProperty('consoleCam.visible', true)
		else
			makeLuaText('consoleTxt', 'Type a command/function:', 0, 20, 20)
			setTextSize('consoleTxt', 25)
			setTextAlignment('consoleTxt', 'left')
			setTextBorder('consoleTxt', 0, '000000', '')
			setProperty('consoleTxt.antialiasing', false)
			addLuaText('consoleTxt')

			makeLuaText('consoleLog', startingText, 0, 20, 90)
			setTextSize('consoleLog', 14)
			setTextAlignment('consoleLog', 'left')
			setTextBorder('consoleLog', 0, '000000', '')
			setProperty('consoleLog.antialiasing', false)
			addLuaText('consoleLog')

			appendLog('This console is NOT meant to be user-accessed, so expect some bugs.')

			runHaxeCode([[
				addHaxeLibrary('FlxUIInputText', 'flixel.addons.ui');

				var cam = new FlxCamera();
				cam.bgColor = 0x8C000000;
				game.variables.set('consoleCam', cam);
				FlxG.cameras.add(cam, false);

				game.getLuaObject('consoleTxt').camera = cam;
				game.getLuaObject('consoleLog').camera = cam;

				var input = new FlxUIInputText(40, 60, 1190, '', 17);
				input.camera = cam;
				input.hasFocus = true;
				input.caretColor = 0xFFFFFFFF;
				input.antialiasing = false;
				input.background = false;
				input.color = 0xFFFFFFFF;
				game.variables.set('console', input);
				add(input);
			]])

			loaded = true
		end
	end
end

function onCustomSubstateUpdate(n, dt)
	if active then
		if keyboardJustPressed('ESCAPE') then
			if freecamMode then
				freecamMode = false
				setProperty('consoleFreecamGuide.visible', false)
				setProperty('console.hasFocus', true)
				setProperty('consoleCam.active', true)
				setProperty('consoleCam.visible', true)
			else
				active = false
				setProperty('console.hasFocus', false)
				setProperty('consoleCam.visible', false)
				setProperty('consoleCam.active', false)
				closeCustomSubstate()
			end
		end

		if freecamMode then
			if keyboardPressed('LEFT') then setProperty('camGame.scroll.x', getProperty('camGame.scroll.x') - camMoveSpeed * dt) end
			if keyboardPressed('RIGHT') then setProperty('camGame.scroll.x', getProperty('camGame.scroll.x') + camMoveSpeed * dt) end
			if keyboardPressed('UP') then setProperty('camGame.scroll.y', getProperty('camGame.scroll.y') - camMoveSpeed * dt) end
			if keyboardPressed('DOWN') then setProperty('camGame.scroll.y', getProperty('camGame.scroll.y') + camMoveSpeed * dt) end

			if keyboardPressed('C') then setProperty('camGame.zoom', getProperty('camGame.zoom') + 3 * dt)
			elseif keyboardPressed('V') then setProperty('camGame.zoom', getProperty('camGame.zoom') - 3 * dt) end

			if keyboardPressed('N') then camMoveSpeed = camMoveSpeed + 5
			elseif keyboardPressed('M') then camMoveSpeed = camMoveSpeed - 5
			elseif keyboardJustPressed('B') then camMoveSpeed = 200 end

			return
		end



		if keyboardJustPressed('UP') then navigateInputHistory(-1)
		elseif keyboardJustPressed('DOWN') then navigateInputHistory(1) end



		if keyboardJustPressed('ENTER') then inputEntered(getProperty('console.text')) end
	end
end

function navigateInputHistory(dir)
	if #prevInputs == 0 then return end

	if inputHistoryIndex == nil then
		inputHistoryIndex = #prevInputs
		inputHistorySave = getProperty('console.text')
	else
		inputHistoryIndex = inputHistoryIndex + dir

		if inputHistoryIndex < 1 then inputHistoryIndex = 1 end
		if inputHistoryIndex > #prevInputs then
			inputHistoryIndex = nil
			setProperty('console.text', inputHistorySave)
			setProperty('console.caretIndex', #inputHistorySave)
			return
		end
	end

	local daText = prevInputs[inputHistoryIndex]
	setProperty('console.text', daText)
	setProperty('console.caretIndex', #daText)
end

function inputEntered(txt)
	setProperty('console.text', '')
	setProperty('console.caretIndex', 0)

	table.insert(prevInputs, txt)
	inputHistoryIndex = nil

	local args = stringSplit(txt, ' ')
	while args[1] == '' or args[1] == ' ' do table.remove(args, 1) end -- removes whitespaces

	if args[1] == 'setNumProperty' then setProperty(args[2], tonumber(args[3])); appendLog(txt)
	elseif args[1] == 'setBoolProperty' then setProperty(args[2], string.lower(args[3]) == 'true'); appendLog(txt)
	elseif args[1] == 'setColorProperty' then setProperty(args[2], FlxColor(args[3])); appendLog(txt)
	elseif args[1] == 'setStrProperty' then setProperty(args[2], table.concat(args, ' ', 3) or ''); appendLog(txt)
	elseif args[1] == 'setNumVar' then setVar(args[2], tonumber(args[3])); appendLog(txt)
	elseif args[1] == 'setBoolVar' then setVar(args[2], string.lower(args[3]) == 'true'); appendLog(txt)
	elseif args[1] == 'setColorVar' then setVar(args[2], FlxColor(args[3])); appendLog(txt)
	elseif args[1] == 'setStrVar' then setVar(args[2], table.concat(args, ' ', 3) or ''); appendLog(txt)
	elseif args[1] == 'setGroupNumProperty' then setPropertyFromGroup(args[2], tonumber(args[3]), args[4], tonumber(args[5])); appendLog(txt)
	elseif args[1] == 'setGroupBoolProperty' then setPropertyFromGroup(args[2], tonumber(args[3]), args[4], string.lower(args[5]) == 'true'); appendLog(txt)
	elseif args[1] == 'setGroupColorProperty' then setPropertyFromGroup(args[2], tonumber(args[3]), args[4], FlxColor(args[5])); appendLog(txt)
	elseif args[1] == 'setGroupStrProperty' then setPropertyFromGroup(args[2], tonumber(args[3]), args[4], table.concat(args, ' ', 5) or ''); appendLog(txt)
	elseif args[1] == 'precacheImage' then precacheImage(table.concat(args, ' ', 2) or ''); appendLog(txt)
	elseif args[1] == 'precacheSound' then precacheSound(table.concat(args, ' ', 2) or ''); appendLog(txt)
	elseif args[1] == 'precacheMusic' then precacheMusic(table.concat(args, ' ', 2) or ''); appendLog(txt)
	elseif args[1] == 'listCached' then appendLog(listCached())
	elseif args[1] == 'decacheImage' then decacheImage(table.concat(args, ' ', 2) or ''); appendLog(txt)
	elseif args[1] == 'decacheSound' then decacheSound(table.concat(args, ' ', 2) or ''); appendLog(txt)
	elseif args[1] == 'setTextFont' then setTextFont(args[2], table.concat(args, ' ', 3) or ''); appendLog(txt)
	elseif args[1] == 'setTextSize' then setTextSize(args[2], tonumber(args[3])); appendLog(txt)
	elseif args[1] == 'setTextAlignment' then setTextAlignment(args[2], args[3]); appendLog(txt)
	elseif args[1] == 'setAllUITextFont' then
		local font = table.concat(args, ' ', 2) or ''

		setTextFont('botplayTxt', font)
		setTextFont('timeTxt', font)
		setTextFont('scoreTxtThing', font)
		appendLog('Set all UI text font to: '..font)
	elseif args[1] == 'setAllUITextSize' then
		local size = tonumber(args[2])

		setTextSize('botplayTxt', size)
		setTextSize('timeTxt', size)
		setTextSize('scoreTxtThing', size)
		appendLog('Set all UI text size to: '..size)
	elseif args[1] == 'setAllUITextAlignment' then
		setTextAlignment('botplayTxt', args[2])
		setTextAlignment('timeTxt', args[2])
		setTextAlignment('scoreTxtThing', args[2])
		appendLog('Set all UI text alignment to: '..args[2])
	elseif args[1] == 'add' then setProperty(args[2], getProperty(args[2]) + tonumber(args[3])); appendLog(txt)
	elseif args[1] == 'addToGroup' then
		local index = tonumber(args[3])
		setPropertyFromGroup(args[2], index, args[4], getPropertyFromGroup(args[2], index, args[4]) + tonumber(args[5]))
		appendLog(txt)
	elseif args[1] == 'forceHealth' then
		curHealth = tonumber(args[2])
		setVar('forceHealth.value', curHealth)
		setVar('forceHealth', true)
		appendLog('Set health value to: '..curHealth)
	elseif args[1] == 'freezeHealth' then
		freezeHealth = not freezeHealth
		if freezeHealth then
			curHealth = getHealth()
			appendLog('Froze health to: '..curHealth)
		else appendLog('Defroze health') end
	elseif args[1] == 'restartSong' then triggerEvent('restartSong'); appendLog('Attempted to restart song')
	elseif args[1] == 'moveToSong' then
		local songstr = string.lower(table.concat(args, '-', 2) or '')

		if songstr ~= '' then
			setVar('prev.song', songstr)
			loadSong(songstr, -1)
			appendLog('Attempted to load song: '..songstr)
		else appendLog('Invalid song name') end
	elseif args[1] == 'triggerEvent' then
		local evstr = table.concat(args, ' ', 2) or ''
		local ev = stringSplit(evstr, ':')

		-- make sure ev has at least 3 elements
		for i = #ev + 1, 3 do ev[i] = '' end

		triggerEvent(ev[1], ev[2], ev[3])
		appendLog('Triggered event: '..ev[1]..' ('..ev[2]..', '..ev[3]..')')
	elseif args[1] == 'know' then
		local prop = getProperty(args[2])
		if prop ~= nil then appendLog('Know: '..args[2]..' = '..tostring(prop))
		else appendLog('Know: '..args[2]..' is null') end
	elseif args[1] == 'knowGroup' then
		local prop = getPropertyFromGroup(args[2], tonumber(args[3]), args[4])
		if prop ~= nil then appendLog('Know (Group): '..args[2]..'['..args[3]..'].'..args[4]..' = '..tostring(prop))
		else appendLog('Know (Group): '..args[2]..'['..args[3]..'].'..args[4]..' is null') end
	elseif args[1] == 'knowVar' then
		local prop = getVar(args[2])
		if prop ~= nil then appendLog('Know (Var): '..args[2]..' = '..tostring(prop))
		else appendLog('Know (Var): '..args[2]..' is null') end
	elseif args[1] == 'freecam' then
		if not luaTextExists('consoleFreecamGuide') then
			makeLuaText('consoleFreecamGuide', 'Freecam Controls:\n- B: Reset cam speed\n- N: Increase cam speed\n- B: Decrease cam speed\n- C: Zoom in\n- V: Zoom out\n- Arrow keys to move around', 0, 20, 20)
			setTextSize('consoleFreecamGuide', 20)
			setTextAlignment('consoleFreecamGuide', 'left')
			setProperty('consoleFreecamGuide.borderSize', 0.8)
			setObjectCamera('consoleFreecamGuide', 'camOther')
			setProperty('consoleFreecamGuide.antialiasing', false)
			addLuaText('consoleFreecamGuide')
		else setProperty('consoleFreecamGuide.visible', true) end

		setProperty('console.hasFocus', false)
		setProperty('consoleCam.visible', false)
		freecamMode = true
	elseif args[1] == 'clearLog' then setTextString('consoleLog', startingText)
	elseif args[1] == 'clearInputLog' then prevInputs = {}
	elseif args[1] == 'ghostAllNotes' then
		isAllNotesGhost = not isAllNotesGhost

		local ghosting = function(group)
			for i = 0, getProperty(group..'.length') - 1 do
				if getPropertyFromGroup(group, i, 'mustPress') then
					setPropertyFromGroup(group, i, 'ignoreNote', isAllNotesGhost)
				end
			end
		end

		ghosting('unspawnNotes')
		ghosting('notes')

		appendLog('GhostAllNotes: '..onOrOff(isAllNotesGhost))
	elseif args[1] == 'swapNoteSections' then
		local swap = function(group)
			for i = 0, getProperty(group..'.length') - 1 do
				setPropertyFromGroup(group, i, 'mustPress', not getPropertyFromGroup(group, i, 'mustPress'))
			end
		end

		swap('unspawnNotes')
		swap('notes')

		appendLog('Swapped note sections')
	elseif args[1] == 'addLuaScript' then local path = table.concat(args, ' ', 2) or ''; if path ~= '' then addLuaScript(path) end
	elseif args[1] == 'addHScript' then local path = table.concat(args, ' ', 2) or ''; if path ~= '' then addHScript(path) end
	elseif args[1] == 'saveDebugScript' then
		local path = table.concat(args, ' ', 2) or ''

		if path == '' then
			appendLog('Invalid path.')
			return
		end

		if not stringEndsWith(path, '.dsc') then path = path..'.dsc' end

		local loopWarning = false
		local content = '_ver='..consoleVersion
		for i = 1, #prevInputs do
			content = content..'\n'

			local cmd = prevInputs[i]
			if stringStartsWith(cmd, 'runDebugScript') then loopWarning = true end
			content = content..cmd
		end

		saveFile(path, content)
		appendLog('Saved '..#prevInputs..' lines to: '..path)

		if loopWarning then appendLog("WARNING: Including a 'runDebugScript' command in your script may cause an endless loop upon running the script, also it may crash your game :3") end
	elseif args[1] == 'runDebugScript' then
		local path = table.concat(args, ' ', 2) or ''
		if not stringEndsWith(path, '.dsc') then path = path..'.dsc' end

		if checkFileExists(path) then
			local scriptVersion = '1.0.0'
			local lines = stringSplit(getTextFromFile(path), '\n')

			appendPrefix = 'From script: '

			for i = 1, #lines do
				local line = lines[i]:gsub("[\r\n]+$", "") -- removes line breaks at the end

				if stringStartsWith(line, '_') then
					local entry = stringSplit(line, '=')

					if entry[1] == '_ver' then scriptVersion = entry[2] end
				else
					if scriptVersion ~= consoleVersion then
						appendPrefix = ''
						appendLog("This script was made on a different version of Amigos Mod's debug console. (Script: "..scriptVersion..", Console: "..consoleVersion..")")
						return
					end

					inputEntered(line)
				end
			end

			appendPrefix = ''
		else appendLog('File does not exist: '..path) end
	elseif args[1] == 'help' then -- help
		appendLog('List of Functions:')
		appendLog('- setNumProperty [object.property] [number]')
		appendLog('- setBoolProperty [object.property] [boolean]')
		appendLog("- setColorProperty [object.property] [color] (If using a hex code, prefix your color with a '#')")
		appendLog('- setStrProperty [object.property], [string]')
		appendLog('- setNumVar [var] [number]')
		appendLog('- setBoolVar [var] [boolean]')
		appendLog("- setColorVar [var] [color] (If using a hex code, prefix your color with a '#')")
		appendLog('- setStrVar [var] [string]')
		appendLog('- setGroupNumProperty [group] [index] [var] [number]')
		appendLog('- setGroupBoolProperty [group] [index] [var] [boolean]')
		appendLog("- setGroupColorProperty [group] [index] [var] [color] (If using a hex code, prefix your color with a '#')")
		appendLog('- setGroupStrProperty [group] [index] [var] [string]')
		appendLog('- precacheImage [image]')
		appendLog('- precacheSound [sound]')
		appendLog('- precacheMusic [music]')
		appendLog('- listCached')
		appendLog('- decacheImage [image]')
		appendLog('- decacheSound [sound]')
		appendLog('- setTextFont [text] [font]')
		appendLog('- setTextSize [text] [size]')
		appendLog('- setTextAlignment [text] [alignment]')
		appendLog('- setAllUITextFont [font]')
		appendLog('- setAllUITextSize [size]')
		appendLog('- setAllUITextAlignment [alignment]')
		appendLog('- add [object.property] [number]')
		appendLog('- addToGroup [group] [index] [property] [number]')
		appendLog('- forceHealth [healthValue] (May glitch out)')
		appendLog('- freezeHealth (Stops the health bar from moving)')
		appendLog('- restartSong')
		appendLog("- moveToSong [song] (Type 'menu' in [song] to exit to menu)")
		appendLog('- triggerEvent [event]:[value1]:[value2]')
		appendLog('- know [property] (Prints out an engine/mod property)')
		appendLog('- knowGroup [group] [index] [property] (Prints out a property from an engine group)')
		appendLog('- knowVar [var] (Prints out a mod variable)')
		appendLog('- freecam')
		appendLog('- ghostAllNotes (Toggles whether all notes should be hit or not, may break the chart.)')
		appendLog('- swapNoteSections (Swaps the notes of the player and the opponent, may break the chart.)')
		appendLog('- addLuaScript (Loads a lua script if not already running.)')
		appendLog('- addHScript (Loads a haxe script if not already running.)')
		appendLog('- saveDebugScript (Saves your command session into a script file for reuse.)')
		appendLog('- runDebugScript (Loads and runs a command log.)')
		appendLog('- clearInputLog')
		appendLog('- clearLog\n')
		appendLog('(Press the UP ARROW KEY to automatically type your previous input.)')
	elseif txt ~= '' then appendLog("'"..args[1].."' isn't a valid command/function") end
end

function appendLog(txt)
	setTextString('consoleLog', getTextString('consoleLog')..'\n'..appendPrefix..txt)
end

function onOrOff(bool)
	return bool and 'ON' or 'OFF' -- recommended for bool values only
end