local plr = 'boyfriend'

function onCreate()
	if dadName == 'lonliMC' then plr = 'dad' end
	if dadName ~= 'lonliMC' and boyfriendName ~= 'lonliMC' then plr = 'gf' end
	
	if plr == 'boyfriend' then
		setPropertyFromClass('GameOverSubstate', 'characterName', 'lonliMC')
		setPropertyFromClass('GameOverSubstate', 'deathSoundName', 'oof')
		setPropertyFromClass('GameOverSubstate', 'loopSoundName', 'sadpiano')
		--setPropertyFromClass('GameOverSubstate', 'endSoundName', '')
	end

	setVar('plr.noReaction', true)

	close()
end