function onCreate()
	setVar('plr.noReaction', true)
	close()
end