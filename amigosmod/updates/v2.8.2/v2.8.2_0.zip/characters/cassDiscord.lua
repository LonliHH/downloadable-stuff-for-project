local plr = 'boyfriend'
local p = 1
local oy = -4

function onCreate()
	if dadName == 'cassDiscord' then
		plr = 'dad'
		p = 2
	elseif boyfriendName ~= 'cassDiscord' then
		plr = 'gf'
		p = 0
	end

	makeLuaSprite('cassName', 'clones/cassName', getProperty(plr..'.x'), getProperty(plr..'.y') - 20)
	addLuaSprite('cassName', true)
end

function onUpdatePost()
	local isVisible = getProperty(plr..'.visible')
	setProperty('cassName.visible', isVisible)

	if isVisible then
		setProperty('cassName.x', getProperty(plr..'.x'))
		setProperty('cassName.y', getProperty(plr..'.y') - 20)
	end

	if p > 0 then
		if (p == 1 and getHealth() < 0.4) or (p == 2 and getHealth() > 1.6) then
			setProperty('iconP'..p..'.offset.x', getRandomInt(3,-3))
			setProperty('iconP'..p..'.offset.y', getRandomInt(3,-3) + oy)
		else
			setProperty('iconP'..p..'.offset.x', 0)
			setProperty('iconP'..p..'.offset.y', oy)
		end
	end
end