function onCreate()
	if boyfriendName == 'lonley' then
		setPropertyFromClass('substates.GameOverSubstate', 'characterName', 'lonley')
		setPropertyFromClass('substates.GameOverSubstate', 'deathSoundName', 'oof')
		setPropertyFromClass('substates.GameOverSubstate', 'loopSoundName', 'sadpiano')

		setVar('am.death.charName', 'lonley')
	end

	setVar('plr.noReaction', true)

	close()
end