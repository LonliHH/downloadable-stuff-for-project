local plr = 'dad'

function onCreate()
	if boyfriendName == 'redDiscord' then plr = 'boyfriend'
	elseif dadName ~= 'redDiscord' then plr = 'gf' end

	makeLuaSprite('redName', 'clones/cassCloneName', getProperty(plr..'.x'), getProperty(plr..'.y') - 20)
	addLuaSprite('redName', true)
end

function onUpdatePost()
	local isVisible = getProperty(plr..'.visible')
	setProperty('redName.visible', isVisible)

	if isVisible then
		setProperty('redName.x', getProperty(plr..'.x'))
		setProperty('redName.y', getProperty(plr..'.y') - 20)
	end
end