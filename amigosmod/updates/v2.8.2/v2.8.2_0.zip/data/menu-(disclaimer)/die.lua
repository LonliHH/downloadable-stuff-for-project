local allowed = false
local accepted = false
local components = {}
local fadeTime = 0.8

local green = 'acff75'
local red = 'ff3b3b'
local yellow = 'ffe75b'

function onCreate()
	local invisact = function(tag)
		setProperty(tag..'.visible', false)
		setProperty(tag..'.active', false)
	end

	invisact('boyfriend')
	invisact('gf')
	invisact('dad')
	invisact('healthBar')
	if luaSpriteExists('healthBarBG') then invisact('healthBarBG') end
	invisact('scoreTxt')
	invisact('botplayTxt')
	invisact('iconP1')
	invisact('iconP2')

	if timeBarType ~= 'Disabled' then
		invisact('timeBar')
		if luaSpriteExists('timeBarBG') then invisact('timeBarBG') end
		invisact('timeTxt')
	end

	runHaxeCode([[
		game.camGame.active = game.camGame.visible = false;
		FlxG.cameras.remove(game.camGame, false);
	]])

	makeLuaText('header', 'FRIENDLY DISCLAIMER', 0, 0, 130)
	setObjectCamera('header', 'camHUD')
	setTextFont('header', 'pah.ttf')
	setTextSize('header', 80)
	setTextAlignment('header', 'center')
	setTextBorder('header', 0, '000000', '')
	screenCenter('header', 'x')
	setProperty('header.antialiasing', true)
	addComp('header', true)

	makeLuaText('inf1', 'This mod contains                  to serve as the backbone of the mod code. These scripts only access your           and          .', 1100, 0, 282)
	setObjectCamera('inf1', 'camHUD')
	setTextSize('inf1', 36)
	setTextAlignment('inf1', 'center')
	setTextBorder('inf1', 0, '000000', '')
	screenCenter('inf1', 'x')
	setProperty('inf1.antialiasing', false)
	addComp('inf1', true)

	makeLuaText('inf2', 'advanced scripts', 0, 490, 282)
	setObjectCamera('inf2', 'camHUD')
	setTextColor('inf2', green)
	setTextSize('inf2', 36)
	setTextAlignment('inf2', 'center')
	setTextBorder('inf2', 0, '000000', '')
	setProperty('inf2.antialiasing', false)
	addComp('inf2', true)

	makeLuaText('inf3', 'mod files     save data', 0, 440, 346)
	setObjectCamera('inf3', 'camHUD')
	setTextColor('inf3', yellow)
	setTextSize('inf3', 36)
	setTextAlignment('inf3', 'center')
	setTextBorder('inf3', 0, '000000', '')
	setProperty('inf3.antialiasing', false)
	addComp('inf3', true)

	makeLuaText('inf4', 'They        collect personal information or modify anything outside game-related folders.', 1100, 0, 410)
	setObjectCamera('inf4', 'camHUD')
	setTextSize('inf4', 36)
	setTextAlignment('inf4', 'center')
	setTextBorder('inf4', 0, '000000', '')
	screenCenter('inf4', 'x')
	setProperty('inf4.antialiasing', false)
	addComp('inf4', true)

	makeLuaText('inf5', 'DO NOT', 0, 218, 410)
	setObjectCamera('inf5', 'camHUD')
	setTextColor('inf5', red)
	setTextSize('inf5', 36)
	setTextAlignment('inf5', 'center')
	setTextBorder('inf5', 0, '000000', '')
	setProperty('inf5.antialiasing', false)
	addComp('inf5', true)

	makeLuaText('prompt', '(Press [ACCEPT] to continue)', 0, 0, 640)
	setObjectCamera('prompt', 'camHUD')
	setTextSize('prompt', 20)
	setTextAlignment('prompt', 'center')
	setTextBorder('prompt', 0, '000000', '')
	screenCenter('prompt', 'x')
	setProperty('prompt.alpha', 0)
	addComp('prompt', true)
end

function onCreatePost()
	for i = 1, #components do
		if components[i] ~= 'prompt' then
			setProperty(components[i]..'.alpha', 0)
			doTweenAlpha(components[i], components[i], 1, fadeTime, 'sineOut')
		end
	end

	runTimer('allow', fadeTime)
	runTimer('promptAppear', 3.5)
end

function addComp(tag, text)
	text = text or false
	if text then addLuaText(tag) else addLuaSprite(tag) end
	table.insert(components, tag)
end

function onUpdate()
	if allowed and not accepted and keyJustPressed('accept') then
		accepted = true
		cancelTimer('promptAppear')
		setDataFromSave('lonlihh', 'disclaimer', true)
		for i = 1, #components do doTweenAlpha(components[i], components[i], 0, fadeTime, 'sineIn') end
		runTimer('doneFade', fadeTime)
	end
end

function onTimerCompleted(t, l, ll)
	if t == 'doneFade' then loadSong('menu', -1) end
	if t == 'promptAppear' then doTweenAlpha('prompt', 'prompt', 1, fadeTime, 'sineOut') end
	if t == 'allow' then allowed = true end
end

function onPause() return Function_Stop end
function onStartCountdown() return Function_Stop end