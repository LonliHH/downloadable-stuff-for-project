local accepted = false
local waitSeconds = 5
local angleLoopDur = 0.25

function onCreate()
	addLuaScript('lonlihh/scripts/screen.lua')

	runHaxeCode([[
		function removeSave(name:String):Void {
			if (game.modchartSaves.exists(name)) game.modchartSaves.remove(name);
		}

		createCallback('removeSave', removeSave);
	]])
end

function onCreatePost()
	makeLuaText('header', 'HEADS UP!', 0, 0, 90)
	setObjectCamera('header', 'camHUD')
	setTextFont('header', 'pah.ttf')
	setTextSize('header', 80)
	setTextAlignment('header', 'center')
	screenCenter('header', 'x')
	setProperty('header.antialiasing', true)
	addLuaText('header')

	makeLuaText('inf', "Amigos Mod has updated its save system!\nStarting from this version, saves are no longer compatible with v2.8.1 and earlier due to its new save path.\n\nYour current save will be converted once after this message.\nNew saves won't sync with older versions, although it's still possible manually if you're up for it.\nYour old saves will be erased after this operation.\n\nThanks for playing! :3", 1100, 0, 0)
	setObjectCamera('inf', 'camHUD')
	setTextSize('inf', 36)
	setTextAlignment('inf', 'center')
	screenCenter('inf', 'xy')
	setProperty('inf.y', getProperty('inf.y') + 30)
	setProperty('inf.antialiasing', false)
	addLuaText('inf')

	makeLuaText('prompt', '(Press [ACCEPT] to continue)', 0, 0, 640)
	setObjectCamera('prompt', 'camHUD')
	setTextSize('prompt', 20)
	setTextAlignment('prompt', 'center')
	screenCenter('prompt', 'x')
	addLuaText('prompt')

	makeLuaSprite('black')
	makeGraphic('black', screenWidth, screenHeight, '000000')
	setObjectCamera('black', 'camOther')
	setProperty('black.alpha', 0)
	addLuaSprite('black')

	makeLuaText('loadTxt', '', 0, 10, screenHeight - 30)
	setObjectCamera('loadTxt', 'camOther')
	setTextSize('loadTxt', 20)
	setTextAlignment('loadTxt', 'left')
	setProperty('loadTxt.antialiasing', false)
	setProperty('loadTxt.borderSize', 2)
	setProperty('loadTxt.alpha', 0)
	addLuaText('loadTxt')

	playMusic('options', 1, true)

	runTimer('angleStuff', angleLoopDur)
end

function onTimerCompleted(t, l, ll)
	if t == 'angleStuff' then
		setProperty('header.angle', getRandomFloat(-2, 2))
		runTimer('angleStuff', angleLoopDur)
	end

	if t == 'menuCountdown' then
		local secondsPassed = waitSeconds - ll
		local seconds = waitSeconds - secondsPassed

		setTextString('loadTxt', getTextString('loadTxt'):gsub((seconds + 1)..'s', seconds..'s'))

		if seconds == 0 then
			setDataFromSave('lonlihh', 'transferred', true)
			removeSave('lonlihh')
			loadSong('menu', -1)
		end
	end
end

function onTweenCompleted(t)
	if t == 'startConversion' then
		local appData = os.getenv('APPDATA')
		local fromDir = appData..'\\ShadowMario\\PsychEngine\\amigosmod\\'
		local toDir = appData..'\\LonliHH\\AmigosMod\\'

		os.execute('mkdir "'..toDir..'"')

		local copySave = function(name)
			setTextString('loadTxt', 'Copying '..name..'...')
			os.execute('copy "'..fromDir..name..'.sol" "'..toDir..name..'.sol"')
			setTextString('loadTxt', 'Copied '..name)
		end

		copySave('lonlihh')
		copySave('amstats')
		copySave('amcache')

		removeSave('amstats')
		removeSave('amcache')

		setTextString('loadTxt', 'Deleting old saves...')
		os.execute('rmdir /S /Q "'..fromDir..'"')

		setTextString('loadTxt', "Successfully converted save data! It's recommended to restart Psych Engine to reload your saves. (5s...)")
		runTimer('menuCountdown', 1, 5)
	end
end

function onUpdate(elapsed)
	if not accepted and keyJustPressed('accept') then
		accepted = true

		doTweenAlpha('startConversion', 'black', 1, 0.6, 'sineIn')
		doTweenAlpha('loadTxt', 'loadTxt', 1, 0.6, 'sineIn')
		setTextString('loadTxt', 'Converting saves...')
	end

	local chx = getProperty('ch.x')
	if chx >= 0 then setProperty('ch.x', -200)
	else setProperty('ch.x', chx + 100 * elapsed) end
end

function onStartCountdown() return Function_Stop end