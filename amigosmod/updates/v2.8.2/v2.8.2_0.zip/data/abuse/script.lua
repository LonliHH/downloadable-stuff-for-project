function opponentNoteHit()
	local h = getHealth()
	if h > 0.1 then setHealth(h - 0.02) end
end

function onCreatePost()
	if not middlescroll then
		setPropertyFromGroup('strumLineNotes', 0, 'x', defaultPlayerStrumX0)
		setPropertyFromGroup('strumLineNotes', 1, 'x', defaultPlayerStrumX1)
		setPropertyFromGroup('strumLineNotes', 2, 'x', defaultPlayerStrumX2)
		setPropertyFromGroup('strumLineNotes', 3, 'x', defaultPlayerStrumX3)

		setPropertyFromGroup('strumLineNotes', 4, 'x', defaultOpponentStrumX0)
		setPropertyFromGroup('strumLineNotes', 5, 'x', defaultOpponentStrumX1)
		setPropertyFromGroup('strumLineNotes', 6, 'x', defaultOpponentStrumX2)
		setPropertyFromGroup('strumLineNotes', 7, 'x', defaultOpponentStrumX3)

		makeLuaSprite('youBG', nil, getPropertyFromGroup('strumLineNotes', 4, 'x') - 10)
		makeGraphic('youBG', 468, screenHeight, '000000')
		setObjectCamera('youBG', 'camHUD')
		setObjectOrder('youBG', getObjectOrder('strumLineNotes') - 1)
		setProperty('youBG.alpha', 0)
		addLuaSprite('youBG')

		makeLuaSprite('you', 'menu/checkered', getPropertyFromGroup('strumLineNotes', 4, 'x') - 246, 250)
		setObjectCamera('you', 'camHUD')
		setProperty('you.angle', 90)
		scaleObject('you', 0.6142, 0.6142)
		setObjectOrder('you', getObjectOrder('strumLineNotes') - 1)
		setProperty('you.alpha', 0)
		addLuaSprite('you')

		makeLuaText('youTxt', 'YOUR SIDE', 448, getPropertyFromGroup('strumLineNotes', 4, 'x'), 0)
		setObjectCamera('youTxt', 'camHUD')
		setTextSize('youTxt', 50)
		setTextAlignment('youTxt', 'center')
		screenCenter('youTxt', 'y')
		setProperty('youTxt.alpha', 0)
		setObjectOrder('youTxt', getObjectOrder('strumLineNotes') - 1)
		addLuaText('youTxt')
	end
end

function onSongStart()
	if not middlescroll then
		doTweenAlpha('youBG', 'youBG', 0.2, crochet / 1000, 'sineIn')
		doTweenAlpha('you', 'you', 0.3, crochet / 1000, 'sineIn')

		setProperty('youTxt.y', getProperty('youTxt.y') + 50)
		doTweenY('youTxty', 'youTxt', getProperty('youTxt.y') - 50, crochet / 1000, 'circOut')
		doTweenAlpha('youTxt', 'youTxt', 1, crochet / 1000, 'circIn')
	end
end

function onUpdatePost(elapsed)
	if not middlescroll and getProperty('you.alpha') > 0 then setProperty('you.y', getProperty('you.y') - 100 * elapsed) end
end

function onBeatHit()
	if curBeat == 4 and not middlescroll then
		doTweenAlpha('youBGa', 'youBG', 0, crochet / 1000, 'sineOut')
		doTweenAlpha('you', 'you', 0, crochet / 1000, 'sineOut')
		doTweenAlpha('youTxt', 'youTxt', 0, crochet / 1000, 'sineOut')
		doTweenY('youTxty', 'youTxt', getProperty('youTxt.y') + 50, crochet / 1000, 'sineIn')
	end
end

function onTweenCompleted(t)
	if t == 'youBGa' then
		removeLuaSprite('youBG', true)
		removeLuaSprite('you', true)
		removeLuaText('youTxt', true)
	end
end