local bfy = 0
local unready = {3,2,1,0}
local y = -80
local ay = 0
local wasMiddleScroll = false

function onDestroy() if wasMiddleScroll then setPropertyFromClass('backend.ClientPrefs', 'data.middleScroll', true) end end
function onCreate()
	wasMiddleScroll = getPropertyFromClass('backend.ClientPrefs', 'data.middleScroll')
	setPropertyFromClass('backend.ClientPrefs', 'data.middleScroll', false)

	runHaxeCode([[
		function initNotes():Void {
			addHaxeLibrary('StrumNote', 'objects');

			for (s in game.strumLineNotes.members) {
				s.setGraphicSize(s.width / 0.7 * 0.65);
				s.updateHitbox();
			}

			game.callOnScripts('onStrumsSizeChange', [ game.strumLineNotes.members[0].scale.x, game.strumLineNotes.members[0].scale.y ]);

			var redstrums = [];
			var dirs = ['left', 'down', 'up', 'right'];
			var separation = (game.strumLineNotes.members[1].x - game.strumLineNotes.members[0].x) - (game.strumLineNotes.members[0].width * 0.09);

			for (i in 0...game.opponentStrums.length) {
				var yipe = new StrumNote(0, game.opponentStrums.members[i].y - game.opponentStrums.members[i].y, i, 0);
				yipe.setGraphicSize(yipe.width / 0.7 * 0.65);
				yipe.updateHitbox();

				yipe.downScroll = ClientPrefs.data.downScroll;
				yipe.alpha = game.opponentStrums.members[i].alpha;

				game.opponentStrums.add(yipe);
				game.strumLineNotes.insert(4 + i, yipe);
				redstrums.push(yipe);

				yipe.animation.destroyAnimations();
				yipe.animation.addByPrefix('static', 'arrow' + dirs[i].toUpperCase());
				yipe.animation.addByPrefix('pressed', dirs[i] + ' press', 24, false);
				yipe.animation.addByPrefix('confirm', dirs[i] + ' confirm', 24, false);
				yipe.playAnim('static', false);

				yipe.ID = i;
				yipe.centerOrigin();
			}



			game.strumLineNotes.members[0].x -= (separation * 0.6) + 5;

			for (i in 1...game.opponentStrums.length) game.opponentStrums.members[i].x = game.opponentStrums.members[i - 1].x + separation;
			for (i in 0...game.playerStrums.length) game.playerStrums.members[i].x = game.opponentStrums.members[i].x + (separation * (game.opponentStrums.length - redstrums.length));
			for (i in 0...redstrums.length) redstrums[i].x = game.playerStrums.members[i].x + (separation * game.playerStrums.length);



			for (n in game.unspawnNotes) {
				if (!n.isSustainNote) {
					n.setGraphicSize(n.width / 0.7 * 0.65);

					if (n.tail.length > 0) for (t in n.tail) {
						t.setGraphicSize(t.width / 0.7 * 0.65, t.height);
						t.copyX = false;

						if (t.mustPress) t.x = game.playerStrums.members[t.noteData].x + 35;
						else if (t.gfNote) t.x = redstrums[t.noteData].x + 35;
						else t.x = game.opponentStrums.members[t.noteData].x + 35;

						if (t.noteData == 1) t.x -= 1.5;
					}
				}

				n.updateHitbox();

				if (n.gfNote && !n.mustPress) n.noteData += game.opponentStrums.length - redstrums.length;
			}



			// to avoid endless looping
			var animLength = game.singAnimations.length;

			for (i in 0...animLength) game.singAnimations.push(game.singAnimations[i]);
		}

		function endThing():Void {
			for (s in game.playerStrums.members) s.visible = false;

			var ca = game.dad.healthColorArray;
			var dc = FlxColor.fromRGB(ca[0], ca[1], ca[2]);

			game.healthBar.setColors(dc, dc);
		}

		createCallback('initNotes', initNotes);
		createCallback('endThing', endThing);
	]])
end

function onCreatePost()
	bfy = getProperty('boyfriend.y')

	makeLuaSprite('dia1', 'clones/dia1', getProperty('boyfriend.x') - 20, bfy - 85)
	if downscroll then setProperty('dia1.y', getProperty('dia1.y') + 260) end
	setProperty('dia1.visible', false)
	addLuaSprite('dia1', true)

	makeLuaSprite('dia2', 'clones/dia2', getProperty('gf.x') + 35, getProperty('dia1.y'))
	setProperty('dia2.visible', false)
	addLuaSprite('dia2', true)

	makeLuaSprite('dia3', 'clones/dia3', getProperty('gf.x') - 200, getProperty('dia1.y'))
	setProperty('dia3.visible', false)
	addLuaSprite('dia3', true)



	if downscroll then y = -y end
	ay = y * 2

	debugPrint('yoo: '..ay)


	--[[
	ay = y * 2
	for i = 0, getProperty('strumLineNotes.length') - 1 do
		setPropertyFromGroup('strumLineNotes', i, 'y', getPropertyFromGroup('strumLineNotes', i, 'y') + ay)
	end

	
	setProperty('botplayTxt.y', getProperty('botplayTxt.y') - y)
	setProperty('healthBar.y', getProperty('healthBar.y') - y)
	setProperty('healthBar.alpha', 0)
	setProperty('scoreTxt.y', getProperty('scoreTxt.y') - y)
	setProperty('scoreTxt.alpha', 0)

	for i = 1,2 do
		setProperty('iconP'..i..'.y', getProperty('iconP'..i..'.y') - y)
		setProperty('iconP'..i..'.alpha', 0)
	end
	]]--
end
luaDebugMode = true
function onSongStart()
	initNotes()

	onBeatHit()

	doTweenY('intro_hby', 'healthBar', getProperty('healthBar.y') + y, 0.5, 'backOut')
	doTweenAlpha('intro_hba', 'healthBar', 1, 0.5, 'sineOut')
	doTweenY('intro_sty', 'scoreTxt', getProperty('scoreTxt.y') + y, 0.5, 'backOut')
	doTweenAlpha('intro_sta', 'scoreTxt', 1, 0.5, 'sineOut')

	for i = 1,2 do
		doTweenY('intro_ip'..i, 'iconP'..i, getProperty('iconP'..i..'.y') + y, 0.5, 'backOut')
		doTweenAlpha('intro_ipa'..i, 'iconP'..i, 1, 0.5, 'sineOut')
	end
end

function onBeatHit()
	if curBeat == 0 then runTimer('opp1strum', 0.06, 4) end
	if curBeat == 2 then runTimer('opp2strum', 0.06, 4) end
	if curBeat == 7 then runTimer('plrstrum', 0.06, 4) end

	if curBeat == 97 then
		playSound('discordping')
		setProperty('dia1.visible', true)
	end

	if curBeat == 98 then
		playSound('discordping')
		setProperty('dia2.visible', true)
		doTweenAlpha('dia1a', 'dia1', 0, 1, 'sineOut')
		triggerEvent('Camera Follow Pos', '400', '300')
	end

	if curBeat == 100 then
		playSound('discordping')
		setProperty('dia3.visible', true)
		removeLuaSprite('dia2', true)
		triggerEvent('Camera Follow Pos', '580', '300')
	end

	if curBeat == 103 then doTweenAlpha('dia3a', 'dia3', 0, 1, 'sineOut') end

	if curBeat == 108 then
		removeLuaSprite('dia1', true)
		removeLuaSprite('dia3', true)
	end



	if curBeat == 96 then runTimer('itnain', 0.06, getProperty('strumLineNotes.length')) end
	if curBeat == 102 then runTimer('itnaout', 0.06, getProperty('strumLineNotes.length')) end



	if curBeat == 144 then doTweenY('bfy', 'boyfriend', bfy + 20, 4, 'sineOut') end

	if curBeat == 184 then
		doTweenAlpha('sta', 'scoreTxt', 0, 0.6, 'sineIn')
		endThing()
	end
end

function onTimerCompleted(t, l, ll)
	if t == 'itnain' then noteTweenAlpha('tnain'..ll, ll, 0, 0.5, 'sineIn') end
	if t == 'itnaout' then
		local a = 0.3
		if ll > 7 then a = 1 end
		noteTweenAlpha('tnaout'..ll, ll, a, 0.5, 'sineOut')
	end

	if t == 'opp1strum' then
		local i = unready[ll + 1]
		table.remove(unready, ll + 1)
		noteTweenY('opp1strum'..i, i, getPropertyFromGroup('opponentStrums', i, 'y') - ay, 0.6, 'backOut')
		
		if ll == 0 then unready = {3,2,1,0} end
	end

	if t == 'opp2strum' then
		local i = unready[ll + 1]
		table.remove(unready, ll + 1)
		noteTweenY('opp2strum'..i, i + 4, getPropertyFromGroup('opponentStrums', i + 4, 'y') - ay, 0.6, 'backOut')

		if ll == 0 then unready = {3,2,1,0} end
	end

	if t == 'plrstrum' then
		local i = unready[ll + 1]
		table.remove(unready, ll + 1)
		noteTweenY('plrstrum'..i, i + getProperty('opponentStrums.length'), getPropertyFromGroup('playerStrums', i, 'y') - ay, 0.6, 'backOut')
	end
end

function opponentNoteHit(i, d, t, s)
	if not getPropertyFromGroup('notes', i, 'ignoreNote') then
		local h = getHealth()
		if h > 0.1 then setHealth(h - 0.015) end
	end
end

function onUpdatePost()
	if curBeat < 2 then
		for i = 0, getProperty('opponentStrums.length') - 1 do
			setPropertyFromGroup('opponentStrums', i, 'alpha', 0.3)
		end

		for i = 0, getProperty('notes.length') - 1 do
			if not getPropertyFromGroup('notes', i, 'mustPress') then setPropertyFromGroup('notes', i, 'alpha', 0.3) end
		end
	end
end