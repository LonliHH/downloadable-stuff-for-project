local enabled = false
local bop = 1

function onCreate()
	initSaveData('lonlihh', 'amigosmod')
	enabled = getDataFromSave('lonlihh', 'optCamPan', true)
end

function onBeatHit()
	if enabled then
		if curBeat < 388 then
			triggerEvent('Add Camera Zoom', 0.04, 0.05)

			setProperty('camHUD.angle', bop * 3)
			setProperty('camGame.angle', bop * 3)
			doTweenAngle('hudang', 'camHUD', bop, stepCrochet / 500, 'circOut')
			doTweenX('hudx', 'camHUD', -bop * 8, crochet / 1000, 'linear')
			doTweenAngle('cgang', 'camGame', bop, stepCrochet / 500, 'circOut')
			doTweenX('cgx', 'camGame', -bop * 8, crochet / 1000, 'linear')

			bop = -bop
		end

		if curBeat == 388 then
			cancelTween('hudang')
			cancelTween('hudx')
			cancelTween('hudy')
			cancelTween('hudy2')
			cancelTween('cgang')
			cancelTween('cgx')

			setProperty('camHUD.angle', 0)
			setProperty('camHUD.x', 0)
			setProperty('camGame.angle', 0)
			setProperty('camGame.x', 0)
		end
	end
end

function onStepHit()
	if enabled and curBeat < 388 then
		if curStep % 4 == 0 then doTweenY('hudy', 'camHUD', -12, stepCrochet / 500, 'circOut')
		elseif curStep % 4 == 2 then doTweenY('hudy2', 'camHUD', 0, stepCrochet / 500, 'sineIn') end
	end
end

function onSongStart()
	onBeatHit()
	onStepHit()

	if not enabled then
		triggerEvent('Add Camera Zoom', '', '')
		close()
	end
end