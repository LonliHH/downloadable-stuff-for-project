function onCreate()
	addLuaScript('lonlihh/scripts/screen.lua')
end

function onCreatePost()
	makeLuaText('misver', "You're using a version of Psych Engine that Amigos Mod does not support :(\n\nPlease use v0.7.1h as Amigos Mod was made on this version\n\n(You're currently using v"..version..")\n\nSo ya we recommend using that instead because older versions cause backend code bugs, while newer versions cause frontend code bugs\n\n(Press [BACK] to exit)", 1000, 0, 0)
	setObjectCamera('misver', 'camHUD')
	setTextSize('misver', 36)
	setTextAlignment('misver', 'center')
	screenCenter('misver', 'xy')
	setProperty('misver.y', getProperty('misver.y') + 100)
	setProperty('misver.antialiasing', false)
	addLuaText('misver')
	doTweenY('misver', 'misver', getProperty('misver.y') - 100, 1.8, 'circOut')

	playMusic('sadpiano', 1, true)
end

function onUpdate(elapsed)
	if keyJustPressed('back') then exitSong(false) end

	local chx = getProperty('ch.x')
	if chx >= 0 then setProperty('ch.x', -200)
	else setProperty('ch.x', chx + 100 * elapsed) end
end

function onStartCountdown() return Function_Stop end