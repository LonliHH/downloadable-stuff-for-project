local showing = false
local firstPosX = {}

local width = 368
local height = 75
local colWidth = 8
local colAmount = 2
local textMargin = 10
local slideX = 385
local slideIn = 1
local slideOut = 1.3



function onCreate()
	setOstVar('title', nil)

	makeLuaSprite('npBG', nil, (screenWidth - width) + slideX, 20)
	makeGraphic('npBG', width, height, '000000')
	setObjectCamera('npBG', 'camOther')
	setProperty('npBG.alpha', 0.8)
	setProperty('npBG.visible', false)
	addLuaSprite('npBG')
	firstPosX['npBG'] = getProperty('npBG.x')

	for i = 1, colAmount do
		local x
		if i > 1 then x = getProperty('npCol'..(i - 1)..'.x') - colWidth
		else x = getProperty('npBG.x') - colWidth end

		makeLuaSprite('npCol'..i, nil, x, getProperty('npBG.y'))
		makeGraphic('npCol'..i, colWidth, height, 'ffffff')
		setObjectCamera('npCol'..i, 'camOther')
		setProperty('npCol'..i..'.visible', false)
		addLuaSprite('npCol'..i)
		firstPosX['npCol'..i] = getProperty('npCol'..i..'.x')
	end

	makeLuaText('npTxt', 'Now playing:', 800, getProperty('npBG.x') + textMargin, getProperty('npBG.y') + textMargin)
	setObjectCamera('npTxt', 'camOther')
	setTextSize('npTxt', 22)
	setTextAlignment('npTxt', 'left')
	setProperty('npTxt.borderSize', 2)
	setProperty('npTxt.antialiasing', false)
	setProperty('npTxt.visible', false)
	addLuaText('npTxt')
	firstPosX['npTxt'] = getProperty('npTxt.x')

	makeLuaText('npSong', 'SONG HERE', width - 10, getProperty('npTxt.x'), getProperty('npTxt.y') + 26)
	setObjectCamera('npSong', 'camOther')
	setTextSize('npSong', 26)
	setTextAlignment('npSong', 'left')
	setProperty('npSong.borderSize', 3)
	setProperty('npSong.antialiasing', false)
	setProperty('npSong.wordWrap', false)
	setProperty('npSong.visible', false)
	addLuaText('npSong')
	firstPosX['npSong'] = getProperty('npSong.x')

	local file = 'lonlihh/menu_ost.txt'
	if checkFileExists(file) then
		local lines = stringSplit(getTextFromFile(file), '\n')
		for i = 1, #lines do
			if lines[i] ~= '' then
				local entry = stringSplit(lines[i], ',,,')
				local tag = entry[1]
				setOstVar(tag..'.title', entry[2])

				local colors = {}
				for c = 1, colAmount do table.insert(colors, entry[c + 2]) end

				setOstVar(tag..'.colors', colors)
			end
		end
	else missingFile(file) end
end

function onTimerCompleted(t, l, ll)
	if t == 'npShowAndHide' then
		if showing then
			cancelTimer('npHide')
			for comp in pairs(firstPosX) do
				cancelTween(comp..'x')
				cancelTween(comp..'xback')
			end
		end

		showing = true
		updateBar()
		for comp in pairs(firstPosX) do
			setProperty(comp..'.visible', true)
			doTweenX(comp..'x', comp, firstPosX[comp] - slideX, slideIn, 'circOut')
		end

		runTimer('npHide', 2)
	end

	if t == 'npHide' and showing then
		for comp in pairs(firstPosX) do doTweenX(comp..'xback', comp, firstPosX[comp], slideOut, 'quadIn') end
	end
end

function onTweenCompleted(t)
	if t == 'npBGxback' then
		showing = false
		for comp in pairs(firstPosX) do setProperty(comp..'.visible', false) end
	end
end

function updateBar()
	local title = getOstVar('title')
	if title ~= nil then
		local colors = getOstVar(title..'.colors')
		for i = 1, colAmount do setProperty('npCol'..i..'.color', getColorFromHex(colors[i])) end
		setTextString('npTxt', 'Now playing:')
		setTextString('npSong', getOstVar(title..'.title'))
	end
end

function missingFile(file)
	triggerEvent('error msg', getVar('am.errh.msg'):gsub('%[sillyfile%]', file)..'\n'..getVar('am.errh.restartMsg')..';'..getVar('am.errh.title'), 'ok')
	loadSong(songName, -1)
end

function setOstVar(tag, var) setVar('am.menu.ost.'..tag, var) end
function getOstVar(tag) return getVar('am.menu.ost.'..tag) end