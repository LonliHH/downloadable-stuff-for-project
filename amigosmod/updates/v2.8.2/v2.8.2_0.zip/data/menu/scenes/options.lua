local activeScene = false

local selected = 1
local lastSelected = 1
local selectable = false
local transitioning = false

local intro_x = 0
local intro_time = 0



-------------------- OPTIONS --------------------

local touchedAnything = false
local list = {}
local green = 'acff75'
local red = 'ff3b3b'
local guideSize
local guideSizeAdjust = 3
local guideCharLimit = 104

function loadAssets(aa)
	local listFile = 'lonlihh/options_list.txt'
	if checkFileExists(listFile) then
		local checkSave = function(tag, default)
			if getDataFromSave('lonlihh', tag, nil) == nil then setDataFromSave('lonlihh', tag, default) end
		end

		local objOrder = getObjectOrder('sidebar') - 1
		local entries = stringSplit(getTextFromFile(listFile), '\n')
		for i = 1, #entries do
			local data = {}
			local daOpt = stringSplit(entries[i], ' || ')
			local saveTag = daOpt[1]
			local saveType = daOpt[2]
			local saveName = daOpt[3]

			table.insert(data, saveTag)
			table.insert(data, saveType)
			table.insert(data, saveName)
			table.insert(data, daOpt[4]) -- save desc

			if saveType == 'bool' then -- Disabled/Enabled types
				local val = tonumber(daOpt[5]) == 1
				table.insert(data, val)
				checkSave(saveTag, val)
			elseif saveType == 'num' then -- Level/Disabled types
				local val = tonumber(daOpt[5])
				table.insert(data, val)
				table.insert(data, tonumber(daOpt[6])) -- Max level
				checkSave(saveTag, val)
			end

			table.insert(list, data)

			local tag = 'opt'..i
			makeLuaText(tag, saveName, 0, 140, 250 + (100 * (i - 1)))
			setObjectCamera(tag, 'camHUD')
			setTextFont(tag, 'pah.ttf')
			setTextSize(tag, 70)
			setTextAlignment(tag, 'left')
			setProperty(tag..'.antialiasing', aa)
			setProperty(tag..'.alpha', 0)
			setObjectOrder(tag, objOrder)
			addLuaText(tag)
		end
	else missingFile(listFile) end



	-- POINTERS
	makeLuaText('optPointer1', '>', 0, 40, 225)
	setObjectCamera('optPointer1', 'camHUD')
	setTextFont('optPointer1', 'pah.ttf')
	setTextSize('optPointer1', 100)
	setTextAlignment('optPointer1', 'left')
	setProperty('optPointer1.antialiasing', aa)
	setProperty('optPointer1.alpha', 0)
	setObjectOrder('optPointer1', getObjectOrder('sidebar') - 1)
	addLuaSprite('optPointer1')



	-- GUIDE TEXT
	makeLuaSprite('guideBG', nil, 0, 720)
	makeGraphic('guideBG', screenWidth, 50, '000000')
	setObjectCamera('guideBG', 'camHUD')
	setProperty('guideBG.alpha', 0.6)
	setProperty('guideBG.visible', false)
	setObjectOrder('guideBG', getObjectOrder('sidebar') - 2)
	addLuaSprite('guideBG')

	makeLuaText('guide', 'Hi :)', screenWidth - 20, 10, 730)
	setObjectCamera('guide', 'camHUD')
	setTextSize('guide', 20)
	setTextAlignment('guide', 'left')
	setProperty('guide.borderSize', 1.2)
	setProperty('guide.wordWrap', false)
	setProperty('guide.antialiasing', false)
	setProperty('guide.visible', false)
	setObjectOrder('guide', getObjectOrder('guideBG') + 1)
	addLuaSprite('guide')

	guideSize = getTextSize('guide')
end

function missingFile(path)
	triggerEvent('error msg', getVar('am.errh.msg'):gsub('%[sillyfile%]', path)..';'..getVar('am.errh.restartMsg'), 'ok')
	loadSong(songName, -1)
end

function updateOptions()
	for i = 1, #list do
		colorOptionText(i)
		setpos('opt'..i, nil, (250 - (100 * (selected - 1))) + (100 * (i - 1)), 0.5, 'circOut')
	end

	setTextString('guide', list[selected][4])
	setProperty('guide.offset.x', -10)
	doTweenX('guideOX', 'guide.offset', 0, intro_time / 2, 'circOut')

	if #getProperty('guide.text') > guideCharLimit then
		setTextSize('guide', guideSize - guideSizeAdjust)
		setProperty('guide.offset.y', -1)
	else
		setTextSize('guide', guideSize)
		setProperty('guide.offset.y', 0)
	end
end

function colorOptionText(id)
	local opt = list[id]
	local tag = 'opt'..id
	local saveType = opt[2]

	if saveType == 'bool' then
		if getDataFromSave('lonlihh', opt[1]) then doTweenColor(tag..'c', tag, green, 0.25, 'sineOut')
		else doTweenColor(tag..'c', tag, red, 0.25, 'sineOut') end
	elseif saveType == 'num' then
		if getDataFromSave('lonlihh', opt[1]) > 0 then doTweenColor(tag..'c', tag, green, 0.25, 'sineOut')
		else doTweenColor(tag..'c', tag, red, 0.25, 'sineOut') end
	elseif saveType == 'psychBool' then
		if getPropertyFromClass('backend.ClientPrefs', 'data.'..opt[1]) then doTweenColor(tag..'c', tag, green, 0.25, 'sineOut')
		else doTweenColor(tag..'c', tag, red, 0.25, 'sineOut') end
	end
end

function onCreate() precacheMusic('options') end
function onStartCountdown()
	if not activeScene and getVar('am.menu.scene') == 'options' then
		activeScene = true
		touchedAnything = false
		updateVars()
		playAnim('options', 'basic', false)
		setProperty('options.offset.x', 0)
		setProperty('options.offset.y', 0)

		for i = 1, #list do
			updateListItem(i, false)
			doTweenAlpha('opt'..i..'a', 'opt'..i, 1, intro_time, 'sineOut')
		end

		if getVar('am.menu.rushTransition') then setProperty('options.x', getProperty('options.x') + 55) end

		doTweenAngle('optionsR1', 'options', 15, intro_time / 2, 'quadOut')

		addpos('title', nil, -140, intro_time + 0.2, 'backIn')
		addpos('sidebar', -850, nil, intro_time + 0.45, 'sineIn')
		addpos('options', 385, nil, intro_time, 'circOut')
		doTweenY('oyt', 'options', 20, intro_time, 'backInOut')
		addpos('freeplay', -(intro_x+350), nil, intro_time, 'backIn')
		addpos('credits', -(intro_x+350), nil, intro_time, 'backIn')
		addpos('mtitle', 530, nil, intro_time + 0.4, 'backIn')
		addpos('mdesc', 530, nil, intro_time + 0.4, 'backIn')
		addpos('play', 530, nil, intro_time + 0.4, 'backIn')
		addpos('opt', 530, nil, intro_time + 0.4, 'backIn')
		addpos('ppl', 530, nil, intro_time + 0.4, 'backIn')
		addpos('guideBG', nil, -40, intro_time + 0.3, 'backOut')
		addpos('guide', nil, -40, intro_time + 0.3, 'backOut')

		setProperty('optPointer1.x', 40)
		setProperty('guideBG.visible', true)
		setProperty('guide.visible', true)

		cancelTween('bgc')
		cancelTween('bgc3b')

		soundFadeOut('', 0.45, 0)
		doTweenColor('bgc3', 'bg', '3eed3e', intro_time + 0.45, 'sineOut')
	end

	return Function_Stop
end

function onTweenCompleted(t)
	if not activeScene then return end

	if t == 'loadintosong' then
		local daSong = getDataFromSave('lonlihh', 'prev.song', nil)
		if daSong ~= nil then loadSong(daSong, -1) end
	end

	if t == 'optionsR1' then doTweenAngle('optionsR2', 'options', 0, intro_time / 2, 'backOut') end

	if t == 'xsidebar' then
		transitioning = false
		selectable = true
		selected = lastSelected
		updateOptions()
		onTweenCompleted('po1-1')

		setProperty('credits.visible', false)
		setProperty('sidebar.visible', false)
		setProperty('title.visible', false)
		setProperty('mtitle.visible', false)
		setProperty('mdesc.visible', false)
		setProperty('play.visible', false)
		setProperty('opt.visible', false)
		setProperty('ppl.visible', false)

		doTweenAlpha('pointer1', 'optPointer1', 1, intro_time - 0.2, 'sineOut')

		playMusic('options', 1, true)
		setVar('am.menu.ost.title', 'options')
		runTimer('npShowAndHide', 0)

		setVar('am.menu.rushTransition', false)
	end

	if t == 'xoptPointer1' then onTweenCompleted('po1-2') end

	if t == 'po1-1' then doTweenX('po1-2', 'optPointer1', 70, 0.6, 'sineInOut') end
	if t == 'po1-2' then doTweenX('po1-1', 'optPointer1', 40, 0.6, 'sineInOut') end
end

function updateListItem(id, toggle)
	local opt = list[id]
	if opt[2] == 'bool' then
		if toggle then
			local val = not getDataFromSave('lonlihh', opt[1])
			setDataFromSave('lonlihh', opt[1], val)
			optionChanged(opt[1], opt[2], val)
		end
	elseif opt[2] == 'num' then
		local max = opt[6]
		local lvl = getDataFromSave('lonlihh', opt[1])
		local oldLvl = lvl
		if toggle then lvl = lvl + 1 end

		if lvl > max then lvl = 0 end

		if lvl > 0 then setTextString('opt'..id, opt[3]..lvl)
		else setTextString('opt'..id, opt[3]..'Disabled') end

		setDataFromSave('lonlihh', opt[1], lvl)
		if lvl ~= oldLvl then optionChanged(opt[1], opt[2], lvl) end
	elseif opt[2] == 'psychBool' then
		if toggle then
			local val = not getPropertyFromClass('backend.ClientPrefs', 'data.'..opt[1])
			setPropertyFromClass('backend.ClientPrefs', 'data.'..opt[1], val)
			optionChanged(opt[1], opt[2], val)
		end
	end
end

function onUpdate()
	if not activeScene then return end

	if selectable then
		if keyJustPressed('accept') then
			touchedAnything = true
			playSound('clickText')
			updateListItem(selected, true)
			colorOptionText(selected)
		elseif keyJustPressed('down') or keyJustPressed('right') then
			selected = selected + 1
			if selected > #list then selected = 1 end

			playSound('scrollMenu')
			updateOptions()
		elseif keyJustPressed('up') or keyJustPressed('left') then
			selected = selected - 1
			if selected < 1 then selected = #list end

			playSound('scrollMenu')
			updateOptions()
		elseif keyJustPressed('reset') then
			-- RESET ALL OPTIONS
			for i = 1, #list do
				local opt = list[i]
				if not stringStartsWith(opt[2], 'psych') then -- only mod-saveable options are reset
					setDataFromSave('lonlihh', opt[1], opt[5])
					updateListItem(i, false)
				end
			end

			touchedAnything = true
			debugPrint('Reset all options.')
			playSound('cancelMenu')
			updateOptions()
		elseif keyJustPressed('back') then
			-- TRANSITION FROM OPTIONS TO MAIN MENU
			transitioning = true
			selectable = false
			updateOptions()
			for i = 1, #list do updateListItem(i, false) end
			playSound('cancelMenu')

			setpos('optPointer1', 40, nil, 0.15, 'circOut')

			if touchedAnything then
				flushSaveData('lonlihh')
				runTimer('playSaveAnim', 0)
			end

			if getDataFromSave('lonlihh', 'prev.enabled', false) then
				setDataFromSave('lonlihh', 'prev.enabled', false)
				setDataFromSave('lonlihh', 'lastScene', 'freeplay')

				if touchedAnything then runTimer('fadeSaveAnim', 0.65) end

				doTweenAlpha('loadintosong', 'lsc', 1, 0.6, 'sineOut')
				soundFadeOut('', 0.59, 0)
				return
			end

			cancelTween('xoptPointer1')
			cancelTween('po1-1')
			cancelTween('po1-2')

			local white = getColorFromHex('ffffff')
			for i = 1, #list do
				cancelTween('opt'..i..'c')
				setProperty('opt'..i..'.color', white)
				doTweenAlpha('opt'..i..'a', 'opt'..i, 0, intro_time, 'sineIn')
			end

			setProperty('freeplay.visible', true)
			setProperty('credits.visible', true)
			setProperty('sidebar.visible', true)
			setProperty('title.visible', true)
			setProperty('mtitle.visible', true)
			setProperty('mdesc.visible', true)
			setProperty('play.visible', false)
			setProperty('opt.visible', true)
			setProperty('ppl.visible', false)

			doTweenAlpha('optP1', 'optPointer1', 0, intro_time, 'sineIn')

			cancelTween('bgc')
			cancelTween('bgc3')

			setpos('freeplay', 50, 180, intro_time + 0.2, 'circOut')
			setpos('options', 50, 340, intro_time, 'circOut')
			setpos('credits', 50, 500, intro_time + 0.4, 'circOut')
			addpos('title', 0, 140, intro_time + 0.5, 'backOut')
			setpos('sidebar', -190, -270, intro_time + 0.45, 'sineOut')
			addpos('mtitle', -530, 0, intro_time + 0.4, 'backOut')
			addpos('mdesc', -530, 0, intro_time + 0.4, 'backOut')
			addpos('play', -530, 0, intro_time + 0.4, 'backOut')
			addpos('opt', -530, 0, intro_time + 0.4, 'backOut')
			addpos('ppl', -530, 0, intro_time + 0.4, 'backOut')
			doTweenColor('bgc3b', 'bg', getVar('am.menu.bg.default_color'), intro_time + 0.5, 'sineOut')

			addpos('guideBG', nil, 40, intro_time + 0.3, 'backIn')
			addpos('guide', nil, 40, intro_time + 0.3, 'backIn')

			soundFadeOut('', intro_time, 0)
			runTimer('backtomenus', intro_time)

			lastSelected = selected
			selected = 2
			saveVars()
			changeScene('menu')
		end
	end
end

function onTimerCompleted(t, l, ll)
	if not activeScene then return end

	if t == 'fadeSaveAnim' then doTweenAlpha('savedFadeOut', 'saved', 0, 0.15, 'sineOut') end
end













function changeScene(name)
	activeScene = false
	setVar('am.menu.scene', name)
	startCountdown()
end

function saveVars()
	setVar('am.menu.selected', selected)
	setVar('am.menu.selectable', selectable)
	setVar('am.menu.transitioning', transitioning)
	setVar('am.menu.intro_x', intro_x)
	setVar('am.menu.intro_time', intro_time)
end

function getMenuVar(tag) return getVar('am.menu.'..tag) end
function updateVars()
	selectable = getMenuVar('selectable')
	transitioning = getMenuVar('transitioning')
	intro_x = getMenuVar('intro_x')
	intro_time = getMenuVar('intro_time')
end










-------------------- LAZY STUFF --------------------

function addpos(obj, x, y, dur, ease)
	if x ~= nil then doTweenX('x'..obj, obj, getProperty(obj..'.x') + x, dur, ease) end
	if y ~= nil then doTweenY('y'..obj, obj, getProperty(obj..'.y') + y, dur, ease) end
end

function setpos(obj, x, y, dur, ease)
	if x ~= nil and getProperty(obj..'.x') ~= x then doTweenX('x'..obj, obj, x, dur, ease) end
	if y ~= nil and getProperty(obj..'.y') ~= y then doTweenY('y'..obj, obj, y, dur, ease) end
end

function tweenScale(obj, scale, dur, ease)
	if getProperty(obj..'.scale.x') ~= scale then doTweenX('sx'..obj, obj..'.scale', scale, dur, ease) end
	if getProperty(obj..'.scale.y') ~= scale then doTweenY('sy'..obj, obj..'.scale', scale, dur, ease) end
end

----------------------------------------------------