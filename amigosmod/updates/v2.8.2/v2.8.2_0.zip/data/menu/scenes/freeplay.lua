local activeScene = false

local selected = 1
local lastSelected = 1
local selectable = false
local transitioning = false

local intro_x = 0
local intro_time = 0

local songs = {}
local songTitles = {}
local songIcons = {}
local songIconOffsetX = {}
local songIconOffsetY = {}
local songShaders = {}
local songCategories = {}
local songColors = {}
local songBPM = {}
local songDelays = {}
local categoryTitles = {}
local curCategory = ''
local freeplayDistance = 150

local curBPM = 0
local curSongPreview = ''
local nextSongPreview = ''
local songFadeTime = 0.4

local centeredIconX = nil
local centeredIconY = nil



function loadAssets(aa)
	local realShadersEnabled = (shadersEnabled and getDataFromSave('lonlihh', 'shaderLvl') > 0)

	local fpath = 'lonlihh/freeplay/'
	local dataFile = fpath..'songs.txt'
	if checkFileExists(dataFile) then
		local previewAllowed = (getDataFromSave('lonlihh', 'songPreview') and getDataFromSave('lonlihh', 'preloadPreview'))

		local offs = stringSplit(getTextFromFile(dataFile), '\n')
		for i = 1, #offs do
			if offs[i] ~= '' then
				local entry = stringSplit(offs[i], ' / ')
				table.insert(songs, entry[1])
				songTitles[entry[1]] = titleSong(entry[1])

				local dat = stringSplit(entry[2], ',')
				table.insert(songIconOffsetX, tonumber(dat[1]))
				table.insert(songIcons, dat[2])

				if realShadersEnabled then table.insert(songShaders, entry[3]) end

				table.insert(songCategories, entry[4])
				table.insert(songColors, entry[5])
				table.insert(songBPM, tonumber(entry[6]))
				table.insert(songDelays, tonumber(entry[7]))

				if previewAllowed then
					local prevsong = 'previews/'..entry[1]
					if checkFileExists('music/'..prevsong..'.ogg') then precacheMusic(prevsong) end
				end
			end
		end
	else missingFile(dataFile) end

	local ctgDataFile = fpath..'categories.txt'
	if checkFileExists(ctgDataFile) then
		local entries = stringSplit(getTextFromFile(ctgDataFile), '\n')
		for i = 1, #entries do
			if entries[i] ~= '' then
				local dat = stringSplit(entries[i], '=')
				categoryTitles[dat[1]] = dat[2]
			end
		end
	else missingFile(ctgDataFile) end

	local offYFile = fpath..'icon_y_offsets.txt'
	if checkFileExists(offYFile) then
		local entries = stringSplit(getTextFromFile(offYFile), '\n')
		for i = 1, #entries do
			if entries[i] ~= '' then
				local entry = stringSplit(entries[i], '=')
				songIconOffsetY[entry[1]] = tonumber(entry[2])
			end
		end
	else missingFile(offYFile) end

	for i = 1, #songs do
		local tag = 'week'..i
		makeLuaSprite(tag, 'songs/'..songs[i], 0, 870 + (freeplayDistance * (i - 1)))
		setObjectCamera(tag, 'camHUD')
		screenCenter(tag, 'x')
		setProperty(tag..'.visible', false)
		addLuaSprite(tag)

		if realShadersEnabled and songShaders[i] ~= '' then
			initLuaShader(songShaders[i])
			setSpriteShader(tag, songShaders[i])
		end
	end

	for i = 1, #songIcons do
		local tag = 'weekIcon-'..songIcons[i]

		if not luaSpriteExists(tag) then
			loadIcon(tag, songIcons[i], 0, getProperty('week1.y'))
			setObjectCamera(tag, 'camHUD')
			addAnimationByPrefix(tag, 'idle', 'def', 24, false)
			addAnimationByPrefix(tag, 'done', 'win', 24, false)
			playAnim(tag, 'idle', false)
			screenCenter(tag, 'x')
			setProperty(tag..'.alpha', 0)
			setProperty(tag..'.offset.y', songIconOffsetY[songIcons[i]])
			addLuaSprite(tag)
		end
	end

	makeLuaSprite('fpCtgBG', nil, 0, 165)
	makeGraphic('fpCtgBG', screenWidth, 70, '000000')
	setObjectCamera('fpCtgBG', 'camHUD')
	setProperty('fpCtgBG.alpha', 0)
	setProperty('fpCtgBG.visible', false)
	setObjectOrder('fpCtgBG', getObjectOrder('sidebar') - 1)
	addLuaSprite('fpCtgBG')

	makeLuaText('fpCtg', '', screenWidth, 0, 170)
	setObjectCamera('fpCtg', 'camHUD')
	setTextSize('fpCtg', 48)
	setTextAlignment('fpCtg', 'center')
	setProperty('fpCtg.borderSize', 3)
	setTextFont('fpCtg', 'fnf.ttf')
	setProperty('fpCtg.antialiasing', aa)
	setProperty('fpCtg.alpha', 0)
	setProperty('fpCtg.visible', false)
	setObjectOrder('fpCtg', getObjectOrder('fpCtgBG') + 1)
	addLuaText('fpCtg')

	makeLuaSprite('fpStatsBG', nil, 0, screenHeight + 50)
	makeGraphic('fpStatsBG', screenWidth, 50, '000000')
	setObjectCamera('fpStatsBG', 'camHUD')
	setProperty('fpStatsBG.alpha', 0.6)
	setProperty('fpStatsBG.visible', false)
	setObjectOrder('fpStatsBG', getObjectOrder('sidebar') - 2)
	addLuaSprite('fpStatsBG')

	makeLuaText('fpStats', '', screenWidth, 0, screenHeight - 27)
	setObjectCamera('fpStats', 'camHUD')
	setTextSize('fpStats', 19)
	setTextAlignment('fpStats', 'center')
	setTextBorder('fpStats', 0, '000000', '')
	setProperty('fpStats.antialiasing', false)
	setProperty('fpStats.alpha', 0)
	setProperty('fpStats.visible', false)
	setObjectOrder('fpStats', getObjectOrder('fpStatsBG') + 1)
	addLuaText('fpStats')
end

function missingFile(path)
	triggerEvent('error msg', getVar('am.errh.msg'):gsub('%[sillyfile%]', path)..'\n'..getVar('am.errh.restartMsg')..';'..getVar('am.errh.title'), 'ok')
	restartSong(true)
end

function loadIcon(name, path, x, y)
	local pth = 'icons/icon-'..path
	if not checkFileExists('images/'..pth..'.png') or not checkFileExists('images/'..pth..'.xml') then pth = '../lonlihh/assets/hidden' end
	makeAnimatedLuaSprite(name, pth, x, y)
end

function titleSong(str)
	local arr = stringSplit(str, '-')
	if #arr == 1 then return str:gsub("^%l", string.upper) end

	for i = 1, #arr do arr[i] = arr[i]:gsub("^%l", string.upper) end
	return table.concat(arr, ' ')
end


function onStartCountdown()
	if not activeScene and getVar('am.menu.scene') == 'freeplay' then
		activeScene = true
		updateVars()
		playAnim('freeplay', 'basic', false)

		if getVar('am.menu.rushTransition') then setProperty('freeplay.x', getProperty('freeplay.x') + 110) end

		doTweenAngle('freeplayR1', 'freeplay', 15, intro_time / 2, 'quadOut')

		setProperty('fpCtgBG.visible', true)
		setProperty('fpCtg.visible', true)
		setProperty('fpStatsBG.visible', true)
		setProperty('fpStats.visible', true)

		addpos('title', nil, -140, intro_time + 0.2, 'backIn')
		addpos('sidebar', -850, nil, intro_time + 0.45, 'sineIn')
		addpos('freeplay', 385, nil, intro_time, 'circOut')
		doTweenY('fpyt', 'freeplay', 20, intro_time, 'backInOut')
		addpos('options', -(intro_x+350), nil, intro_time, 'backIn')
		addpos('credits', -(intro_x+350), nil, intro_time, 'backIn')
		addpos('mtitle', 530, nil, intro_time + 0.4, 'backIn')
		addpos('mdesc', 530, nil, intro_time + 0.4, 'backIn')
		addpos('play', 530, nil, intro_time + 0.4, 'backIn')
		addpos('opt', 530, nil, intro_time + 0.4, 'backIn')
		addpos('ppl', 530, nil, intro_time + 0.4, 'backIn')
		setpos('fpStatsBG', nil, screenHeight - 35, intro_time + 0.3, 'backOut')

		doTweenAlpha('fpStatsa', 'fpStats', 1, intro_time, 'sineOut')
		doTweenAlpha('fpCtgBGa', 'fpCtgBG', 0.3, intro_time, 'sineOut')
		doTweenAlpha('fpCtga', 'fpCtg', 1, intro_time, 'sineOut')

		for i = 1, #songs do
			cancelTween('weekFadeIn'..i)
			setProperty('week'..i..'.alpha', 0)
			setProperty('week'..i..'.visible', true)
			doTweenAlpha('weekFadeIn'..i, 'week'..i, 1, intro_time + 0.2, 'sineIn')
			addpos('week'..i, nil, -600, intro_time + 0.3, 'backInOut')
		end

		if centeredIconY == nil then centeredIconY = getProperty('weekIcon-'..songIcons[1]..'.y') - 600 end

		for icon in pairs(songIconOffsetY) do
			setProperty('weekIcon-'..icon..'.y', centeredIconY)
		end

		if getDataFromSave('lonlihh', 'newScoreSave', false) then
			setDataFromSave('lonlihh', 'newScoreSave', false)
			flushSaveData('amstats')
			runTimer('playSaveAnim', 0.8)
		end
	end

	return Function_Stop
end

function onTweenCompleted(t)
	if not activeScene then return end

	if t == 'freeplayR1' then doTweenAngle('freeplayR2', 'freeplay', 0, intro_time / 2, 'backOut') end

	if t == 'loadintosong' then
		setDataFromSave('lonlihh', 'lastScene', getVar('am.menu.scene'))
		setDataFromSave('lonlihh', 'freeplayRush_lastSelected', selected)

		if songs[selected] ~= getDataFromSave('lonlihh', 'prev.song', nil) then setPropertyFromClass('states.PlayState', 'deathCounter', 0) end

		preloadSongAssets()
	end

	if t == 'xsidebar' then
		if not getVar('am.menu.rushTransition') then
			transitioning = false
			selectable = true
			updateFreeplay()
		else rushScroll() end

		for icon in pairs(songIconOffsetY) do onTweenCompleted(icon..'2icna') end

		setProperty('options.visible', false)
		setProperty('credits.visible', false)
		setProperty('sidebar.visible', false)
		setProperty('title.visible', false)
		setProperty('mtitle.visible', false)
		setProperty('mdesc.visible', false)
		setProperty('play.visible', false)
		setProperty('opt.visible', false)
		setProperty('ppl.visible', false)

		setVar('am.menu.rushTransition', false)
	end

	if stringEndsWith(t, 'icna') then
		for icon in pairs(songIconOffsetY) do
			if t == icon..'1icna' then doTweenAngle(icon..'2icna', 'weekIcon-'..icon, 10, 0.8, 'sineInOut') end
			if t == icon..'2icna' then doTweenAngle(icon..'1icna', 'weekIcon-'..icon, -10, 0.8, 'sineInOut') end
		end
	end
end

function preloadSongAssets()
	setTextString('loadTxt', 'Loading pictures...')

	local imgPath = 'data/'..songs[selected]..'/preloadImg.txt'
	if checkFileExists(imgPath) then
		local assets = stringSplit(getTextFromFile(imgPath), ';')
		for i = 1, #assets do precacheImage(assets[i]) end
	end

	runTimer('loadsongsounds', 0.05)
end

function preloadSongSounds()
	setTextString('loadTxt', 'Loading sounds...')
	local sndPath = 'data/'..songs[selected]..'/preloadSnd.txt'
	if checkFileExists(sndPath) then
		local assets = stringSplit(getTextFromFile(sndPath), ';')
		for i = 1, #assets do precacheSound(assets[i]) end
	end

	runTimer('loadintosongagain', 0.05)
end

local camBoomAngle = -4
function onTimerCompleted(t, l, ll)
	if t == 'invisSongs' then
		for i = 1, #songs do
			setProperty('week'..i..'.visible', false)
			setProperty('week'..i..'.alpha', 1)
		end
	end

	if not activeScene then return end

	if t == 'musForceFadeOut' then
		local vol = getPropertyFromClass('flixel.FlxG', 'sound.music.volume')
		if vol > 0 then setPropertyFromClass('flixel.FlxG', 'sound.music.volume', vol - 0.0834) end
	end

	if t == 'musFadeOut' and nextSongPreview ~= '' then
		soundFadeIn('', 0.0001, 1)
		playMusic(nextSongPreview, 1, true)
		curSongPreview = nextSongPreview

		curBPM = songBPM[selected]
		runTimer('camBoom', songDelays[selected])
	end

	if t == 'camBoom' then
		local weekTag = 'week'..selected

		setProperty('camHUD.zoom', 1.05)
		setProperty(weekTag..'.angle', camBoomAngle)
		setProperty(weekTag..'.scale.x', 1.08)
		setProperty(weekTag..'.scale.y', 1.08)
		doTweenZoom('camHUDz', 'camHUD', 1, curBPM, 'circOut')
		doTweenAngle(weekTag..'ang', weekTag, 0, curBPM, 'circOut')
		doTweenX(weekTag..'sx', weekTag..'.scale', 1, curBPM, 'circOut')
		doTweenY(weekTag..'sy', weekTag..'.scale', 1, curBPM, 'circOut')
		runTimer('camBoom', curBPM)

		camBoomAngle = -camBoomAngle
	end

	if t == 'loadsongsounds' then preloadSongSounds() end
	if t == 'loadintosongagain' then
		local msg
		local msgs = getDataFromSave('amcache', 'load_msgs', nil)
		if msgs ~= nil then
			local avoidMsg = getDataFromSave('lonlihh', 'avoidLoadTxt', nil)
			if avoidMsg == nil then msg = msgs[getRandomInt(1, #msgs)]
			else while true do
				msg = msgs[getRandomInt(1, #msgs)]
				if msg ~= avoidMsg then break end
			end end

			setTextString('loadTxt', msg)
			setDataFromSave('lonlihh', 'lastLoadTxt', msg)
		else
			local coolReplacement = 'Uhm'
			triggerEvent('error msg', getVar('am.errh.msg'):gsub('%[sillyfile%]', 'lonlihh/load_msgs.txt')..'\nUhm...'..';'..getVar('am.errh.title'), 'ok')
			setDataFromSave('lonlihh', 'lastLoadTxt', coolReplacement)
			setTextString('loadTxt', coolReplacement)
		end

		loadSong(songs[selected], -1)
	end

	if t == 'rushScroll' then
		selected = selected + 1
		playSound('scrollMenu')
		updateFreeplay()

		runTimer('rushScroll_free', 0.15)
	end

	if t == 'rushScroll_free' then
		transitioning = false
		selectable = true
	end
end

------------------------- FREEPLAY -------------------------

local ratingReplacements = nil
local centeredWeekX = nil
local songsY = nil

function updateFreeplay()
	if ratingReplacements == nil then ratingReplacements = getVar('am.scoreTxt.replacements') end
	if centeredIconX == nil then centeredIconX = getProperty('weekIcon-'..songIcons[1]..'.x') end
	if centeredWeekX == nil then
		centeredWeekX = {}
		for i = 1, #songs do table.insert(centeredWeekX, getProperty('week'..i..'.x')) end
	end
	if songsY == nil then
		songsY = {}
		for i = 1, #songs do
			table.insert(songsY, getProperty('week'..i..'.y'))
		end
	end

	local daSong = songs[selected]
	local score = getDataFromSave('amstats', daSong..'.score', 0)
	local misses = getDataFromSave('amstats', daSong..'.misses', 0)
	local acc = getDataFromSave('amstats', daSong..'.acc', 0)
	local rate = ratingReplacements[getDataFromSave('amstats', daSong..'.rate', '?')]
	local ratefc = getDataFromSave('amstats', daSong..'.ratefc', '?')
	local deaths = getDataFromSave('amstats', daSong..'.deaths', 0)
	setTextString('fpStats', 'Song: '..songTitles[daSong]..' | Score: '..score..' | Misses: '..misses..' | Accuracy: '..acc..'% | Rating: '..rate..' ('..ratefc..') | Deaths: '..deaths)

	doTweenColor('bgc', 'bg', songColors[selected], songFadeTime, 'sineOut')
	if getDataFromSave('lonlihh', 'songPreview') then
		cancelTimer('camBoom')
		soundFadeOut('', songFadeTime, 0)
		nextSongPreview = 'previews/'..daSong
		runTimer('musFadeOut', songFadeTime)
	end

	for icon in pairs(songIconOffsetY) do
		if icon == songIcons[selected] then
			doTweenAlpha(icon..'a', 'weekIcon-'..icon, 1, 0.3, 'circOut')
			doTweenX(icon..'x', 'weekIcon-'..icon, centeredIconX + songIconOffsetX[selected], 0.5, 'circOut')

			if getDataFromSave('amstats', daSong..'.done', false) then playAnim('weekIcon-'..icon, 'done', false)
			else playAnim('weekIcon-'..icon, 'idle', false) end
		else
			doTweenAlpha(icon..'a', 'weekIcon-'..icon, 0, 0.3, 'circOut')
			doTweenX(icon..'x', 'weekIcon-'..icon, centeredIconX, 0.5, 'circOut')
		end
	end


	local newCtg = songCategories[selected]
	if curCategory ~= newCtg then
		setProperty('fpCtgBG.offset.y', -20)
		setProperty('fpCtg.offset.y', -20)
		doTweenY('fpCtgBGy', 'fpCtgBG.offset', 0, 0.5, 'circOut')
		doTweenY('fpCtgy', 'fpCtg.offset', 0, 0.5, 'circOut')
		setTextString('fpCtg', categoryTitles[newCtg])
		curCategory = newCtg
	end


	local mult = freeplayDistance * (selected - 1)
	for i = 1, #songs do
		local weekY = songsY[i] - mult

		if i == selected then
			setpos('week'..i, centeredWeekX[i] - 125, weekY, 0.5, 'circOut')
			doTweenAlpha('week'..i..'a', 'week'..i, 1, 0.5, 'circOut')
		else
			setpos('week'..i, centeredWeekX[i], weekY, 0.5, 'circOut')
			doTweenAlpha('week'..i..'a', 'week'..i, 0.5, 0.5, 'circOut')
		end
	end
end

------------------------------------------------------------

function rushScroll()
	lastSelected = getDataFromSave('lonlihh', 'freeplayRush_lastSelected', 1)
	selected = 0
	runTimer('rushScroll', 0.08, lastSelected)
end

function onUpdate()
	if not activeScene then return end

	for i = 1, #songShaders do if songShaders[i] ~= '' then setShaderFloat('week'..i, 'iTime', os.clock()) end end

	if selectable then
		if keyJustPressed('accept') then
			transitioning = true
			selectable = false
			playSound('scrollMenu')
			runTimer('musForceFadeOut', 0.05, 12)

			doTweenAlpha('loadintosong', 'lsc', 1, 0.6, 'sineOut')
			doTweenAlpha('loadintosongTxt', 'loadTxt', 1, 0.6, 'sineOut')
		elseif keyJustPressed('down') then
			selected = selected + 1
			if selected > #songs then selected = 1 end

			playSound('scrollMenu')
			updateFreeplay()
		elseif keyJustPressed('up') then
			selected = selected - 1
			if selected < 1 then selected = #songs end

			playSound('scrollMenu')
			updateFreeplay()
		elseif keyJustPressed('back') then
			-- TRANSITION FROM FREEPLAY TO MAIN MENU
			transitioning = true
			selectable = false
			lastSelected = selected
			updateFreeplay()

			playSound('cancelMenu')

			for i = 1, #songs do
				local mult = freeplayDistance * (i - 1)
				cancelTween('week'..i..'a')
				cancelTween('xweek'..i)
				cancelTween('xweekIcon-'..songIcons[i])

				doTweenAlpha('awi'..i, 'weekIcon-'..songIcons[i], 0, intro_time, 'sineOut')
				doTweenAlpha('week'..i..'a', 'week'..i, 0, intro_time, 'sineOut')

				--addpos('week'..i, nil, 600, intro_time + 0.3, 'backInOut')
				setpos('week'..i, centeredWeekX[i], mult + (900 - (150 * (selected - 1))), intro_time + 0.3, 'backInOut')
			end

			runTimer('invisSongs', intro_time + 0.31)

			setProperty('options.visible', true)
			setProperty('credits.visible', true)
			setProperty('sidebar.visible', true)
			setProperty('title.visible', true)
			setProperty('mtitle.visible', true)
			setProperty('mdesc.visible', true)
			setProperty('play.visible', true)
			setProperty('opt.visible', false)
			setProperty('ppl.visible', false)

			setpos('freeplay', 50, 180, intro_time, 'circOut')
			setpos('options', 50, 340, intro_time + 0.2, 'circOut')
			setpos('credits', 50, 500, intro_time + 0.4, 'circOut')
			addpos('title', 0, 140, intro_time + 0.5, 'backOut')
			setpos('sidebar', -190, -270, intro_time + 0.45, 'sineOut')
			addpos('mtitle', -530, 0, intro_time + 0.4, 'backOut')
			addpos('mdesc', -530, 0, intro_time + 0.4, 'backOut')
			addpos('play', -530, 0, intro_time + 0.4, 'backOut')
			addpos('opt', -530, 0, intro_time + 0.4, 'backOut')
			addpos('ppl', -530, 0, intro_time + 0.4, 'backOut')
			setpos('fpStatsBG', nil, screenHeight + 50, intro_time + 0.3, 'backIn')

			doTweenAlpha('fpStatsa', 'fpStats', 0, intro_time, 'sineIn')
			doTweenAlpha('fpCtgBGa', 'fpCtgBG', 0, intro_time, 'sineIn')
			doTweenAlpha('fpCtga', 'fpCtg', 0, intro_time, 'sineIn')

			if getDataFromSave('lonlihh', 'songPreview') then
				runTimer('backtomenus', intro_time)
				soundFadeOut('', intro_time - 0.1, 0)
				curSongPreview = ''
				nextSongPreview = ''
			end

			cancelTween('bgc')
			cancelTween('bgc3')
			cancelTween('bgc3b')
			doTweenColor('bgc', 'bg', getVar('am.menu.bg.default_color'), intro_time + 0.5, 'sineOut')

			selected = 1
			saveVars()
			changeScene('menu')
		elseif keyJustPressed('reset') then
			-- RESET SONG SCORE
			local daSong = songs[selected]
			setDataFromSave('amstats', daSong..'.score', 0)
			setDataFromSave('amstats', daSong..'.misses', 0)
			setDataFromSave('amstats', daSong..'.acc', 0)
			setDataFromSave('amstats', daSong..'.rate', '?')
			setDataFromSave('amstats', daSong..'.ratefc', '?')
			setDataFromSave('amstats', daSong..'.deaths', 0)

			debugPrint('Reset song score.')
			flushSaveData('amstats')
			runTimer('playSaveAnim', 0)
			playSound('cancelMenu')
			updateFreeplay()
		end
	end
end













function changeScene(name)
	activeScene = false
	setVar('am.menu.scene', name)
	startCountdown()
end

function saveVars()
	setVar('am.menu.selected', selected)
	setVar('am.menu.selectable', selectable)
	setVar('am.menu.transitioning', transitioning)
end

function getMenuVar(tag) return getVar('am.menu.'..tag) end
function updateVars()
	selected = lastSelected
	selectable = getMenuVar('selectable')
	transitioning = getMenuVar('transitioning')

	intro_x = getMenuVar('intro_x')
	intro_time = getMenuVar('intro_time')
end







-------------------- LAZY STUFF --------------------

function addpos(obj, x, y, dur, ease)
	if x ~= nil then doTweenX('x'..obj, obj, getProperty(obj..'.x') + x, dur, ease) end
	if y ~= nil then doTweenY('y'..obj, obj, getProperty(obj..'.y') + y, dur, ease) end
end

function setpos(obj, x, y, dur, ease)
	if x ~= nil and getProperty(obj..'.x') ~= x then doTweenX('x'..obj, obj, x, dur, ease) end
	if y ~= nil and getProperty(obj..'.y') ~= y then doTweenY('y'..obj, obj, y, dur, ease) end
end

function tweenScale(obj, scale, dur, ease)
	if getProperty(obj..'.scale.x') ~= scale then doTweenX('sx'..obj, obj..'.scale', scale, dur, ease) end
	if getProperty(obj..'.scale.y') ~= scale then doTweenY('sy'..obj, obj..'.scale', scale, dur, ease) end
end

----------------------------------------------------