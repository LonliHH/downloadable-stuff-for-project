local activeScene = false

local selected = 0
local selectable = false
local transitioning = false

local intro_x = 0
local intro_time = 0




function loadAssets()
	makeLuaSprite('cbg')
	makeGraphic('cbg', 1200, 580, '000000')
	setObjectCamera('cbg', 'camHUD')
	screenCenter('cbg', 'xy')
	setProperty('cbg.alpha', 0)
	setProperty('cbg.visible', false)
	addLuaSprite('cbg')

	makeAnimatedLuaSprite('cborder', 'menu/creditsBorder', 20, 54)
	setObjectCamera('cborder', 'camHUD')
	addAnimationByPrefix('cborder', 'idle', 'idle', 3, true)
	playAnim('cborder', 'idle', false)
	setProperty('cborder.alpha', 0)
	setProperty('cborder.visible', false)
	addLuaSprite('cborder')

	makeAnimatedLuaSprite('cpageL', 'menu/creditsPage', 280, -190)
	setObjectCamera('cpageL', 'camHUD')
	addAnimationByPrefix('cpageL', 'idle', 'idle', 3, true)
	playAnim('cpageL', 'idle', false)
	setProperty('cpageL.visible', false)
	addLuaSprite('cpageL')

	makeAnimatedLuaSprite('cpageR', 'menu/creditsPage', 905, -190)
	setObjectCamera('cpageR', 'camHUD')
	addAnimationByIndices('cpageR', 'idle', 'idle', '2,0,1', 3, true)
	playAnim('cpageR', 'idle', false)
	setProperty('cpageR.flipX', true)
	setProperty('cpageR.visible', false)
	addLuaSprite('cpageR')

	makeLuaText('cnameOut', 'your mom', screenWidth, 205, 205)
	setObjectCamera('cnameOut', 'camHUD')
	setTextFont('cnameOut', '8bitarcade.ttf')
	setTextSize('cnameOut', 100)
	setTextColor('cnameOut', '888888')
	setTextBorder('cnameOut', 0, '000000', '')
	setTextAlignment('cnameOut', 'center')
	setProperty('cnameOut.antialiasing', false)
	setProperty('cnameOut.alpha', 0)
	setProperty('cnameOut.visible', false)
	addLuaText('cnameOut')

	makeLuaText('cnameIn', 'your mom', screenWidth, 200, 200)
	setObjectCamera('cnameIn', 'camHUD')
	setTextFont('cnameIn', '8bitarcade.ttf')
	setTextSize('cnameIn', 100)
	setTextBorder('cnameIn', 0, '000000', '')
	setTextAlignment('cnameIn', 'center')
	setProperty('cnameIn.antialiasing', false)
	setProperty('cnameIn.alpha', 0)
	setProperty('cnameIn.visible', false)
	addLuaText('cnameIn')

	makeLuaText('cquote', '"insert quote here"', screenWidth, 200, 300)
	setObjectCamera('cquote', 'camHUD')
	setTextSize('cquote', 30)
	setTextAlignment('cquote', 'center')
	setTextBorder('cquote', 0, '000000', '')
	setProperty('cquote.antialiasing', false)
	setProperty('cquote.alpha', 0)
	setProperty('cquote.visible', false)
	addLuaText('cquote')
end

function onStartCountdown()
	if not activeScene and getVar('am.menu.scene') == 'credits' then
		activeScene = true
		updateVars()
		playAnim('credits', 'basic', false)
		setProperty('credits.offset.x', 0)
		setProperty('credits.offset.y', 0)

		if getVar('am.menu.rushTransition') then setProperty('credits.x', getProperty('credits.x') + 110) end

		doTweenAngle('creditsR1', 'credits', 15, intro_time / 2, 'quadOut')

		addpos('title', nil, -140, intro_time + 0.2, 'backIn')
		addpos('sidebar', -850, nil, intro_time + 0.45, 'sineIn')
		addpos('credits', 385, nil, intro_time, 'circOut')
		doTweenY('cyt', 'credits', 20, intro_time, 'backInOut')
		addpos('options', -(intro_x+350), nil, intro_time, 'backIn')
		addpos('freeplay', -(intro_x+350), nil, intro_time, 'backIn')
		addpos('mtitle', 530, nil, intro_time + 0.4, 'backIn')
		addpos('mdesc', 530, nil, intro_time + 0.4, 'backIn')
		addpos('play', 530, nil, intro_time + 0.4, 'backIn')
		addpos('opt', 530, nil, intro_time + 0.4, 'backIn')
		addpos('ppl', 530, nil, intro_time + 0.4, 'backIn')

		setProperty('cpageL.visible', true)
		setProperty('cpageR.visible', true)
		setProperty('cbg.visible', true)
		setProperty('cborder.visible', true)
		setProperty('cnameIn.visible', true)
		setProperty('cnameOut.visible', true)
		setProperty('cquote.visible', true)

		addpos('cpageL', nil, 200, intro_time, 'backOut')
		addpos('cpageR', nil, 200, intro_time, 'backOut')

		doTweenAlpha('cbga', 'cbg', 0.6, intro_time + 0.2, 'sineOut')
		doTweenAlpha('cbordera', 'cborder', 1, intro_time, 'sineOut')
		doTweenAlpha('cnameIna', 'cnameIn', 1, intro_time, 'sineOut')
		doTweenAlpha('cnameOuta', 'cnameOut', 1, intro_time, 'sineOut')
		doTweenAlpha('cquotea', 'cquote', 1, intro_time, 'sineOut')
	end

	return Function_Stop
end

function onTweenCompleted(t)
	if not activeScene then return end

	if t == 'creditsR1' then doTweenAngle('creditsR2', 'credits', 0, intro_time / 2, 'backOut') end

	if t == 'xsidebar' then
		transitioning = false
		selectable = true

		setProperty('options.visible', false)
		setProperty('freeplay.visible', false)
		setProperty('sidebar.visible', false)
		setProperty('title.visible', false)
		setProperty('mtitle.visible', false)
		setProperty('mdesc.visible', false)
		setProperty('play.visible', false)
		setProperty('opt.visible', false)
		setProperty('ppl.visible', false)

		setVar('am.menu.rushTransition', false)
	end
end

function onUpdate(elapsed)
	if not activeScene then return end

	if selectable then
		if keyJustPressed('accept') then

		elseif keyJustPressed('left') then

		elseif keyJustPressed('right') then

		elseif keyJustPressed('back') then
			-- TRANSITION FROM CREDITS TO MAIN MENU
			transitioning = true
			selectable = false
			selected = 3

			playSound('cancelMenu')

			setProperty('options.visible', true)
			setProperty('freeplay.visible', true)
			setProperty('sidebar.visible', true)
			setProperty('title.visible', true)
			setProperty('mtitle.visible', true)
			setProperty('mdesc.visible', true)
			setProperty('play.visible', false)
			setProperty('opt.visible', false)
			setProperty('ppl.visible', true)

			setpos('freeplay', 50, 180, intro_time, 'circOut')
			setpos('options', 50, 340, intro_time + 0.2, 'circOut')
			setpos('credits', 50, 500, intro_time + 0.4, 'circOut')
			addpos('title', 0, 140, intro_time + 0.5, 'backOut')
			setpos('sidebar', -190, -270, intro_time + 0.45, 'sineOut')
			addpos('mtitle', -530, 0, intro_time + 0.4, 'backOut')
			addpos('mdesc', -530, 0, intro_time + 0.4, 'backOut')
			addpos('play', -530, 0, intro_time + 0.4, 'backOut')
			addpos('opt', -530, 0, intro_time + 0.4, 'backOut')
			addpos('ppl', -530, 0, intro_time + 0.4, 'backOut')

			doTweenAlpha('cbga', 'cbg', 0, intro_time, 'sineIn')
			doTweenAlpha('cbordera', 'cborder', 0, intro_time, 'sineIn')
			doTweenAlpha('cnameIna', 'cnameIn', 0, intro_time, 'sineIn')
			doTweenAlpha('cnameOuta', 'cnameOut', 0, intro_time, 'sineIn')
			doTweenAlpha('cquotea', 'cquote', 0, intro_time, 'sineIn')

			addpos('cpageL', nil, -200, intro_time, 'backIn')
			addpos('cpageR', nil, -200, intro_time, 'backIn')

			saveVars()
			changeScene('menu')
		end
	end
end






function changeScene(name)
	activeScene = false
	setVar('am.menu.scene', name)
	startCountdown()
end

function saveVars()
	setVar('am.menu.selected', selected)
	setVar('am.menu.selectable', selectable)
	setVar('am.menu.transitioning', transitioning)
	setVar('am.menu.intro_x', intro_x)
	setVar('am.menu.intro_time', intro_time)
end

function getMenuVar(tag) return getVar('am.menu.'..tag) end
function updateVars()
	selected = getMenuVar('selected')
	selectable = getMenuVar('selectable')
	transitioning = getMenuVar('transitioning')
	intro_x = getMenuVar('intro_x')
	intro_time = getMenuVar('intro_time')
end











-------------------- LAZY STUFF --------------------

function addpos(obj, x, y, dur, ease)
	if x ~= nil then doTweenX('x'..obj, obj, getProperty(obj..'.x') + x, dur, ease) end
	if y ~= nil then doTweenY('y'..obj, obj, getProperty(obj..'.y') + y, dur, ease) end
end

function setpos(obj, x, y, dur, ease)
	if x ~= nil and getProperty(obj..'.x') ~= x then doTweenX('x'..obj, obj, x, dur, ease) end
	if y ~= nil and getProperty(obj..'.y') ~= y then doTweenY('y'..obj, obj, y, dur, ease) end
end

function tweenScale(obj, scale, dur, ease)
	if getProperty(obj..'.scale.x') ~= scale then doTweenX('sx'..obj, obj..'.scale', scale, dur, ease) end
	if getProperty(obj..'.scale.y') ~= scale then doTweenY('sy'..obj, obj..'.scale', scale, dur, ease) end
end

----------------------------------------------------