local activeScene = false

function onCustomSubstateCreate(n)
	if n == 'easterEggTransition' then
		activeScene = true

		makeLuaSprite('broke', 'menu/brokenScreen')
		setObjectCamera('broke', 'camHUD')
		setObjectOrder('broke', 101)
		addLuaSprite('broke')

		makeLuaSprite('borderBars', 'windowBorderBars')
		setObjectCamera('borderBars', 'camHUD')
		setObjectOrder('borderBars', 102)
		screenCenter('borderBars', 'xy')
		addLuaSprite('borderBars')

		makeLuaText('shakeTxt', 'Redirecting...', screenWidth)
		setTextSize('shakeTxt', 30)
		setTextAlignment('shakeTxt', 'center')
		screenCenter('shakeTxt', 'y')
		setProperty('shakeTxt.alpha', 0)
		setProperty('shakeTxt.antialiasing', false)
		toLoadScreenCam('shakeTxt')
		addLuaText('shakeTxt')

		playSound('glass_shatter')

		runTimer('shake_loadSounds', 0.05)
		runTimer('shake_camZoomOut', 1.4)
	end
end

function onTimerCompleted(t, l, ll)
	if activeScene then
		if t == 'shake_loadSounds' then
			precacheSound('deltarune_fall')
			precacheSound('stone_slide')
		end

		if t == 'shake_camZoomOut' then
			playSound('stone_slide')
			doTweenZoom('camHUDz', 'camHUD', 0.6, 1.78, 'linear')
			runTimer('shake_camFall', 2.65)
		end

		if t == 'shake_camFall' then
			playSound('deltarune_fall')

			doTweenZoom('camHUDz', 'camHUD', 0.15, 2.48, 'linear')
			doTweenAlpha('camHUDa', 'camHUD', 0, 2.48, 'circOut')
			doTweenY('camHUDy1', 'camHUD', getProperty('camHUD.y') - 300, 1.04, 'quadOut')
			doTweenAngle('camHUDang', 'camHUD', 290, 2.48, 'linear')
			runTimer('shake_showLoadText', 2.48)
		end

		if t == 'shake_showLoadText' then doTweenAlpha('shakeTxta', 'shakeTxt', 1, 1.2, 'linear') end
	end
end

function onTweenCompleted(t)
	if activeScene then
		if t == 'camHUDy1' then doTweenY('camHUDy2', 'camHUD', getProperty('camHUD.y') + 500, 1.44, 'sineIn') end
		if t == 'shakeTxta' then loadSong('menu-(your-annoying-assistant)', -1) end
	end
end