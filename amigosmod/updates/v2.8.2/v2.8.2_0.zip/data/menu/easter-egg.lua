local activeScene = false

local shake_timeAllowance
local shake_step
local shake_level
local shake_nextKey
local shakeable = true

function onCreate()
	precacheImage('menu/brokenScreen')
	precacheImage('windowBorderBars')
	precacheSound('glass_shatter')
	precacheSound('undertale_hurt')
	resetShakeVars()
end

function onCustomSubstateCreate(n)
	if n ~= 'easterEggTransition' then return end

	activeScene = true

	makeLuaSprite('broke', 'menu/brokenScreen')
	setObjectCamera('broke', 'camHUD')
	setObjectOrder('broke', 101)
	addLuaSprite('broke')

	makeLuaSprite('borderBars', 'windowBorderBars')
	setObjectCamera('borderBars', 'camHUD')
	setObjectOrder('borderBars', 102)
	screenCenter('borderBars', 'xy')
	addLuaSprite('borderBars')

	makeLuaText('shakeTxt', 'Redirecting...', screenWidth)
	setTextSize('shakeTxt', 30)
	setTextAlignment('shakeTxt', 'center')
	screenCenter('shakeTxt', 'y')
	setProperty('shakeTxt.alpha', 0)
	setProperty('shakeTxt.antialiasing', false)
	toLoadScreenCam('shakeTxt')
	addLuaText('shakeTxt')

	playSound('glass_shatter')

	runTimer('shake_loadSounds', 0.05)
	runTimer('shake_camZoomOut', 1.4)
end

function onTimerCompleted(t, l, ll)
	if t == 'shakeTimeLimit' then resetShakeVars() end

	if not activeScene then return end

	if t == 'shake_loadSounds' then
		precacheSound('deltarune_fall')
		precacheSound('stone_slide')
	end

	if t == 'shake_camZoomOut' then
		playSound('stone_slide')
		doTweenZoom('camHUDz', 'camHUD', 0.6, 1.78, 'linear')
		runTimer('shake_camFall', 2.65)
	end

	if t == 'shake_camFall' then
		playSound('deltarune_fall')

		doTweenZoom('camHUDz', 'camHUD', 0.15, 2.48, 'linear')
		doTweenAlpha('camHUDa', 'camHUD', 0, 2.48, 'circOut')
		doTweenY('camHUDy1', 'camHUD', getProperty('camHUD.y') - 300, 1.04, 'quadOut')
		doTweenAngle('camHUDang', 'camHUD', 290, 2.48, 'linear')
		runTimer('shake_showLoadText', 2.48)
	end

	if t == 'shake_showLoadText' then doTweenAlpha('shakeTxta', 'shakeTxt', 1, 1.2, 'linear') end
end

function onTweenCompleted(t)
	if not activeScene then return end

	if t == 'camHUDy1' then doTweenY('camHUDy2', 'camHUD', getProperty('camHUD.y') + 500, 1.44, 'sineIn') end
	if t == 'shakeTxta' then loadSong('menu-(your-annoying-assistant)', -1) end
end

function processUpdate()
	if keyJustPressed('left') and (shake_nextKey == '' or shake_nextKey == 'right') then
		shake_nextKey = 'left'
		easterEggShake(false)
	elseif keyJustPressed('right') and (shake_nextKey == '' or shake_nextKey == 'left') then
		shake_nextKey = 'right'
		easterEggShake(true)
	end
end

function easterEggShake(dir)
	if not shakeable then return end

	if shake_step == 10 then
		shake_step = 0
		shake_level = shake_level + 1
		shake_timeAllowance = shake_timeAllowance * 0.8
	end

	if shake_level == 8 then
		shakeable = false
		resetShakeVars()
		cancelTimer('shakeTimeLimit')
		setPropertyFromClass('flixel.FlxG', 'sound.music.volume', 0)
		cancelTween('camHUDx')
		cancelTween('camHUDang')
		setProperty('camHUD.x', 0)
		setProperty('camHUD.angle', 0)
		setProperty('camOther.visible', false)
		openCustomSubstate('easterEggTransition', true)
		return
	end

	shake_step = shake_step + 1
	playSound('undertale_hurt', 0.4, 'shakeSound')

	cancelTimer('shakeTimeLimit')
	runTimer('shakeTimeLimit', shake_timeAllowance)

	local x = shake_level * 4
	local ang = shake_level * 0.65
	if not dir then
		x = -x
		ang = -ang
	end

	setProperty('camHUD.x', x)
	setProperty('camHUD.angle', ang)

	local intro_time = getVar('am.menu.intro_time')

	doTweenX('camHUDx', 'camHUD', 0, intro_time / 2, 'circOut')
	doTweenAngle('camHUDang', 'camHUD', 0, intro_time / 2, 'circOut')
end

function resetShakeVars()
	shake_timeAllowance = 1
	shake_step = 0
	shake_level = 1
	shake_nextKey = ''
end