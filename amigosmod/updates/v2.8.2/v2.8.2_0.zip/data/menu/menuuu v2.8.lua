local activeScene = true

local aa = false

local selected = 0
local lastSelected = 0
local selectable = false
local transitioning = false

local intro_x = 150
local intro_time = 0.6
local sidebarFloating = false

local duskyFlipped = false
local duskyWaiting = false
local duskyWalkSpeed = 300
local duskyWalkY = -20

local shakeable = false

local lastScene = ''



-------------------- SPRITES --------------------

function onCreate()
	setVar('am.menu.scene', 'am_none')
	lastSelected = getDataFromSave('lonlihh', 'lastB', 1)
	selected = lastSelected

	aa = getPropertyFromClass('backend.ClientPrefs', 'data.antialiasing')

	setVar('am.menu.rushTransition', false)
	setVar('am.menu.bg.default_color', '0c90f5')

	precacheSound('scrollMenu')
	precacheSound('confirmMenu')
	precacheSound('cancelMenu')
	precacheSound('clickText')

	setProperty('boyfriend.visible', false)
	setProperty('boyfriend.active', false)
	setProperty('gf.visible', false)
	setProperty('gf.active', false)
	setProperty('dad.visible', false)
	setProperty('dad.active', false)
	setProperty('healthBar.visible', false)
	setProperty('healthBar.active', false)
	setProperty('scoreTxt.visible', false)
	setProperty('scoreTxt.active', false)
	setProperty('iconP1.visible', false)
	setProperty('iconP1.active', false)
	setProperty('iconP2.visible', false)
	setProperty('iconP2.active', false)
	setProperty('playbackRate', 1)

	if timeBarType ~= 'Disabled' then
		setProperty('timeBar.visible', false)
		setProperty('timeBar.active', false)
		setProperty('timeTxt.visible', false)
		setProperty('timeTxt.active', false)
	end



	local menuFolder = string.lower(songName):gsub('%s', '-')
	local menuPath = 'data/'..menuFolder..'/'
	setVar('am.menu.path', menuPath)

	lastScene = getDataFromSave('lonlihh', 'lastScene', 'menu')
	local prevEnabled = getDataFromSave('lonlihh', 'prev.enabled', false)

	-- BUG FIX
	if lastScene == 'menu' and prevEnabled then
		prevEnabled = false
		setDataFromSave('lonlihh', 'prev.enabled', false)
		loadSong(songName, -1) -- force restart
		return
	end

	runHaxeCode([[
		addHaxeLibrary('Image', 'lime.graphics');
		addHaxeLibrary('Application', 'lime.app');

		ClientPrefs.keyBinds['debug_1'] = [];
		ClientPrefs.keyBinds['debug_2'] = [];
		game.variables.set('debugKeys_enabled', false);

		game.camGame.active = game.camGame.visible = false;
		FlxG.cameras.remove(game.camGame, false);

		var coolCam = new FlxCamera();
		coolCam.bgColor = 0x00;

		game.variables.set('camLoadScreen', coolCam);
		FlxG.cameras.add(coolCam, false);

		createGlobalCallback('toLoadScreenCam', function(tag:String):Void {
			game.getLuaObject(tag).camera = coolCam;
		});



		function findScript(scriptFile:String, ?ext:String):String {
			if (ext == null) ext = '.lua';

			if (scriptFile.substr(-ext.length) != ext) scriptFile += ext;
			if (FileSystem.exists(scriptFile)) return scriptFile;

			var path:String = Paths.modFolders(scriptFile);
			if (FileSystem.exists(path)) return path;

			var preloadPath:String = Paths.getPreloadPath(scriptFile);
			if (FileSystem.exists(preloadPath)) return preloadPath;

			return null;
		}

		var eeLuaPath = findScript('data/]]..menuFolder..[[/easter-egg.lua');
		var eeScript = null;
		if (eeLuaPath != null) {
			for (luaInstance in game.luaArray) {
				if (luaInstance.scriptName == eeLuaPath) {
					eeScript = luaInstance;
					break;
				}
			}
		}

		if (eeScript == null) debugPrint("Couldn't find easter egg script :(");

		function processEasterEggUpdate():Void {
			if (eeScript != null) eeScript.call('onUpdate', []);
		}

		function resetEasterEggShakeVars():Void {
			if (eeScript != null) eeScript.call('resetShakeVars', []);
		}

		createCallback('processEasterEggUpdate', processEasterEggUpdate);
		createCallback('resetEasterEggShakeVars', resetEasterEggShakeVars);



		Application.current.window.setIcon(Image.fromFile(Paths.modFolders('lonlihh/assets/woah.png')));
	]])

	local scenesPath = menuPath..'scenes/'
	local loadScene = function(name, args, forceLoad)
		if (forceLoad) or (prevEnabled and lastScene == name) or (not prevEnabled) then
			local scenePath = scenesPath..name..'.lua'
			addLuaScript(scenePath)
			callScript(scenePath, 'loadAssets', args)
		end
	end

	local ignoreOpt = not getDataFromSave('lonlihh', 'optimizeMod', true)

	daMenuStuff()
	loadScene('options', {aa}, ignoreOpt)
	loadScene('freeplay', {aa}, ignoreOpt)
	loadScene('credits', {}, ignoreOpt)
	loadingScreenStuff()

	saveVars()
end

function daMenuStuff()
	makeLuaSprite('bg', 'menu/bg')
	setProperty('bg.color', getColorFromHex(getVar('am.menu.bg.default_color')))
	setObjectCamera('bg', 'camHUD')
	addLuaSprite('bg')

	makeLuaSprite('ch', 'menu/checkered', -250)
	setObjectCamera('ch', 'camHUD')
	setProperty('ch.alpha', 0.35)
	addLuaSprite('ch')

	makeLuaText('mtitle', '...', 600, 680, 130)
	setObjectCamera('mtitle', 'camHUD')
	setTextAlignment('mtitle', 'center')
	setTextSize('mtitle', 50)
	addLuaText('mtitle')

	makeLuaText('mdesc', '...', 550, 700, 540)
	setObjectCamera('mdesc', 'camHUD')
	setTextAlignment('mdesc', 'center')
	setTextSize('mdesc', 35)
	addLuaText('mdesc')

	makeLuaSprite('dusky', 'menu/duskyChillin', 920, 328)
	setObjectCamera('dusky', 'camHUD')
	scaleObject('dusky', 0.7, 0.7)
	setObjectOrder('dusky', getObjectOrder('mtitle') + 1)
	setProperty('dusky.visible', false)
	addLuaSprite('dusky')

	makeLuaSprite('sidebar', 'menu/bigsidebar', -390, -270)
	setObjectCamera('sidebar', 'camHUD')
	scaleObject('sidebar', 0.8, 0.8)
	setObjectOrder('sidebar', getObjectOrder('dusky') + 1)
	addLuaSprite('sidebar')

	makeAnimatedLuaSprite('title', 'menu/title', 20, -100)
	setObjectCamera('title', 'camHUD')
	addAnimationByPrefix('title', 'idle', 'title', 24, true)
	playAnim('title', 'idle', false)
	setObjectOrder('title', getObjectOrder('sidebar') + 1)
	addLuaSprite('title')

	makeAnimatedLuaSprite('freeplay', 'mainmenu/menu_freeplay', -100, 180)
	setObjectCamera('freeplay', 'camHUD')
	addAnimationByPrefix('freeplay', 'basic', 'freeplay basic', 24, true)
	addAnimationByPrefix('freeplay', 'white', 'freeplay white', 24, true)
	playAnim('freeplay', 'basic', false)
	setObjectOrder('freeplay', getObjectOrder('title') + 1)
	addLuaSprite('freeplay')

	makeAnimatedLuaSprite('options', 'mainmenu/menu_options', -100, 340)
	setObjectCamera('options', 'camHUD')
	addAnimationByPrefix('options', 'basic', 'options basic', 24, true)
	addAnimationByPrefix('options', 'white', 'options white', 24, true)
	playAnim('options', 'basic', false)
	setObjectOrder('options', getObjectOrder('freeplay') + 1)
	addLuaSprite('options')

	makeAnimatedLuaSprite('credits', 'mainmenu/menu_credits', -100, 500)
	setObjectCamera('credits', 'camHUD')
	addAnimationByPrefix('credits', 'basic', 'credits basic', 24, true)
	addAnimationByPrefix('credits', 'white', 'credits white', 24, true)
	playAnim('credits', 'basic', false)
	setObjectOrder('credits', getObjectOrder('options') + 1)
	addLuaSprite('credits')

	makeAnimatedLuaSprite('play', 'menu/playbutton', 870)
	setObjectCamera('play', 'camHUD')
	addAnimationByPrefix('play', 'idle', 'idle', 8, true)
	playAnim('play', 'idle', false)
	scaleObject('play', 0.6, 0.6)
	screenCenter('play', 'y')
	setObjectOrder('play', getObjectOrder('credits') + 1)
	setProperty('play.visible', false)
	addLuaSprite('play')

	makeAnimatedLuaSprite('opt', 'menu/options', 850)
	setObjectCamera('opt', 'camHUD')
	addAnimationByPrefix('opt', 'idle', 'idle', 8, true)
	playAnim('opt', 'idle', false)
	scaleObject('opt', 0.6, 0.6)
	screenCenter('opt', 'y')
	setObjectOrder('opt', getObjectOrder('play') + 1)
	setProperty('opt.visible', false)
	addLuaSprite('opt')

	makeAnimatedLuaSprite('ppl', 'menu/people', 850)
	setObjectCamera('ppl', 'camHUD')
	addAnimationByPrefix('ppl', 'idle', 'idle', 8, true)
	playAnim('ppl', 'idle', false)
	scaleObject('ppl', 0.6, 0.6)
	screenCenter('ppl', 'y')
	setObjectOrder('ppl', getObjectOrder('opt') + 1)
	setProperty('ppl.visible', false)
	addLuaSprite('ppl')
end

function loadingScreenStuff()
	local max = 0
	while checkFileExists('images/load/screen'..max..'.png') do max = max + 1 end

	makeLuaSprite('blak')
	makeGraphic('blak', screenWidth, screenHeight, '000000')
	toLoadScreenCam('blak')
	setProperty('blak.alpha', 0)
	addLuaSprite('blak')

	if getDataFromSave('lonlihh', 'menuLoadIn', false) then
		setDataFromSave('lonlihh', 'menuLoadIn', false)

		makeLuaSprite('prevlsc', getDataFromSave('lonlihh', 'loadScreen'))
		toLoadScreenCam('prevlsc')
		setProperty('prevlsc.antialiasing', false)
		addLuaSprite('prevlsc')
		doTweenAlpha('prevLscOut', 'prevlsc', 0, 0.6, 'sineOut')
	end



	local daScreen = 'load/screen'
	daScreen = max > 1 and (daScreen..(getRandomInt(1, max) - 1)) or (daScreen..'0')

	makeLuaSprite('lsc', daScreen)
	toLoadScreenCam('lsc')
	setProperty('lsc.alpha', 0)
	addLuaSprite('lsc')
	setDataFromSave('lonlihh', 'loadScreen', daScreen)

	makeLuaText('loadTxt', 'Loading...', 0, 10, screenHeight - 30)
	toLoadScreenCam('loadTxt')
	setTextSize('loadTxt', 20)
	setTextAlignment('loadTxt', 'left')
	setProperty('loadTxt.antialiasing', false)
	setProperty('loadTxt.borderSize', 2)
	setProperty('loadTxt.alpha', 0)
	addLuaText('loadTxt')

	makeLuaSprite('saved', 'saved')
	toLoadScreenCam('saved')
	scaleObject('saved', 0.75, 0.75)
	setProperty('saved.x', screenWidth - (getProperty('saved.width') + 20))
	setProperty('saved.y', screenHeight + getProperty('saved.height'))
	setProperty('saved.antialiasing', false)
	setProperty('saved.visible', false)
	addLuaSprite('saved')
end





local buttonPositions = nil
local buttons = {'freeplay', 'options', 'credits'}
local buttonIcons = {'play', 'opt', 'ppl'}
local buttonTitles = {'Freeplay', 'Options', 'Credits'}
local buttonDesc = {
	'List of all available songs in the mod',
	'Adjust or turn off mechanics\nAccess some of Psych Engine options',
	'List of contributors!!11!'
}

function updateMenu()
	if not activeScene then return end

	if buttonPositions == nil then buttonPositions = {
		{ getProperty('freeplay.x'), getProperty('freeplay.y') },
		{ getProperty('options.x'), getProperty('options.y') },
		{ getProperty('credits.x'), getProperty('credits.y') }
	} end

	for i = 1, #buttons do
		if selected == i then
			tweenScale(buttons[i], 1, 0.5, 'circOut')
			setProperty(buttons[i]..'.x', buttonPositions[i][1] - 35)
			setProperty(buttons[i]..'.y', buttonPositions[i][2] - 30)
			playAnim(buttons[i], 'white', false)

			setTextString('mtitle', buttonTitles[i])
			setTextString('mdesc', buttonDesc[i])

			setProperty(buttonIcons[i]..'.visible', true)
			setProperty(buttonIcons[i]..'.offset.y', 40)
			doTweenY(buttonIcons[i]..'oy', buttonIcons[i]..'.offset', 78, 0.5, 'circOut')
		else
			tweenScale(buttons[i], 0.8, 0.5, 'circOut')
			setProperty(buttons[i]..'.x', buttonPositions[i][1])
			setProperty(buttons[i]..'.y', buttonPositions[i][2])
			playAnim(buttons[i], 'basic', false)

			setProperty(buttonIcons[i]..'.visible', false)
		end
	end
end





function onUpdate(elapsed)
	if keyboardJustPressed('L') then restartSong(true) end

	if getProperty('ch.x') >= 0 then setProperty('ch.x', -200)
	else setProperty('ch.x', getProperty('ch.x') + 100 * elapsed) end


	if not activeScene then return end


	if selectable then
		if keyJustPressed('accept') then
			-- PRESSED SMTH IN MAIN MENU
			transitioning = true
			sidebarFloating = true
			selectable = false
			lastSelected = selected
			playSound('confirmMenu')
			setDataFromSave('lonlihh', 'lastB', lastSelected)
			changeScene(buttons[selected])
		elseif keyJustPressed('down') then
			selected = selected + 1
			if selected > #buttons then selected = 1 end

			playSound('scrollMenu')
			updateMenu()
		elseif keyJustPressed('up') then
			selected = selected - 1
			if selected < 1 then selected = #buttons end

			playSound('scrollMenu')
			updateMenu()
		elseif keyJustPressed('back') then
			-- EXIT MAIN MENU
			selectable = false
			enableDebugKeys()
			eraseSaveData('amcache')
			setDataFromSave('lonlihh', 'lastScene', getVar('am.menu.scene'))
			setDataFromSave('lonlihh', 'lastB', selected)
			flushSaveData('lonlihh')
			flushSaveData('amstats')
			exitSong(false)
		elseif shakeable then processEasterEggUpdate() end
	end



	local duskyX = getProperty('dusky.x')
	if (not duskyFlipped and duskyX > 200) or (duskyFlipped and duskyX < 1300) then setProperty('dusky.x', duskyX - duskyWalkSpeed * elapsed)
	elseif not duskyWaiting then
		duskyWaiting = true
		if sidebarFloating then runTimer('duskywalkwait', getRandomFloat(0.5, 3.5)) end
	end
end





local saveAnimQueue = 0
local saveAnimPlaying = false

function onTimerCompleted(t, l, ll)
	if t == 'playSaveAnimBack' and saveAnimPlaying then doTweenY('savedyback', 'saved', screenHeight + getProperty('saved.height'), intro_time + 0.2, 'backIn') end
	if t == 'playSaveAnim' then
		if saveAnimPlaying then
			saveAnimQueue = saveAnimQueue + 1
			return
		end

		saveAnimPlaying = true
		setProperty('saved.visible', true)
		doTweenY('savedy', 'saved', screenHeight - (getProperty('saved.height') + 20), intro_time + 0.1, 'backOut')
		runTimer('playSaveAnimBack', intro_time + 1)
	end

	if not activeScene then return end

	if t == 'buttons' then
		local o = 'options'
		if ll == 0 then o = 'credits' end

		addpos(o, intro_x, nil, intro_time, 'circOut')
	end

	if t == 'duskywalkwait' then
		duskyWaiting = false
		duskyFlipped = not duskyFlipped
		duskyWalkSpeed = -duskyWalkSpeed

		setProperty('dusky.flipX', duskyFlipped)
	end

	if t == 'backtomenus' then
		soundFadeIn('', 0.0001, 1)
		playMusic('menu', 1, true)

		setVar('am.menu.ost.title', 'menu')
		runTimer('npShowAndHide', 0)
	end
end

function onTweenCompleted(t)
	if t == 'duskya' then
		setProperty('dusky.visible', false)
		setProperty('dusky.alpha', 1)
	end

	if t == 'savedyback' then
		saveAnimPlaying = false
		setProperty('saved.visible', false)

		if saveAnimQueue > 0 then
			saveAnimQueue = saveAnimQueue - 1
			onTimerCompleted('playSaveAnim', 0, 0)
		end
	end

	if t == 'prevLscOut' then removeLuaSprite('prevlsc', true) end

	if not activeScene then return end

	if t == 'xsidebar' then
		transitioning = false
		selectable = true
		selected = lastSelected
		updateMenu()

		if getVar('am.menu.scene') == 'menu' then shakeable = true end

		cancelTween('po1-1')
		cancelTween('po1-2')
		cancelTween('po2-1')
		cancelTween('po2-2')

		sidebarFloating = true
		onTweenCompleted('sbfloat2')
		onTweenCompleted('duskywalk2')

		setProperty('dusky.x', 1300)
		setProperty('dusky.visible', true)

		-- freeplay leftovers
		setProperty('fpCtgBG.visible', false)
		setProperty('fpCtg.visible', false)
		setProperty('fpStatsBG.visible', false)
		setProperty('fpStats.visible', false)

		-- options leftovers
		setProperty('guideBG.visible', false)
		setProperty('guide.visible', false)

		-- credits leftovers
		setProperty('cpageL.visible', false)
		setProperty('cpageR.visible', false)
		setProperty('cbg.visible', false)
		setProperty('cborder.visible', false)
		setProperty('cnameIn.visible', false)
		setProperty('cnameOut.visible', false)
		setProperty('cquote.visible', false)
	end

	if sidebarFloating then
		if t == 'duskywalk1' then doTweenY('duskywalk2', 'dusky.offset', duskyWalkY, 0.6, 'sineIn') end
		if t == 'duskywalk2' then doTweenY('duskywalk1', 'dusky.offset', 0, 0.6, 'sineOut') end

		if t == 'sbfloat1' then doTweenX('sbfloat2', 'sidebar', getProperty('sidebar.x') - 30, 2.5, 'sineInOut') end
		if t == 'sbfloat2' then doTweenX('sbfloat1', 'sidebar', getProperty('sidebar.x') + 30, 2.5, 'sineInOut') end
	end
end





function fixDusky()
	cancelTimer('duskywalkwait')
	cancelTween('duskywalk1')
	cancelTween('duskywalk2')
	setProperty('dusky.x', 920)
	setProperty('dusky.y', 328)
	setProperty('dusky.offset.x', 0)
	setProperty('dusky.offset.y', 0)
	setProperty('dusky.flipX', false)

	if duskyWalkSpeed < 0 then duskyWalkSpeed = -duskyWalkSpeed end
end





function onStartCountdown()
	local scene = getVar('am.menu.scene')

	if scene == 'menu' then
		activeScene = true
		updateVars()
		fixDusky()
	elseif scene == 'am_none' then
		activeScene = true

		if lastScene ~= 'options' then
			playMusic('menu', 1, true)
			setVar('am.menu.ost.title', 'menu')
			runTimer('npShowAndHide', 0.1)
		end

		if lastScene == 'menu' then
			addpos('sidebar', 200, nil, intro_time + 0.45, 'backOut')
			addpos('title', nil, 140, intro_time + 0.2, 'backOut')
			addpos('freeplay', intro_x, nil, intro_time, 'circOut')
			runTimer('buttons', 0.1, 2)
			setVar('am.menu.scene', 'menu')
		else
			setProperty('sidebar.x', getProperty('sidebar.x') + 200)
			setProperty('title.y', getProperty('title.y') + 140)

			setVar('am.menu.rushTransition', true)
			changeScene(lastScene)
		end

		setDataFromSave('lonlihh', 'lastScene', 'menu')
		setDataFromSave('lonlihh', 'lastB', 1)
	end

	return Function_Stop
end

function saveVars(sceneName)
	setVar('am.menu.selected', selected)
	setVar('am.menu.lastSelected', lastSelected)
	setVar('am.menu.selectable', selectable)
	setVar('am.menu.transitioning', transitioning)

	setVar('am.menu.intro_x', intro_x)
	setVar('am.menu.intro_time', intro_time)
	setVar('am.menu.sidebarFloating', sidebarFloating)

	setVar('am.menu.duskyFlipped', duskyFlipped)
	setVar('am.menu.duskyWaiting', duskyWaiting)
	setVar('am.menu.duskyWalkSpeed', duskyWalkSpeed)
	setVar('am.menu.duskyWalkY', duskyWalkY)

	setVar('am.menu.songs', songs)
	setVar('am.menu.songIcons', songIcons)
	setVar('am.menu.songIconOffsetX', songIconOffsetX)
	setVar('am.menu.songIconOffsetY', songIconOffsetY)
	setVar('am.menu.songShaders', songShaders)
	setVar('am.menu.songCategories', songCategories)
	setVar('am.menu.freeplayDistance', freeplayDistance)

	if sceneName == 'freeplay' and songs ~= nil then
		setVar('am.menu.songs', songs)
		setVar('am.menu.songIcons', songIcons)
		setVar('am.menu.songIconOffsetX', songIconOffsetX)
		setVar('am.menu.songIconOffsetY', songIconOffsetY)
		setVar('am.menu.songShaders', songShaders)
		setVar('am.menu.songCategories', songCategories)
		setVar('am.menu.songColors', songColors)
		setVar('am.menu.songBPM', songBPM)
		setVar('am.menu.songDelays', songDelays)
		setVar('am.menu.categoryTitles', categoryTitles)
		setVar('am.menu.freeplayDistance', freeplayDistance)

		songs = nil
		songIcons = nil
		songIconOffsetX = nil
		songIconOffsetY = nil
		songShaders = nil
		songCategories = nil
		songColors = nil
		songBPM = nil
		songDelays = nil
		categoryTitles = nil
		freeplayDistance = nil
	end

	if optListData ~= nil then
		setVar('am.menu.optListData', optListData)
		optListData = nil
	end
end

function getMenuVar(tag) return getVar('am.menu.'..tag) end
function updateVars()
	selected = getMenuVar('selected')
	lastSelected = getMenuVar('lastSelected')
	selectable = getMenuVar('selectable')
	transitioning = getMenuVar('transitioning')

	intro_x = getMenuVar('intro_x')
	intro_time = getMenuVar('intro_time')
	sidebarFloating = getMenuVar('sidebarFloating')

	duskyFlipped = getMenuVar('duskyFlipped')
	duskyWaiting = getMenuVar('duskyWaiting')
	duskyWalkSpeed = getMenuVar('duskyWalkSpeed')
	duskyWalkY = getMenuVar('duskyWalkY')
end

function changeScene(name)
	activeScene = false
	shakeable = false

	doTweenAlpha('duskya', 'dusky', 0, 0.5, 'sineOut')
	cancelTween('sbfloat1')
	cancelTween('sbfloat2')
	cancelTween('sxfreeplay')
	cancelTween('syfreeplay')
	cancelTween('sxoptions')
	cancelTween('syoptions')
	cancelTween('sxcredits')
	cancelTween('sycredits')
	cancelTween('xfreeplay')
	cancelTween('xoptions')
	cancelTween('xcredits')
	cancelTween('ytitle')

	saveVars(name)
	setVar('am.menu.scene', name)
	startCountdown()
end







-------------------- LAZY STUFF --------------------

function addpos(obj, x, y, dur, ease)
	if x ~= nil then doTweenX('x'..obj, obj, getProperty(obj..'.x') + x, dur, ease) end
	if y ~= nil then doTweenY('y'..obj, obj, getProperty(obj..'.y') + y, dur, ease) end
end

function tweenScale(obj, scale, dur, ease)
	if getProperty(obj..'.scale.x') ~= scale then doTweenX('sx'..obj, obj..'.scale', scale, dur, ease) end
	if getProperty(obj..'.scale.y') ~= scale then doTweenY('sy'..obj, obj..'.scale', scale, dur, ease) end
end

----------------------------------------------------