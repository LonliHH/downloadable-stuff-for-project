local diaTag = ''
local newText = ''
local newTextLength = 0
local textPos = 0
local speed = 0
local volume = 0
local finished = true

function onCreate()
	local dialoguePath = 'data/'..string.lower(songName):gsub('%s', '-')..'/dialogue.lua'

	setVar('dialoguePath', 'data/'..string.lower(songName):gsub('%s', '-')..'/dialogue.lua')
	setVar('dialogue.finished', finished)

	makeLuaText('dialogue', '', screenWidth, 0, screenHeight - 80)
	setObjectCamera('dialogue', 'camHUD')
	setTextSize('dialogue', 30)
	setTextAlignment('dialogue', 'center')
	setProperty('dialogue.antialiasing', false)
	addLuaText('dialogue')

	precacheSound('dialogue')

	runHaxeCode([[
		function findScript(scriptFile:String, ?ext:String) {
			if (ext == null) ext = '.lua';

			//if (!scriptFile.endsWith(ext)) scriptFile = scriptFile + ext;
			if (scriptFile.substr(-ext.length) != ext) scriptFile += ext;
			var path:String = Paths.modFolders(scriptFile);

			if (FileSystem.exists(scriptFile)) return scriptFile;
			if (FileSystem.exists(path)) return path;

			var preloadPath:String = Paths.getPreloadPath(scriptFile);
			if (FileSystem.exists(preloadPath)) return preloadPath;

			return null;
		}

		var luaPath = findScript(']]..dialoguePath..[[');
		var diaScript = null;
		if (luaPath != null) {
			for (luaInstance in game.luaArray) {
				if (luaInstance.scriptName == luaPath) {
					diaScript = luaInstance;
					break;
				}
			}
		}

		if (diaScript == null) {
			debugPrint("Couldn't find dialogue script :(");
			return;
		}

		function newDialogue(text:String, tag:String, ?speed:Float, ?volume:Float):Void {
			var sv = svDefaults(speed, volume);
			diaScript.call('new', [ text, tag, sv[0], sv[1] ]);
		}

		function addToDialogue(text:String, tag:String, ?speed:Float, ?volume:Float):Void {
			var sv = svDefaults(speed, volume);
			diaScript.call('add', [ text, tag, sv[0], sv[1] ]);
		}

		function svDefaults(speed:Float, volume:Float):Array<Float> {
			return [
				(speed == null || speed <= 0) ? 0.05 : speed,
				(volume == null || volume < 0) ? 0.3 : volume
			];
		}

		createGlobalCallback('newDia', newDialogue);
		createGlobalCallback('addToDia', addToDialogue);
	]])
end

function new(text, tag, speeddd, volumeee)
	if not finished then cancelTimer('diaUpdate') end

	diaTag = tag
	finished = false
	setVar('dialogue.finished', false)

	newText = text
	newTextLength = #text
	textPos = 0
	speed = speeddd
	volume = volumeee

	setTextString('dialogue', '')
	onTimerCompleted('diaUpdate', 0, 0)
end

function add(text, tag, speeddd, volumeee)
	if not finished then cancelTimer('diaUpdate') end

	diaTag = tag
	finished = false
	setVar('dialogue.finished', false)
	newText = newText..text
	newTextLength = #newText
	speed = speeddd
	volume = volumeee

	onTimerCompleted('diaUpdate', 0, 0)
end

function onTimerCompleted(t, l, ll)
	if t == 'diaUpdate' then
		textPos = textPos + 1
		local newChar = string.sub(newText, textPos, textPos)
		if newChar ~= ' ' then playSound('dialogue', volume) end

		setTextString('dialogue', getTextString('dialogue')..newChar)

		if textPos == newTextLength then
			finished = true
			setVar('dialogue.finished', true)
			if diaTag ~= nil then callOnLuas('dialogueFinished', {diaTag}) end
		else runTimer('diaUpdate', speed) end
	end
end