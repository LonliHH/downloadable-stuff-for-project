local diaTag = ''
local newText = ''
local newTextLength = 0
local textPos = 0
local speed = 0
local volume = 0
local finished = true

function onCreate()
	setVar('dialoguePath', 'data/'..string.lower(songName):gsub('%s', '-')..'/dialogue.lua')
	setVar('dialogue.finished', finished)

	makeLuaText('dialogue', '', screenWidth, 0, screenHeight - 80)
	setObjectCamera('dialogue', 'camHUD')
	setTextSize('dialogue', 30)
	setTextAlignment('dialogue', 'center')
	setProperty('dialogue.antialiasing', false)
	addLuaText('dialogue')

	precacheSound('dialogue')
end

function new(text, tag, speeddd, volumeee)
	if finished then
		diaTag = tag
		finished = false
		setVar('dialogue.finished', false)
		newText = text
		newTextLength = string.len(newText)
		textPos = 0
		
		if speeddd == nil or speeddd < 0 then speed = 0.05 else speed = speeddd end
		if volumeee == nil then volume = 0.3 else volume = volumeee end

		setTextString('dialogue', '')
		onTimerCompleted('diaUpdate', 0, 0)
	end
end

function add(text, tag, speeddd, volumeee)
	if finished then
		diaTag = tag
		finished = false
		setVar('dialogue.finished', false)
		newText = newText..text
		newTextLength = string.len(newText)

		if speeddd == nil or speeddd < 0 then speed = 0.05 else speed = speeddd end
		if volumeee == nil then volume = 0.3 else volume = volumeee end

		onTimerCompleted('diaUpdate', 0, 0)
	end
end

function onTimerCompleted(t, l, ll)
	if t == 'diaUpdate' then
		textPos = textPos + 1
		setTextString('dialogue', string.sub(newText, 1, textPos))
		playSound('dialogue', volume)

		if textPos == newTextLength then
			finished = true
			setVar('dialogue.finished', true)
			if diaTag ~= nil then callOnLuas('dialogueFinished', {diaTag}) end
		else runTimer('diaUpdate', speed) end
	end
end