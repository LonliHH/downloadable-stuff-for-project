local activeScene = false
local selectable = false
local components = {}

function loadAssets()
	makeLuaSprite('room2', 'menu/yas/room2')
	setObjectCamera('room2', 'camHUD')
	screenCenter('room2', 'xy')
	addToScene('room2')
end

function addToScene(tag, text)
	if text then addLuaText(tag) else addLuaSprite(tag) end
	setProperty(tag..'.visible', activeScene)
	table.insert(components, tag)
end

function onUpdate()
	if not activeScene then return end

	if selectable then
		if keyJustPressed('down') then
			changeScene('room1')
		end
	end
end

function onSceneChange(n)
	activeScene = n == 'room2'
	selectable = activeScene
	for i = 1, #components do setProperty(components[i]..'.visible', activeScene) end

	if activeScene then
		setTextString('controls', '[DOWN] Go back    [LEFT] Go left')
	end
end