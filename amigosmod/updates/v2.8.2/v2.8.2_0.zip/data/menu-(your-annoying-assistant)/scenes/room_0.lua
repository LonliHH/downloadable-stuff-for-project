local activeScene = false
local selectable = false
local introDone = false
local components = {}

function loadAssets()
	precacheMusic('yas')
	precacheSound('door_open')
	precacheSound('door_close')
	precacheSound('yas_glitch')

	makeLuaSprite('door', 'menu/yas/door')
	setObjectCamera('door', 'camHUD')
	scaleObject('door', 0.65, 0.65)
	screenCenter('door', 'xy')
	addToScene('door')
end

function addToScene(tag, text)
	if text then addLuaText(tag) else addLuaSprite(tag) end
	setProperty(tag..'.visible', activeScene)
	table.insert(components, tag)
end

function onUpdate()
	if not activeScene then return end

	if selectable then
		if keyJustPressed('accept') then
			playSound('door_open')
			changeScene('room1')
		elseif keyJustPressed('back') then
			selectable = false
			playSound('yas_glitch')
			setMusicVolume(0)
			runTimer('yas_exit', 1.7)
			goBackToSleep()
		end
	end
end

function onTimerCompleted(t, l, ll)
	if not activeScene then return end

	if t == 'loadTxtFO' then
		playMusic('yas', 0.0001, true)
		soundFadeIn('', 1, 0.0001, 0.2)
	end

	if t == 'yas_exit' then
		setProperty('blak.alpha', 1)
		loadSong('menu', -1)
	end

	if t == 'diaIntro' then
		if gysave('firstTime', true) then
			sysave('firstTime', false)
			debugPrint(tostring(gysave('firstTime', true)))
			newDia('Woah...', 'diaIntro1', 0.1)
		else
			newDia('Back here again.', 'diaDone')
		end
	end

	if t == 'diaIntro2' then addToDia(' Where the heck am I?', 'diaDone', 0.07) end
end

function dialogueFinished(t)
	if t == 'diaIntro1' then runTimer('diaIntro2', 1) end
	if t == 'diaDone' then
		selectable = true
		introDone = true
		setProperty('controls.visible', true)
	end
end

function onTweenCompleted(t)
	if not activeScene then return end

	if t == 'loadTxta' then runTimer('diaIntro', 0.3) end
end

function onSceneChange(n)
	activeScene = n == 'door'
	for i = 1, #components do setProperty(components[i]..'.visible', activeScene) end

	if activeScene then
		if introDone then selectable = true end
		setTextString('controls', '[BACK] Go back to bed     [ACCEPT] Go inside')
	else
		selectable = false
	end
end