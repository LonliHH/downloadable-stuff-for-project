local activeScene = false
local selectable = false
local components = {}

function loadAssets()
	--initLuaShader('wavy')

	makeLuaSprite('room1', 'menu/yas/room1')
	setObjectCamera('room1', 'camHUD')
	screenCenter('room1', 'xy')
	--setSpriteShader('room1', 'wavy')
	--setShaderFloat('room1', 'frequency', 8)
	--setShaderFloat('room1', 'amplitude', 0.02)
	addToScene('room1')
end

function addToScene(tag, text)
	if text then addLuaText(tag) else addLuaSprite(tag) end
	setProperty(tag..'.visible', activeScene)
	table.insert(components, tag)
end

function onUpdate()
	if not activeScene then return end

	if selectable then
		if keyJustPressed('up') then

		elseif keyJustPressed('right') then changeScene('room2')
		elseif keyJustPressed('back') then
			playSound('door_close')
			soundFadeCancel('')
			setMusicVolume(0.2)
			changeScene('door')
		end
	end
end

function onSceneChange(n)
	activeScene = n == 'room1'
	selectable = activeScene
	for i = 1, #components do setProperty(components[i]..'.visible', activeScene) end

	if activeScene then
		setTextString('controls', '[BACK] Go back outside     [UP] Go to the room up front     [RIGHT] Go right')
		soundFadeCancel('')
		setMusicVolume(1)

		if getVar('phase') < 1 then setTextString('dialogue', '') end
	end
end