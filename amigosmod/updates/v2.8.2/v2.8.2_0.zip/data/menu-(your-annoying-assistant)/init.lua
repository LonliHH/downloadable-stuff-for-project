local oldShadersEnabled = false
local borderBarWidth = 140

function onDestroy() if not oldShadersEnabled then setPropertyFromClass('backend.ClientPrefs', 'data.shaders', false) end end
function onCreatePost() runTimer('loadTxtFO', 0.15) end
function onCreate()
	oldShadersEnabled = getPropertyFromClass('backend.ClientPrefs', 'data.shaders')
	if not oldShadersEnabled then setPropertyFromClass('backend.ClientPrefs', 'data.shaders', true) end

	setVar('phase', 0)

	setProperty('boyfriend.visible', false)
	setProperty('boyfriend.active', false)
	setProperty('gf.visible', false)
	setProperty('gf.active', false)
	setProperty('dad.visible', false)
	setProperty('dad.active', false)
	setProperty('healthBar.visible', false)
	setProperty('healthBar.active', false)
	setProperty('scoreTxt.visible', false)
	setProperty('scoreTxt.active', false)
	setProperty('botplayTxt.visible', false)
	setProperty('botplayTxt.active', false)
	setProperty('iconP1.visible', false)
	setProperty('iconP1.active', false)
	setProperty('iconP2.visible', false)
	setProperty('iconP2.active', false)
	setProperty('playbackRate', 1)

	if timeBarType ~= 'Disabled' then
		setProperty('timeBar.visible', false)
		setProperty('timeBar.active', false)
		setProperty('timeTxt.visible', false)
		setProperty('timeTxt.active', false)
	end

	makeLuaSprite('blak')
	makeGraphic('blak', screenWidth, screenHeight, '000000')
	addLuaSprite('blak')

	makeLuaText('loadTxt', 'Redirecting...', screenWidth)
	setTextSize('loadTxt', 30)
	setTextAlignment('loadTxt', 'center')
	screenCenter('loadTxt', 'y')
	setProperty('loadTxt.antialiasing', false)
	addLuaText('loadTxt')

	makeLuaText('controls', '', screenWidth, 0, 40)
	setObjectCamera('controls', 'camHUD')
	setTextSize('controls', 21)
	setTextAlignment('controls', 'center')
	setProperty('controls.antialiasing', false)
	setProperty('controls.visible', false)
	addLuaText('controls')

	makeLuaSprite('leftBorderBar')
	makeGraphic('leftBorderBar', borderBarWidth, screenHeight, '000000')
	setObjectCamera('leftBorderBar', 'camHUD')
	addLuaSprite('leftBorderBar')

	makeLuaSprite('rightBorderBar', nil, screenWidth - borderBarWidth)
	makeGraphic('rightBorderBar', borderBarWidth, screenHeight, '000000')
	setObjectCamera('rightBorderBar', 'camHUD')
	addLuaSprite('rightBorderBar')

	runHaxeCode([[
		addHaxeLibrary('Reflect');

		game.camGame.active = game.camGame.visible = false;
		FlxG.cameras.remove(game.camGame, false);

		var coolCam = new FlxCamera();
		coolCam.bgColor = 0x00;

		game.variables.set('camLoadScreen', coolCam);
		FlxG.cameras.add(coolCam, false);

		game.getLuaObject('blak').camera = coolCam;
		game.getLuaObject('loadTxt').camera = coolCam;



		// low resolution shader
		game.initLuaShader('lowres');
		var lowresFilter = new ShaderFilter(game.createRuntimeShader('lowres'));

		if (game.camHUD._filters == null) game.camHUD._filters = [];
		if (game.camOther._filters == null) game.camOther._filters = [];

		game.camHUD._filters.push(lowresFilter);
		game.camOther._filters.push(lowresFilter);

		game.camHUD.filtersEnabled = game.camOther.filtersEnabled = true;



		// exit scene shaders
		game.initLuaShader('glitch');
		var glitchShader = game.createRuntimeShader('glitch');
		var glitchFilter = new ShaderFilter(glitchShader);
		glitchShader.setFloat('glitchStrength', FlxG.random.float(0.15, 0.4));
		glitchShader.setFloat('glitchSize', FlxG.random.float(0.045, 0.06));

		game.initLuaShader('rgbfx');
		var rgbShader = game.createRuntimeShader('rgbfx');
		var rgbFilter = new ShaderFilter(rgbShader);
		rgbShader.setFloat('amount', 0.025);



		function goBackToSleep():Void {
			game.camHUD._filters.push(glitchFilter);
			game.camHUD._filters.push(rgbFilter);
			game.camOther._filters.push(glitchFilter);
			game.camOther._filters.push(rgbFilter);
		}

		function changeScene(name:String):Void {
			game.variables.set('scene', name);
			game.callOnLuas('onSceneChange', [name]);
		}

		function setMusicVolume(vol:Float):Void {
			FlxG.sound.music.volume = vol;
		}

		function setYASSave(field:String, value:Dynamic):Void {
			if (!game.modchartSaves.exists('lonlihh')) {
				debugPrint("Save isn't initialized >:(");
				return;
			}

			Reflect.setField(game.modchartSaves.get('lonlihh').data, 'yas_' + field, value);
		}

		function getYASSave(field:String, ?default:Dynamic = null):Dynamic {
			if (!game.modchartSaves.exists('lonlihh')) {
				debugPrint("Save isn't initialized >:(");
				return default;
			}

			field = 'yas_' + field;
			var save = game.modchartSaves.get('lonlihh').data;
			if (Reflect.hasField(save, field)) return Reflect.field(save, field);
			return default;
		}



		createGlobalCallback('goBackToSleep', goBackToSleep);
		createGlobalCallback('changeScene', changeScene);
		createGlobalCallback('setMusicVolume', setMusicVolume);
		createGlobalCallback('sysave', setYASSave);
		createGlobalCallback('gysave', getYASSave);
	]])

	local menuPath = 'data/'..string.lower(songName):gsub('%s', '-')..'/'
	setVar('am.menu.path', menuPath)

	local scenesPath = menuPath..'scenes/'
	local i = 0
	while true do
		local scenePath = scenesPath..'room_'..i..'.lua'
		if not checkFileExists(scenePath) then break end

		addLuaScript(scenePath)
		callScript(scenePath, 'loadAssets', {})

		i = i + 1
	end
end

function onTimerCompleted(t, l, ll)
	if t == 'loadTxtFO' then
		doTweenAlpha('blaka', 'blak', 0, 1, 'sineIn')
		doTweenAlpha('loadTxta', 'loadTxt', 0, 1, 'sineIn')
	end

	if t == 'init_firstscene' then changeScene('door') end
end

function onUpdate()
	if keyJustPressed('reset') then loadSong('menu', -1) end
	if keyboardJustPressed('L') then loadSong(songName, -1) end
	if keyboardJustPressed('K') then
		setDataFromSave('lonlihh', 'yas_firstTime', true)
		debugPrint('RESET YAS SAVES')
		loadSong(songName, -1)
	end
end

function onStartCountdown()
	runTimer('init_firstscene', 0.0001)
	return Function_Stop
end