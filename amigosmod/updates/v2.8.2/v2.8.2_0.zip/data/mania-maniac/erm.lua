local firstTime = true
local mechanic = false

function onCreate()
	mechanic = getDataFromSave('lonlihh', 'bNotes')
end

function opponentNoteHit(i, d, t, s)
	if not getPropertyFromGroup('notes', i, 'ignoreNote') then
		local h = getHealth()
		if h > 0.1 then setHealth(h - 0.019) end
	end
end

function onEvent(n, v1, v2)
	if n == 'circle mechanic' and mechanic and firstTime then
		firstTime = false

		local y = -120
		if downscroll then y = -y end

		makeLuaText('cwarn', 'Press [SPACE]!!', screenWidth, 0, getProperty('healthBar.y') + y)
		setObjectCamera('cwarn', 'camHUD')
		setProperty('cwarn.font', getProperty('scoreTxtThing.font'))
		setTextSize('cwarn', 40)
		setTextAlignment('cwarn', 'center')
		screenCenter('cwarn', 'x')
		setProperty('warn.antialiasing', getPropertyFromClass('backend.ClientPrefs', 'data.antialiasing'))
		addLuaText('cwarn')

		runTimer('cwarn', crochet / 2000, 7)
	end
end

function onTimerCompleted(t, l, ll)
	if t == 'cwarn' then
		if getProperty('cwarn.alpha') == 0.4 then setProperty('cwarn.alpha', 1)
		else setProperty('cwarn.alpha', 0.4) end

		if ll == 0 then doTweenAlpha('cwarna', 'cwarn', 0, crochet / 1000, 'sineOut') end
	end
end

function onTweenCompleted(t)
	if t == 'cwarna' then removeLuaText('cwarn', true) end
end