local drain = false
local moveAllowed = false
local aa = false

function onCreate()
	moveAllowed = getDataFromSave('lonlihh', 'optStrumDance')
	aa = getPropertyFromClass('backend.ClientPrefs', 'data.antialiasing')
	
	local y = -120
	if downscroll then y = -y end

	makeLuaText('drainTxt', 'Sentient opponents DRAIN your HEALTH', screenWidth, 0, getProperty('healthBar.y') + y)
	setObjectCamera('drainTxt', 'camHUD')
	setTextSize('drainTxt', 38)
	setTextAlignment('drainTxt', 'center')
	setTextFont('drainTxt', 'fnf.ttf')
	setProperty('drainTxt.antialiasing', aa)
	setProperty('drainTxt.alpha', 0)
	setProperty('drainTxt.visible', false)

	if not downscroll then setTextString('drainTxt', getTextString('drainTxt')..'\nv v v') end

	addLuaText('drainTxt')

	makeLuaText('yourTurn', 'YOUR TURN!', 432, 0, 0)
	setObjectCamera('yourTurn', 'camHUD')
	setTextSize('yourTurn', 48)
	setTextAlignment('yourTurn', 'center')
	setTextFont('yourTurn', 'fnf.ttf')
	setProperty('yourTurn.antialiasing', aa)
	setProperty('yourTurn.borderSize', 2)
	setProperty('yourTurn.alpha', 0)
	addLuaText('yourTurn')
end

function onCreatePost()
	setTextString('botplayTxt', '[BOTPLAY]\nare you that bad')
end

function onUpdatePost()
	if curBeat < 2 then
		for i = 0,3 do setPropertyFromGroup('playerStrums', i, 'alpha', 0.3) end
	end
end

local notesMove = -10
function onBeatHit()
	if curBeat == 4 then
		setProperty('yourTurn.x', getPropertyFromGroup('playerStrums', 0, 'x') - 8)
		setProperty('yourTurn.y', getPropertyFromGroup('playerStrums', 0, 'y') + 28)
	end

	if moveAllowed and curBeat > 127 and curBeat < 256 and curBeat % 2 == 0 then
		local nm = notesMove

		for i = 0,7 do
			local y = getPropertyFromGroup('strumLineNotes', i, 'y')
			setPropertyFromGroup('strumLineNotes', i, 'y', y + nm)
			noteTweenY('strumy'..i, i, y, crochet / 500, 'circOut')

			nm = -nm
		end

		notesMove = -notesMove
	end
end

function onTweenCompleted(t)
	if getProperty('drainTxt.visible') then
		if t == 'dfloat1' then doTweenY('dfloat2', 'drainTxt', getProperty('drainTxt.y') - 15, crochet / 800, 'sineInOut') end
		if t == 'dfloat2' then doTweenY('dfloat1', 'drainTxt', getProperty('drainTxt.y') + 15, crochet / 800, 'sineInOut') end
		if t == 'dfadeout' then setProperty('drainTxt.visible', false) end
	end
end

function onEvent(n, v1, v2)
	if n == 'se' then
		if v1 == 'drain' then
			drain = not drain

			if drain then
				setProperty('drainTxt.visible', true)
				onTweenCompleted('dfloat1')
				doTweenAlpha('dfade', 'drainTxt', 1, crochet / 600, 'sineOut')
				runTimer('drainfade', crochet / 70)
			end
		end

		if v1 == 'yourturn' then
			scaleObject('yourTurn', 1.15, 1.15)
			setProperty('yourTurn.alpha', 1)
			doTweenX('yourTurnsx', 'yourTurn.scale', 1, crochet / 1000, 'circOut')
			doTweenY('yourTurnsy', 'yourTurn.scale', 1, crochet / 1000, 'circOut')
			runTimer('yourturnfade', crochet / 1005)
		end

		if not middlescroll and v1 == 'oppFade' then strumsBlack(false, v2 == 'in') end
		if v1 == 'plrFade' then strumsBlack(true, v2 == 'in') end
	end
end

function strumsBlack(isPlayer, mode)
	local alpha
	local aeae
	if mode then alpha = 1 else alpha = 0.3 end
	if isPlayer then aeae = {4,7} else aeae = {0,3} end

	for i = aeae[1], aeae[2] do noteTweenAlpha('strumfade'..i, i, alpha, crochet / 1200, 'sineOut') end

	aeae = nil
end

function onTimerCompleted(t, l, ll)
	if t == 'yourturnfade' then doTweenAlpha('urturnfade', 'yourTurn', 0, crochet / 1000, 'sineOut') end
	if t == 'drainfade' then doTweenAlpha('dfadeout', 'drainTxt', 0, crochet / 800, 'sineOut') end
end

function opponentNoteHit(i, d, t, s)
	if drain and not getPropertyFromGroup('notes', i, 'ignoreNote') then
		local h = getHealth()
		if h > 0.1 then setHealth(h - 0.015) end
	end
end