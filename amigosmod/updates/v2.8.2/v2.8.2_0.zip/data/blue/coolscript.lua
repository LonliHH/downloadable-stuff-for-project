local strumsY = 200
local dadAngle = 25
local bfAngle = 25
local bfBop = false
local wasMiddleScroll = false

function onDestroy() if wasMiddleScroll then setPropertyFromClass('backend.ClientPrefs', 'data.middleScroll', true) end end
function onCreate()
	wasMiddleScroll = getPropertyFromClass('backend.ClientPrefs', 'data.middleScroll')
	setPropertyFromClass('backend.ClientPrefs', 'data.middleScroll', false)
	setPropertyFromGroup('unspawnNotes', 0, 'visible', false)
end

function onCreatePost()
	setProperty('dad.visible', false)
end

function onEvent(n, v1, v2)
	if n == 'se' and v1 == 'k3strumsIn' then
		runTimer('k3In', 0.05, 4)

		local dur = crochet / 300
		for i = 0, (getProperty('opponentStrums.length') / 2) - 1 do
			noteTweenAlpha('sfade'..i, i, 0.55, dur, 'quadIn')
		end

		--[[
		for i = 8, (getProperty('playerStrums.length') + 8) - 1 do
			noteTweenAlpha('sfade'..i, i, 0.55, dur, 'quadIn')
		end

		k3StrumsThing(strumsY, dur, 'backOut', 'quintOut')
		]]--
	end
end

function opponentNoteHit(i, d, t, s)
	if not getPropertyFromGroup('notes', i, 'ignoreNote') and not getPropertyFromGroup('notes', i, 'gfNote') then
		local h = getHealth()
		if h > 0.1 then setHealth(h - 0.017) end
	end
end

function onBeatHit()
	if curBeat == 24 then runTimer('plrIn', 0.05, 4) end
	if curBeat == 16 then
		for i = 0, getProperty('strumLineNotes.length') - 1 do setPropertyFromGroup('strumLineNotes', i, 'visible', true) end
		runTimer('oppIn', 0.05, 4)
	end

	if curBeat < 64 and curBeat % 2 ~= 0 then
		scaleObject('iconP1', 1, 1)
		scaleObject('iconP2', 1, 1)
	end

	if curBeat > 31 and curBeat < 96 then
		if curBeat < 64 and curBeat % 2 == 0 then return end

		if bfBop then
			-- assuming ur always playing this song as lonli
			if getHealth() > 0.4 then -- 20% health
				setProperty('iconP1.angle', bfAngle)
				doTweenAngle('iconP1Bop', 'iconP1', 0, crochet / 1000, 'circOut')
			else scaleObject('iconP1', 1, 1) end

			scaleObject('iconP2', 1, 1)
			bfBop = not bfBop
			bfAngle = -bfAngle
		else
			scaleObject('iconP1', 1, 1)
			setProperty('iconP2.angle', dadAngle)
			doTweenAngle('iconP2Bop', 'iconP2', 0, crochet / 1000, 'circOut')

			bfBop = not bfBop
			dadAngle = -dadAngle
		end
	end
end

function onTimerCompleted(t, l, ll)
	--[[
	if t == 'oppIn' then
		local i = -(ll - 3)
		noteTweenY('s'..i, i, getPropertyFromGroup('strumLineNotes', i, 'y') + strumsY, crochet / 300, 'backOut')
	end

	if t == 'plrIn' then
		local i = (-(ll - 7)) + 4
		noteTweenY('s'..i, i, getPropertyFromGroup('strumLineNotes', i, 'y') + strumsY, crochet / 300, 'backOut')
	end

	if t == 'k3In' then
		local i = -(ll - 7)
		noteTweenY('s'..i, i, getPropertyFromGroup('strumLineNotes', i, 'y') + strumsY, crochet / 300, 'backOut')
	end
	]]--
end