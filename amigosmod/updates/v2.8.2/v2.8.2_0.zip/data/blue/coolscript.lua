local strumsY = 200
local dadAngle = 25
local bfAngle = 25
local bfBop = false
local wasMiddleScroll = false

function onDestroy() if wasMiddleScroll then setPropertyFromClass('backend.ClientPrefs', 'data.middleScroll', true) end end
function onCreate()
	wasMiddleScroll = getPropertyFromClass('backend.ClientPrefs', 'data.middleScroll')
	setPropertyFromClass('backend.ClientPrefs', 'data.middleScroll', false)
	setPropertyFromGroup('unspawnNotes', 0, 'visible', false)
end

function onCreatePost()
	runHaxeCode([[
		addHaxeLibrary('StrumNote', 'objects');
		addHaxeLibrary('LuaUtils', 'psychlua');

		var dirs = ['left', 'down', 'up', 'right'];
		var k3strums = [];
		var separation:Float = (game.strumLineNotes.members[1].x - game.strumLineNotes.members[0].x) - (game.strumLineNotes.members[0].width * 0.09);

		// already determined the x cz too lazy to fix visual bugs
		var firstPos = 848.677 - (separation * 4);
		for (i in 0...game.opponentStrums.length) {
			var yipe = new StrumNote(firstPos, game.opponentStrums.members[i].y, i, 0);
			yipe.setGraphicSize(yipe.width / 0.7 * 0.65);
			yipe.updateHitbox();
			yipe.downScroll = ClientPrefs.data.downScroll;

			game.opponentStrums.add(yipe);
			game.strumLineNotes.insert(4 + i, yipe);
			k3strums.push(yipe);

			yipe.animation.destroyAnimations();
			yipe.animation.addByPrefix('static', 'arrow' + dirs[i].toUpperCase());
			yipe.animation.addByPrefix('pressed', dirs[i] + ' press', 24, false);
			yipe.animation.addByPrefix('confirm', dirs[i] + ' confirm', 24, false);
			yipe.playAnim('static', false);

			yipe.ID = i;
			yipe.centerOrigin();

			firstPos += separation;
		}

		for (n in game.unspawnNotes) {
			if (n.gfNote && !n.mustPress) {
				if (!n.isSustainNote) {
					n.setGraphicSize(n.width / 0.7 * 0.65);

					if (n.tail.length > 0) for (t in n.tail) {
						t.setGraphicSize(t.width / 0.7 * 0.65, t.height);
					}
				}

				n.updateHitbox();
				n.noteData += game.opponentStrums.length - k3strums.length;
			}
		}

		// to avoid endless looping
		var animLength = game.singAnimations.length;

		for (i in 0...animLength) game.singAnimations.push(game.singAnimations[i]);



		function boom(strumsY:Float, dur:Float, easeName:String, scaleEaseName:String):Void {
			game.callOnScripts('onStrumsSizeChange', [ k3strums[0].scale.x, k3strums[0].scale.y ]);

			var ease = LuaUtils.getTweenEaseByString(easeName);
			var scaleEase = LuaUtils.getTweenEaseByString(scaleEaseName);

			var thingy = (separation * 0.6) + 5;
			var firstPos = thingy / 2;

			for (i in 0...game.opponentStrums.length - k3strums.length) {
				var strum = game.opponentStrums.members[i];
				var scaleX = k3strums[i].scale.x;
				var scaleY = k3strums[i].scale.y;

				FlxTween.tween(strum, { x: firstPos }, dur, { ease: ease });
				FlxTween.tween(strum.scale, { x: scaleX, y: scaleY }, dur, { ease: scaleEase });

				firstPos += separation;
			}

			firstPos = FlxG.width - (thingy * 2);
			var i = game.playerStrums.length - 1;
			while (i >= 0) {
				var strum = game.playerStrums.members[i];
				var scaleX = k3strums[i].scale.x;
				var scaleY = k3strums[i].scale.y;

				FlxTween.tween(strum, { x: firstPos }, dur, { ease: ease });
				FlxTween.tween(strum.scale, { x: scaleX, y: scaleY }, dur, { ease: scaleEase });

				firstPos -= separation;
				i--;
			}
		}

		createCallback('k3StrumsThing', boom);
	]])

	if downscroll then strumsY = -strumsY end

	for i = 0, getProperty('strumLineNotes.length') - 1 do
		setPropertyFromGroup('strumLineNotes', i, 'visible', false)
		setPropertyFromGroup('strumLineNotes', i, 'y', getPropertyFromGroup('strumLineNotes', i, 'y') - strumsY)
	end
end

function onEvent(n, v1, v2)
	if n == 'se' and v1 == 'k3strumsIn' then
		runTimer('k3In', 0.05, 4)

		local dur = crochet / 300
		for i = 0, (getProperty('opponentStrums.length') / 2) - 1 do
			noteTweenAlpha('sfade'..i, i, 0.55, dur, 'quadIn')
		end

		for i = 8, (getProperty('playerStrums.length') + 8) - 1 do
			noteTweenAlpha('sfade'..i, i, 0.55, dur, 'quadIn')
		end

		k3StrumsThing(strumsY, dur, 'backOut', 'quintOut')
	end
end

function opponentNoteHit(i, d, t, s)
	if not getPropertyFromGroup('notes', i, 'ignoreNote') and not getPropertyFromGroup('notes', i, 'gfNote') then
		local h = getHealth()
		if h > 0.1 then setHealth(h - 0.017) end
	end
end

function onBeatHit()
	if curBeat == 24 then runTimer('plrIn', 0.05, 4) end
	if curBeat == 16 then
		for i = 0, getProperty('strumLineNotes.length') - 1 do setPropertyFromGroup('strumLineNotes', i, 'visible', true) end
		runTimer('oppIn', 0.05, 4)
	end

	if curBeat < 64 and curBeat % 2 ~= 0 then
		scaleObject('iconP1', 1, 1)
		scaleObject('iconP2', 1, 1)
	end

	if curBeat > 31 and curBeat < 96 then
		if curBeat < 64 and curBeat % 2 == 0 then return end

		if bfBop then
			-- assuming ur always playing this song as lonli
			if getHealth() > 0.4 then -- 20% health
				setProperty('iconP1.angle', bfAngle)
				doTweenAngle('iconP1Bop', 'iconP1', 0, crochet / 1000, 'circOut')
			else scaleObject('iconP1', 1, 1) end

			scaleObject('iconP2', 1, 1)
			bfBop = not bfBop
			bfAngle = -bfAngle
		else
			scaleObject('iconP1', 1, 1)
			setProperty('iconP2.angle', dadAngle)
			doTweenAngle('iconP2Bop', 'iconP2', 0, crochet / 1000, 'circOut')

			bfBop = not bfBop
			dadAngle = -dadAngle
		end
	end
end

function onTimerCompleted(t, l, ll)
	if t == 'oppIn' then
		local i = -(ll - 3)
		noteTweenY('s'..i, i, getPropertyFromGroup('strumLineNotes', i, 'y') + strumsY, crochet / 300, 'backOut')
	end

	if t == 'plrIn' then
		local i = (-(ll - 7)) + 4
		noteTweenY('s'..i, i, getPropertyFromGroup('strumLineNotes', i, 'y') + strumsY, crochet / 300, 'backOut')
	end

	if t == 'k3In' then
		local i = -(ll - 7)
		noteTweenY('s'..i, i, getPropertyFromGroup('strumLineNotes', i, 'y') + strumsY, crochet / 300, 'backOut')
	end
end