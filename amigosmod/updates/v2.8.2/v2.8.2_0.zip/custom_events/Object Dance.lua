-- script by LonliHH

local allowed = false
local enabled = false
local obj = 'camHUD'
local bnc = 15
local ang = 1
local oy = 0
local oa = 0

function onCreate()
	allowed = getDataFromSave('lonlihh', 'optCamPan', true)
end

function onEvent(n, v1, v2)
	if n == 'Object Dance' then
		enabled = v1 ~= ''
		
		if not enabled and obj ~= '' then
			doTweenY('objdyr', obj, oy, crochet / 1000, 'quadInOut')
			doTweenAngle('objdar', obj, oa, crochet / 1000, 'quadInOut')
		end
		
		if v1 == 'default' then obj = 'camHUD'
		else obj = v1 end
		
		if stringStartsWith(obj, 'cam') and not allowed then
			enabled = false
			return
		end
		
		if enabled then
			oy = getProperty(obj..'.y')
			oa = getProperty(obj..'.angle')
		end
		
		if v2 == '' then
			ang = 1
			bnc = 15
		else
			local val = stringSplit(v2, ',')
			
			if val[1] ~= nil then ang = tonumber(val[1]) end
			if val[2] ~= nil then bnc = tonumber(val[2]) end
		end
	end
end

function onBeatHit()
	if enabled then
		setProperty(obj..'.y', oy + (bnc/2))
		setProperty(obj..'.angle', oa + (ang*2))
		doTweenY('objdy', obj, oy - bnc, (crochet / 1000) / 2, 'circOut')
		doTweenAngle('objda', obj, oa + ang, crochet / 1000, 'circOut')
		
		ang = -ang
	end
end

function onTweenCompleted(t)
	if t == 'objdy' then doTweenY('objdyBack', obj, oy + bnc, (crochet / 1000) / 2, 'circIn') end
end

function onEndSong()
	enabled = false
	return Function_Continue
end