-- script by LonliHH

local active = false
local pressed = false
local engkCounter = 0
local hitTime = 0.0
local minTime = 0.0
local earlyOffset = 0.09
local lateOffset = 0.094
local pos

local noteAccWeight = 0.8 -- 80% of final accuracy comes from notes accuracy
local circleAccWeight = 0.2 -- 20% of final accuracy comes from circle accuracy
local circleScore = 0
local circlesPressed = 0
local circlesMissed = 0
local ratingsData = {
	-- [ratingName] = { ratingMod, ratingScore }
	['sick'] = { 1.0, 350 },
	['good'] = { 0.67, 200 },
	['bad'] = { 0.34, 100 },
	['shit'] = { 0.0, 50 }
}

function onCreate()
	initSaveData('lonlihh', 'amigosmod')
	if not getDataFromSave('lonlihh', 'bNotes') then
		close()
		return
	end

	precacheImage('circle/engk')
	precacheImage('sick')
	precacheImage('good')
	precacheImage('bad')
	precacheImage('shit')
	precacheSound('engk')
	precacheSound('hitsound')
end

function onCreatePost()
	pos = { getProperty('boyfriend.x') - 65, getProperty('boyfriend.y') - 65 }

	makeAnimatedLuaSprite('cmarker', 'circle/marker', pos[1], pos[2])
	addAnimationByPrefix('cmarker', 'idle', 'idle', 24, false)
	addAnimationByPrefix('cmarker', 'press', 'press', 24, false)
	playAnim('cmarker', 'idle', false)
	addLuaSprite('cmarker', true)

	makeLuaSprite('cmlight', 'circle/markerLight', pos[1], pos[2])
	setProperty('cmlight.alpha', 0)
	addLuaSprite('cmlight', true)

	makeLuaSprite('cout', 'circle/out', pos[1], pos[2])
	setProperty('cout.alpha', 0)
	addLuaSprite('cout', true)
end

function getOffsetRating(offset)
	if offset <= 0.030 then return 'sick'
	elseif offset <= 0.054 then return 'good'
	elseif offset <= 0.072 then return 'bad'
	else return 'shit' end
end

function doSomeCoolRating(coolRating)
	circlesPressed = circlesPressed + 1
	circleScore = circleScore + ratingsData[coolRating][1]

	processBlendedAccuracy(false)
	addScore(ratingsData[coolRating][2])



	makeLuaSprite('crating', coolRating, pos[1] + 175, pos[2] - 100)
	scaleObject('crating', 0.6, 0.6)
	addLuaSprite('crating', true)

	doTweenX('cratingsx', 'crating.scale', 0.5, 0.3, 'circOut')
	doTweenY('cratingsy', 'crating.scale', 0.5, 0.3, 'circOut')
	runTimer('cratingfade', 0.5)
end

function goodNoteHit(i, d, t, s) processBlendedAccuracy(true) end
function noteMiss(i, d, t, s) processBlendedAccuracy(true) end
function processBlendedAccuracy(forceUpdate)
	local circleAcc = (circlesPressed + circlesMissed > 0) and ((circleScore / (circlesPressed + circlesMissed)) * 100) or 100
	local finalAcc = (rating * 100 * noteAccWeight) + (circleAcc * circleAccWeight)

	setVar('am.blendedAcc', finalAcc)
	if forceUpdate then callOnScripts('onUpdateScore') end
end

function onEvent(n, v1, v2)
	if n == 'circle mechanic' then
		active = true
		pressed = false

		local time = (crochet / 1000) * (tonumber(v1) - 1)
		local totalTime = time + lateOffset
		hitTime = os.clock() + time
		minTime = hitTime - earlyOffset

		runTimer('circMech', totalTime)
		if getProperty('cpuControlled') then runTimer('circMechBotplay', time) end

		setProperty('cout.scale.x', 2)
		setProperty('cout.scale.y', 2)
		doTweenX('coutsfx', 'cout.scale', 0.9, totalTime, 'linear')
		doTweenY('coutsfy', 'cout.scale', 0.9, totalTime, 'linear')
		doTweenAlpha('coutfade', 'cout', 1, crochet / 2000, 'sineIn')
	end
end

function onTimerCompleted(t, l, ll)
	if t == 'circMech' then
		resetVars()
		if not pressed then
			if getProperty('cpuControlled') then pressedCircle(0)
			else missedCircle() end
		end
	elseif t == 'circMechBotplay' then pressedCircle(0)
	elseif t == 'cratingfade' then doTweenAlpha('cratingfade', 'crating', 0, 0.4, 'sineOut')
	elseif stringStartsWith(t, 'engk') then doTweenAlpha(t, t, 0, crochet / 500, 'sineOut') end
end

local unpaused = false
local circleAnim = 0
function onUpdate()
	if not getProperty('cpuControlled') then
		if circleAnim ~= 1 and keyboardJustPressed('SPACE') then
			circleAnim = 1
			playAnim('cmarker', 'press', false)

			if active and not pressed then
				pressed = true
				local playerHitTime = os.clock()
				local hitOffset = hitTime - playerHitTime
				if hitOffset < 0 then hitOffset = -hitOffset end

				if playerHitTime >= minTime then pressedCircle(hitOffset)
				else missedCircle() end
			end
		elseif (circleAnim ~= 2 and keyboardReleased('SPACE')) or unpaused then
			unpaused = false
			circleAnim = 2
			playAnim('cmarker', 'idle', false)
		end
	end
end

function onAmigosResume() unpaused = true end

function pressedCircle(hitOffset)
	cancelTimer('circMech')
	resetVars()
	playSound('hitsound', 0.45)

	setVar('forceHealth.value', getHealth() + 0.06)
	setVar('forceHealth', true)

	cancelTween('cmlightfade')

	setProperty('cout.alpha', 0)
	setProperty('cmlight.alpha', 1)
	doTweenAlpha('cmlightfade', 'cmlight', 0, crochet / 500, 'quadOut')

	doSomeCoolRating(getOffsetRating(hitOffset))
end

function missedCircle()
	cancelTimer('circMech')
	resetVars()
	circlesMissed = circlesMissed + 1
	processBlendedAccuracy(false)
	addMisses(1)

	setVar('forceHealth.value', getHealth() - 0.15)
	setVar('forceHealth', true)

	local tag = 'engk'..engkCounter
	engkCounter = engkCounter + 1

	makeLuaSprite(tag, 'circle/engk')
	setObjectCamera(tag, 'camOther')
	setObjectOrder(tag, 100)
	addLuaSprite(tag)
	runTimer(tag, crochet / 500)
	youDiedLol()
	playSound('engk', 0.7, 'engk')

	local dur = crochet / 1000
	doTweenX('coutsfx', 'cout.scale', getProperty('cout.scale.x') + 0.25, dur, 'circOut')
	doTweenY('coutsfy', 'cout.scale', getProperty('cout.scale.y') + 0.25, dur, 'circOut')
	doTweenAlpha('coutfade', 'cout', 0, dur, 'sineOut')
end

function onPause() youDiedLol() end
function youDiedLol() stopSound('engk') end
function onTweenCompleted(t) if stringStartsWith(t, 'engk') then removeLuaSprite(t, true) end end
function resetVars()
	active = false
	pressed = false
	hitTime = 0.0
	minTime = 0.0
end