local notold = stringStartsWith(version, '0.7')

function onEvent(n, v1, v2)
	if n == 'CameraControl' then
		local sp = stringSplit(v1, ',')

		if notold then
			triggerEvent('Camera Follow Pos', sp[1], sp[2])
			setProperty('camGame.scroll.x', tonumber(sp[1]) - (screenWidth / 2))
			setProperty('camGame.scroll.y', tonumber(sp[2]) - (screenHeight / 2))
		else
			-- compatibility with older versions
			setProperty('camFollowPos.x', sp[1])
			setProperty('camFollowPos.y', sp[2])
			setProperty('camFollow.x', sp[1])
			setProperty('camFollow.y', sp[2])
			setProperty('camGame.scroll.x', sp[1])
			setProperty('camGame.scroll.y', sp[2])
		end

		setProperty('camGame.zoom', v2)
		setProperty('defaultCamZoom', v2)
	end
end