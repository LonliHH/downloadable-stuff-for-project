function onEvent(n, v1, v2)
	if n == 'Cam Zoom' then
		cancelTween('czm')

		if v2 == '' then setProperty('defaultCamZoom', v1)
		else doTweenZoom('czm', 'camGame', v1, v2, 'sineInOut') end
	end
end

function onTweenCompleted(t)
	if t == 'czm' then setProperty('defaultCamZoom', getProperty('camGame.zoom')) end
end