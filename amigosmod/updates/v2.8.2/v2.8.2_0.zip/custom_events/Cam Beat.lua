local enabled = false
local bt = 1
local cam = 0.015
local ui = 0.03
local sn = ''
local opt = true
local allowed = true

function onCreate()
	initSaveData('lonlihh', 'amigosmod')
	sn = string.lower(songName)
	opt = getDataFromSave('lonlihh', 'optCamPan', true)
	
	if sn == 'kaboom' and opt then allowed = false end
end

function onEvent(n, v1, v2)
	if allowed and n == 'Cam Beat' then
		enabled = v1 ~= '0'
		
		if v1 == '' then bt = 1
		else bt = tonumber(v1) end
		
		if v2 == '' then
			cam = 0.015
			ui = 0.03
		else
			local str = stringSplit(v2, ',')
			
			if str[1] ~= nil then cam = tonumber(str[1]) end
			if str[2] ~= nil then ui = tonumber(str[2]) end
		end
	end
end

function onBeatHit()
	if enabled and curBeat % bt == 0 then
		if curBeat % 4 == 0 then triggerEvent('Add Camera Zoom', cam - 0.015, ui - 0.03)
		else triggerEvent('Add Camera Zoom', cam, ui) end
	end
end

function onEndSong()
	enabled = false
	return Function_Continue
end