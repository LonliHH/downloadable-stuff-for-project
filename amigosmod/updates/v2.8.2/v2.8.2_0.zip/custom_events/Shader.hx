// script by LonliHH

import haxe.Timer;
import flixel.util.FlxSave;
import backend.CoolUtil;
import Reflect;

var stupid:Bool = true;
var on:Bool = false;
var shaders = [];

function onCreate() {
	initSave('lonlihh');
	var lvl:Int = getSave('lonlihh', 'shaderLvl');

	if (lvl > 0) {
		var naur = ['glitch1', 'weird', 'glitch2', 'gridWaveEffect'];

		if (game.camGame._filters == null) game.camGame._filters = [];
		if (game.camHUD._filters == null) game.camHUD._filters = [];

		for (i in 0...(lvl * 2)) {
			game.initLuaShader(naur[i]);
			var shader = game.createRuntimeShader(naur[i]);
			var filter = new ShaderFilter(shader);

			game.camGame._filters.push(filter);
			game.camHUD._filters.push(filter);

			shaders.push(shader);
		}

		game.camGame.filtersEnabled = game.camHUD.filtersEnabled = on;
	} else {
		stupid = false;
		if (getSave('lonlihh', 'optimizeMod')) {
			on = false;
			shaders = null;
		}
	}
}

function onUpdate(elapsed:Float) {
	if (stupid && ((game.camGame.filtersEnabled && game.camGame.visible) || (game.camHUD.filtersEnabled && game.camHUD.visible))) {
		var iTime = Timer.stamp();
		for (s in shaders) s.setFloat('iTime', iTime);
	}
}

function onEvent(name:String, value1:String, value2:String, strumTime:Float) {
	if (stupid && name == 'Shader') {
		switch (value1) {
			case '0': on = false;
			case '1': on = true;
			case 'toggle': on = !on;
		}

		game.camGame.filtersEnabled = game.camHUD.filtersEnabled = on;
	}
}



function initSave(name:String, ?folder:String = 'LonliHH/PsychEngine') {
	if (!game.modchartSaves.exists(name)) {
		var save = new FlxSave();
		save.bind(name, folder);
		game.modchartSaves.set(name, save);
	}
}

function getSave(name:String, field:String, ?default:Dynamic = null) {
	if (game.modchartSaves.exists(name)) {
		var save = game.modchartSaves.get(name).data;
		if (Reflect.hasField(save, field)) return Reflect.field(save, field);
	}

	return default;
}