function onCreate()
	makeLuaText('sub', 'TEST SUBTITLE', 400, 0, 550)
	setObjectCamera('sub', 'camHUD')
	setTextSize('sub', 25)
	setTextAlignment('sub', 'center')
	screenCenter('sub', 'x')
	setProperty('sub.alpha', 0)
	addLuaText('sub')
end

function onEvent(n, v1, v2)
	if n == 'subtitles' then
		if v1 ~= '' then
			setTextString('sub', v1)
			cancelTween('subfade')
			setProperty('sub.alpha', 1)
		else
			doTweenAlpha('subfade', 'sub', 0, 0.5, 'sineOut')
		end
		
		if v2 ~= '' then setTextColor('sub', v2) end
	end
end