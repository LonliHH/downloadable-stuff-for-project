function onCreate()
	local invisact = function(tag)
		setProperty(tag..'.visible', false)
		setProperty(tag..'.active', false)
	end

	invisact('boyfriend')
	invisact('gf')
	invisact('dad')
	invisact('healthBar')
	if luaSpriteExists('healthBarBG') then invisact('healthBarBG') end
	invisact('scoreTxt')
	invisact('botplayTxt')
	invisact('iconP1')
	invisact('iconP2')

	if string.lower(timeBarType) ~= 'disabled' then
		invisact('timeBar')
		if luaSpriteExists('timeBarBG') then invisact('timeBarBG') end
		invisact('timeTxt')
	end

	makeLuaSprite('bg', 'menu/bg')
	setProperty('bg.color', getColorFromHex('0c90f5'))
	setObjectCamera('bg', 'camHUD')
	addLuaSprite('bg')

	makeLuaSprite('ch', 'menu/checkered', -250)
	setObjectCamera('ch', 'camHUD')
	setProperty('ch.alpha', 0.35)
	addLuaSprite('ch')
end