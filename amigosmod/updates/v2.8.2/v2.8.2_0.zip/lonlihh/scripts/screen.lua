function onCreate()
	setProperty('boyfriend.visible', false)
	setProperty('boyfriend.active', false)
	setProperty('gf.visible', false)
	setProperty('gf.active', false)
	setProperty('dad.visible', false)
	setProperty('dad.active', false)
	setProperty('healthBar.visible', false)
	setProperty('healthBar.active', false)
	if luaSpriteExists('healthBarBG') then setProperty('healthBarBG.visible', false) end
	setProperty('scoreTxt.visible', false)
	setProperty('botplayTxt.visible', false)
	setProperty('iconP1.visible', false)
	setProperty('iconP1.active', false)
	setProperty('iconP2.visible', false)
	setProperty('iconP2.active', false)

	if string.lower(timeBarType) ~= 'disabled' then
		setProperty('timeBar.visible', false)
		if luaSpriteExists('timeBarBG') then setProperty('timeBarBG.visible', false) end
		setProperty('timeTxt.visible', false)
	end

	makeLuaSprite('bg', 'menu/bg')
	setProperty('bg.color', getColorFromHex('0c90f5'))
	setObjectCamera('bg', 'camHUD')
	addLuaSprite('bg')

	makeLuaSprite('ch', 'menu/checkered', -250)
	setObjectCamera('ch', 'camHUD')
	setProperty('ch.alpha', 0.35)
	addLuaSprite('ch')
end