local bfAlt = false
local dadAlt = false
local dirs = {'singLEFT', 'singDOWN', 'singUP', 'singRIGHT'}

function goodNoteHit(i, d, t, s)
	if t == 'charac flip note' then
		local charac = 'boyfriend'
		if getPropertyFromGroup('notes', i, 'gfNote') then charac = 'gf' end

		local newScaleX = getProperty(charac..'.scale.x')
		local suffix = ''
		if bfAlt then suffix = '-alt' end

		if not s then
			newScaleX = -newScaleX
			setProperty(charac..'.scale.x', newScaleX)
		end

		if newScaleX > 0 then
			playAnim(charac, dirs[d + 1]..suffix, true)
		else
			if d == 0 then playAnim(charac, 'singRIGHT'..suffix, true)
			elseif d == 3 then playAnim(charac, 'singLEFT'..suffix, true)
			else playAnim(charac, dirs[d + 1]..suffix, true) end
		end
	end
end

function noteMiss(i, d, t, s)
	if not s and t == 'charac flip note' then
		local charac = 'boyfriend'
		if getPropertyFromGroup('notes', i, 'gfNote') then charac = 'gf' end
		setProperty(charac..'.scale.x', -getProperty(charac..'.scale.x'))
	end
end

function opponentNoteHit(i, d, t, s)
	if t == 'charac flip note' then
		local charac = 'dad'
		if getPropertyFromGroup('notes', i, 'gfNote') then charac = 'gf' end

		local newScaleX = getProperty(charac..'.scale.x')
		local suffix = ''
		if dadAlt then suffix = '-alt' end

		if not s then
			newScaleX = -newScaleX
			setProperty(charac..'.scale.x', newScaleX)
		end

		if newScaleX > 0 then
			playAnim(charac, dirs[d + 1]..suffix, true)
		else
			if d == 0 then playAnim(charac, 'singRIGHT'..suffix, true)
			elseif d == 3 then playAnim(charac, 'singLEFT'..suffix, true)
			else playAnim(charac, dirs[d + 1]..suffix, true) end
		end
	end
end

function onEvent(n, v1, v2)
	if n == 'se' and v1 == 'charac flip note' then
		if v2 == 'bf alt-on' then bfAlt = true
		elseif v2 == 'bf alt-off' then bfAlt = false
		elseif v2 == 'dad alt-on' then dadAlt = true
		elseif v2 == 'dad alt-off' then dadAlt = false end
	end
end