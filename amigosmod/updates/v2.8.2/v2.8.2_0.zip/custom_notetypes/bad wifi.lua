function onCreate()
	local enabled = getDataFromSave('lonlihh', 'bNotes', true)

	for i = 0, getProperty('unspawnNotes.length') - 1 do
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'bad wifi' then
			setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', true)
			setPropertyFromGroup('unspawnNotes', i, 'rgbShader.enabled', false)

			if enabled then
				setPropertyFromGroup('unspawnNotes', i, 'texture', 'noteassets/discord')
				setPropertyFromGroup('unspawnNotes', i, 'hitCausesMiss', true)
				setPropertyFromGroup('unspawnNotes', i, 'missHealth', 0.02)
			else
				setPropertyFromGroup('unspawnNotes', i, 'mustPress', false)
				setPropertyFromGroup('unspawnNotes', i, 'copyAlpha', false)
				setPropertyFromGroup('unspawnNotes', i, 'alpha', 0)
				setPropertyFromGroup('unspawnNotes', i, 'visible', false)
			end
		end
	end

	if enabled then
		precacheSound('join')
		precacheSound('leave')
	else close() end
end

function onSongStart()
	local y = 95
	if downscroll then y = 615 end

	makeLuaSprite('reconBarOutline', nil, getPropertyFromGroup('strumLineNotes', 4, 'x') + 39, y)
	makeGraphic('reconBarOutline', 373, 18, '1f1f1f')
	setObjectCamera('reconBarOutline', 'camHUD')
	setProperty('reconBarOutline.alpha', 0)
	addLuaSprite('reconBarOutline')

	makeLuaSprite('reconBarBG', nil, getProperty('reconBarOutline.x') + 4, getProperty('reconBarOutline.y') + 4)
	makeGraphic('reconBarBG', 365, 10, '999999')
	setObjectCamera('reconBarBG', 'camHUD')
	setProperty('reconBarBG.alpha', 0)
	addLuaSprite('reconBarBG')

	makeLuaSprite('reconBar', nil, getProperty('reconBarBG.x'), getProperty('reconBarBG.y'))
	makeGraphic('reconBar', 365, 10, 'ffffff')
	setObjectCamera('reconBar', 'camHUD')
	setProperty('reconBar.alpha', 0)
	addLuaSprite('reconBar')

	makeLuaText('recTxt', 'wenamechainasama', 800, getProperty('reconBar.x') - 220, getProperty('reconBar.y') - 8)
	setTextSize('recTxt', 22)
	setTextAlignment('recTxt', 'center')
	setProperty('recTxt.borderSize', 1.4)
	setProperty('recTxt.font', getProperty('scoreTxt.font'))
	setProperty('recTxt.antialiasing', getProperty('scoreTxt.antialiasing'))
	setProperty('recTxt.alpha', 0)
	addLuaText('recTxt')
end

function noteMiss(id, dir, ntype, sus)
	if ntype == 'bad wifi' then
		setProperty('boyfriend.stunned', true)
		playSound('leave')

		cancelTween('recBarScaleX')
		cancelTween('rta')
		cancelTween('rboa')
		cancelTween('rbga')
		cancelTween('rba')

		setProperty('reconBarOutline.color', getColorFromHex('1f1f1f'))
		setProperty('reconBarBG.color', getColorFromHex('999999'))
		setProperty('reconBar.color', getColorFromHex('ffffff'))
		setProperty('reconBarOutline.alpha', 1)
		setProperty('reconBarBG.alpha', 1)
		setProperty('reconBar.alpha', 1)
		setProperty('reconBar.scale.x', 0)
		setTextColor('recTxt', 'ffffff')
		setTextString('recTxt', 'Reconnecting in 1.0s...')
		setProperty('recTxt.alpha', 1)

		for i = 4,7 do
			cancelTween('badwifiRecon'..i)
			noteTweenAlpha('badwifiRecon'..i, i, 0.4, 0.5, 'sineOut')
		end

		doTweenX('recBarScaleX', 'reconBar.scale', 1, 1, 'linear')
		runTimer('recon', 0.1, 10)
	end
end

function onUpdatePost()
	if getProperty('boyfriend.stunned') then setProperty('vocals.volume', 0) end
end

function onTimerCompleted(t, l, ll)
	if t == 'recon' then
		if ll == 0 then
			setProperty('boyfriend.stunned', false)
			playSound('join')
			setTextColor('recTxt', '63ff75')
			setTextString('recTxt', 'Reconnected!')
			setProperty('reconBarOutline.color', getColorFromHex('0e2e12'))
			setProperty('reconBarBG.color', getColorFromHex('33823c'))
			setProperty('reconBar.color', getColorFromHex('63ff75'))

			doTweenAlpha('rta', 'recTxt', 0, 0.5, 'sineOut')
			doTweenAlpha('rboa', 'reconBarOutline', 0, 0.5, 'sineOut')
			doTweenAlpha('rbga', 'reconBarBG', 0, 0.5, 'sineOut')
			doTweenAlpha('rba', 'reconBar', 0, 0.5, 'sineOut')

			for i = 4,7 do
				cancelTween('badwifiRecon'..i)
				noteTweenAlpha('badwifiRecon'..i, i, 1, 0.5, 'sineIn')
			end
		else setTextString('recTxt', 'Reconnecting in 0.'..ll..'s...') end
	end
end