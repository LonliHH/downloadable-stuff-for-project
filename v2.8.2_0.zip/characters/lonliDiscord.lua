local plr = 'dad'
local plrx = 0

function onCreate()
	if boyfriendName == 'lonliDiscord' then
		plr = 'boyfriend'
		setPropertyFromClass('substates.GameOverSubstate', 'characterName', boyfriendName)
		setPropertyFromClass('substates.GameOverSubstate', 'deathSoundName', 'oof')
		setPropertyFromClass('substates.GameOverSubstate', 'loopSoundName', 'sadpiano')

		setVar('am.death.charName', boyfriendName)
		setVar('am.death.charSprite', 'characters/'..boyfriendName)
		setVar('am.death.bgColor', '2f3136')
		setVar('am.death.off.cam.x', -275.5)
		setVar('am.death.off.cam.y', 187.75)
		setVar('am.death.off.x', -200)
		setVar('am.death.off.y', 3)
		setVar('am.death.off.time', 0.2)
		setVar('plr.noReaction', true)
	elseif dadName == 'lonliDiscord' then setVar('opp.noReaction', true) else plr = 'gf' end

	plrx = getProperty(plr..'.x')

	makeLuaSprite('lonliName', 'clones/lonliName', plrx - 16, getProperty(plr..'.y') - 65)
	addLuaSprite('lonliName', true)
end

function onUpdatePost()
	local isVisible = getProperty(plr..'.visible')
	setProperty('lonliName.visible', isVisible)

	if isVisible then
		setProperty(plr..'.x', plrx)
		setProperty('lonliName.y', getProperty(plr..'.y') - 65)

		if getProperty(plr..'.scale.x') == -1 then
			setProperty(plr..'.x', plrx + 4)
			setProperty('lonliName.x', getProperty(plr..'.x') - 20)
		end
	end
end