-- by LonliHH
local width = 298
local height = 72
local slideX = 385
local onScreen = false

function onCreate()
	makeLuaSprite('npBG', nil, -(slideX + 30), 20)
	makeGraphic('npBG', width, height, '000000')
	setObjectCamera('npBG', 'camOther')
	setProperty('npBG.alpha', 0.8)
	addLuaSprite('npBG')

	makeLuaSprite('npCol', nil, getProperty('npBG.x') + width, getProperty('npBG.y'))
	makeGraphic('npCol', 16, height, 'ffffff')
	setObjectCamera('npCol', 'camOther')
	addLuaSprite('npCol')

	makeLuaText('npHead', 'aeee', width - 10, getProperty('npBG.x'), getProperty('npBG.y') + 10)
	setObjectCamera('npHead', 'camOther')
	setTextSize('npHead', 26)
	setTextAlignment('npHead', 'right')
	setProperty('npHead.borderSize', 3)
	setProperty('npHead.antialiasing', false)
	setProperty('npHead.wordWrap', true)
	addLuaText('npHead')

	makeLuaText('npTxt', 'bbbb', width - 10, getProperty('npHead.x'), getProperty('npHead.y') + 26)
	setObjectCamera('npTxt', 'camOther')
	setTextSize('npTxt', 22)
	setTextAlignment('npTxt', 'right')
	setProperty('npTxt.borderSize', 2)
	setProperty('npTxt.antialiasing', false)
	setProperty('npTxt.wordWrap', true)
	addLuaText('npTxt')
end

function onEvent(n, v1, v2)
	if n == 'bar thing' then
		if v1 == '' then v1 = '0' end

		if v1 == '0' and not onScreen then
			onScreen = true
			local dur = crochet / 280
			doTweenX('npBGx', 'npBG', getProperty('npBG.x') + slideX, dur, 'circOut')
			doTweenX('npColx', 'npCol', getProperty('npCol.x') + slideX, dur, 'circOut')
			doTweenX('npTxtx', 'npTxt', getProperty('npTxt.x') + slideX, dur, 'circOut')
			doTweenX('npHeadx', 'npHead', getProperty('npHead.x') + slideX, dur, 'circOut')
		end

		if v1 == '1' and onScreen then
			onScreen = false
			local dur = crochet / 250
			doTweenX('npBGback', 'npBG', getProperty('npBG.x') - slideX, dur, 'quadIn')
			doTweenX('npColback', 'npCol', getProperty('npCol.x') - slideX, dur, 'quadIn')
			doTweenX('npTxtback', 'npTxt', getProperty('npTxt.x') - slideX, dur, 'quadIn')
			doTweenX('npHeadback', 'npHead', getProperty('npHead.x') - slideX, dur, 'quadIn')
		end

		if v1 == '2' then
			if v2 == '' then v2 = 'among;us;ff0000' end

			local vals = stringSplit(v2, ';')
			setTextString('npHead', vals[1])
			setTextString('npTxt', vals[2])
			setProperty('npCol.color', getColorFromHex(vals[3]))

			if onScreen then
				local offx = 30
				local dur = crochet / 1000
				setProperty('npBG.x', getProperty('npBG.x') + offx)
				setProperty('npCol.x', getProperty('npCol.x') + offx)
				setProperty('npTxt.x', getProperty('npTxt.x') + offx)
				setProperty('npHead.x', getProperty('npHead.x') + offx)
				doTweenX('npBGx', 'npBG', getProperty('npBG.x') - offx, dur, 'circOut')
				doTweenX('npColx', 'npCol', getProperty('npCol.x') - offx, dur, 'circOut')
				doTweenX('npTxtx', 'npTxt', getProperty('npTxt.x') - offx, dur, 'circOut')
				doTweenX('npHeadx', 'npHead', getProperty('npHead.x') - offx, dur, 'circOut')
			end
		end

		if v1 == '3' then
			removeLuaSprite('npBG', true)
			removeLuaSprite('npCol', true)
			removeLuaText('npHead', true)
			removeLuaText('npTxt', true)
			close()
		end
	end
end