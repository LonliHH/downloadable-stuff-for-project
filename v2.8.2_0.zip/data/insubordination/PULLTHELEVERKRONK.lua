local started = false

function onEvent(n, v1, v2)
	if n == 'se' then
		if v1 == 'blackScreen' then
			makeLuaSprite('blak')
			makeGraphic('blak', screenWidth, screenHeight, '000000')
			setObjectCamera('blak', 'camHUD')
			addLuaSprite('blak')
		end
	end
end

function onCreatePost()
	addHaxeLibrary('LuaUtils', 'psychlua')
	addHaxeLibrary('CustomSubstate', 'psychlua')
	runHaxeCode([[
		game.dad.x -= 200;
		game.dad.y -= 80;
		game.dad.scale.x = 0.8;
		game.dad.scale.y = 0.8;

		game.boyfriend.flipX = false;
		game.boyfriend.x += 350;
		game.boyfriend.y += 600;

		game.camFollow.x = 500;
		game.camFollow.y = 550;
		game.camGame.snapToTarget();

		var yaur:Int = 0;
		for (s in game.opponentStrums.members) {
			s.x = game.dad.x + (yaur * 112);
			s.y = -100;

			if (ClientPrefs.data.downScroll) s.y = 700;

			s.cameras = [game.camGame];
			s.scrollFactor.x = 1;
			s.scrollFactor.y = 1;

			yaur++;
		}

		for (n in game.unspawnNotes) {
			if (!n.mustPress) {
				n.cameras = [game.camGame];
				n.scrollFactor.x = 1;
				n.scrollFactor.y = 1;
			}
		}

		for (i in 0...2) {
			var n = game.unspawnNotes[i];
			if (!n.mustPress) {
				n.copyAlpha = false;
				n.visible = false;
				n.noteType = 'insubo';
			}
		}
	]])

	setObjectOrder('dadGroup', getObjectOrder('notes') + 2)
	setObjectOrder('strumLineNotes', getObjectOrder('dadGroup') - 1)
end

function onUpdatePost()
	if not started then
		for i = 0,7 do
			setPropertyFromGroup('strumLineNotes', i, 'alpha', 0.6)
		end

		for i = 0, getProperty('notes.length') - 1 do
			setPropertyFromGroup('notes', i, 'copyAlpha', false)
			setPropertyFromGroup('notes', i, 'alpha', 0.6)
		end
	end
end

function onSongStart() runTimer('delayy', 0.6) end
function onTimerCompleted(t, l, ll) if t == 'delayy' then started = true end end

function goodNoteHit(i, d, t, s)
	if not s and not getPropertyFromGroup('notes', i, 'ignoreNote') and mustHitSection then setProperty('defaultCamZoom', 0.8) end
end

function opponentNoteHit(i, d, t, s)
	if t ~= 'insubo' and not s and not getPropertyFromGroup('notes', i, 'ignoreNote') and not mustHitSection then setProperty('defaultCamZoom', 1) end
end