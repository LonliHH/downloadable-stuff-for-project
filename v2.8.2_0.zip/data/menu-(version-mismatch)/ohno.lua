function onCreate()
	setProperty('boyfriend.visible', false)
	setProperty('gf.visible', false)
	setProperty('dad.visible', false)
	setProperty('healthBar.visible', false)
	if stringStartsWith(version, '0.6') then setProperty('healthBarBG.visible', false) end
	setProperty('scoreTxt.visible', false)
	setProperty('botplayTxt.visible', false)
	setProperty('iconP1.visible', false)
	setProperty('iconP2.visible', false)
	
	if string.lower(timeBarType) ~= 'disabled' then
		setProperty('timeBar.visible', false)
		setProperty('timeBarBG.visible', false)
		setProperty('timeTxt.visible', false)
	end
	
	makeLuaSprite('bg', 'menu/bg')
	setObjectCamera('bg', 'camHUD')
	addLuaSprite('bg')
	
	makeLuaSprite('ch', 'menu/checkered', -250)
	setObjectCamera('ch', 'camHUD')
	setProperty('ch.alpha', 0.35)
	addLuaSprite('ch')
	
	makeLuaText('misver', "You're using a version of Psych Engine that Amigos Mod does not support :(\n\nPlease use v0.7.1h as Amigos Mod was made on this version\n\n(You're currently using v"..version..")\n\nSo ya we recommend using that instead because older versions cause backend code bugs, while newer versions cause frontend code bugs\n\n(Press ESC to exit)", 1000, 0, 0)
	setObjectCamera('misver', 'camHUD')
	setTextSize('misver', 36)
	setTextAlignment('misver', 'center')
	screenCenter('misver', 'xy')
	setProperty('misver.y', getProperty('misver.y') + 100)
	setProperty('misver.antialiasing', false)
	addLuaText('misver')
end

function onCreatePost()
	playMusic('sadpiano', 1, true)
	doTweenY('misver', 'misver', getProperty('misver.y') - 100, 1.8, 'circOut')
end

function onUpdate(elapsed)
	if keyJustPressed('back') then exitSong(false) end
	
	if getProperty('ch.x') >= 0 then setProperty('ch.x', -200)
	else setProperty('ch.x', getProperty('ch.x') + 100 * elapsed) end
end

function onStartCountdown() return Function_Stop end